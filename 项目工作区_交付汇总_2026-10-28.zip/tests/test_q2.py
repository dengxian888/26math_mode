# -*- coding: utf-8 -*-
"""问题2 预测的验证（T2）。

重点验证三件事：
  1. **无未来信息泄漏**：特征只能来自 D-5（用电量）/ D（预测信息）/ D-3（实际信息）
  2. **信息增量真实存在**：MAE(A) > MAE(B) ≥ MAE(C)，且都优于朴素基线
  3. **输出契约**：3672 行、键与附件6 模板一致、无缺失、量级合理

用法：<venv>/python.exe tests/test_q2.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402

from src.common import fill_att6 as F  # noqa: E402
from src.q2.features import (FEAT_A, FEAT_B, FEAT_C, build_panel,  # noqa: E402
                            check_no_leakage)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def main():
    print("=" * 66)
    print("问题2 验证")
    print("=" * 66)

    panel = build_panel()

    # ---------- 1. 无泄漏 ----------
    print("\n[1] 时间闸门：特征不得含未来信息")
    probs = check_no_leakage(panel)
    check("lag5 来自 D-5", not probs, str(probs) if probs else "抽查通过")

    # 逐条核对滞后的定义（用日期位置回推，独立于特征实现）
    dates = sorted(panel["date"].unique())
    rng = np.random.default_rng(0)
    errs = []
    sample = panel.dropna(subset=["lag5", "lag6", "lag7"]).sample(60, random_state=1)
    for _, r in sample.iterrows():
        i = dates.index(r["date"])
        if i < 8:
            continue
        for k, col in ((5, "lag5"), (6, "lag6"), (7, "lag7")):
            ref = panel[(panel["date"] == dates[i - k]) & (panel["hour"] == r["hour"])]["load_actual"]
            if len(ref) and abs(float(ref.iloc[0]) - float(r[col])) > 1e-9:
                errs.append((r["date"], r["hour"], col))
    check("lag5/6/7 与 D-5/6/7 的实测值逐一对上", not errs, f"不符 {len(errs)} 处")

    # att3 实际信息必须滞后 3 天（不能用 D-1/D-2 的）
    a3a = pd.read_csv(os.path.join(ROOT, "data/interim/att3_实际信息.csv"), encoding="utf-8-sig")
    sample = panel.dropna(subset=["a3a_load_total_lag3"]).sample(30, random_state=2)
    bad = 0
    for _, r in sample.iterrows():
        i = dates.index(r["date"])
        if i < 4:
            continue
        ref = a3a[(a3a["date"] == dates[i - 3]) & (a3a["hour"] == r["hour"])]["load_total"]
        if len(ref) and abs(float(ref.iloc[0]) - float(r["a3a_load_total_lag3"])) > 1e-6:
            bad += 1
    check("附件3 实际信息滞后 3 天（≤D-3）", bad == 0, f"不符 {bad} 处")

    # ---------- 2. 三档特征嵌套关系 ----------
    print("\n[2] 三档特征必须是嵌套关系（只加信息、不换模型）")
    check("A ⊂ B", set(FEAT_A) <= set(FEAT_B))
    check("B ⊂ C", set(FEAT_B) <= set(FEAT_C))
    check("B 只新增附件3 预测列", {c for c in FEAT_B if c.startswith("a3f_")} and
          all(c.startswith("a3f_") for c in set(FEAT_B) - set(FEAT_A)))
    check("C 只新增附件3 实际列", all(c.startswith("a3a_") for c in set(FEAT_C) - set(FEAT_B)))

    # ---------- 3. 契约 ----------
    print("\n[3] 输出契约")
    path = os.path.join(OUT, "q2_forecast.csv")
    check("q2_forecast.csv 存在", os.path.exists(path))
    if os.path.exists(path):
        q = pd.read_csv(path, encoding="utf-8-sig")
        check("行数 = 3672", len(q) == 3672, f"{len(q)}")
        need = ["date", "hour", "pred_A", "pred_B", "pred_C", "pred_final", "note"]
        check("列齐全", all(c in q.columns for c in need))
        check("无缺失值", not q[need[2:6]].isna().any().any())
        check("预测值非负", (q[["pred_A", "pred_B", "pred_C", "pred_final"]] >= 0).all().all())
        check("预测值量级合理", (q[["pred_A", "pred_B", "pred_C", "pred_final"]] < 1000).all().all())

        # 与附件6 模板的键对齐
        wb = load_workbook(F.DEFAULT_TEMPLATE, data_only=True)
        ws = wb["问题2_用电量预测"]
        tpl = {(str(ws.cell(r, 1).value)[:10], F.text_to_hour(ws.cell(r, 2).value))
               for r in range(4, 3676)}
        got = set(zip(q["date"], q["hour"]))
        check("键与模板预填完全一致", got == tpl,
              f"缺 {len(tpl - got)} 个，多 {len(got - tpl)} 个")

        # pred_final 必须等于某一档
        eq = [(np.abs(q["pred_final"] - q[f"pred_{s}"]).max() < 1e-9) for s in "ABC"]
        check("pred_final 等于 A/B/C 之一", any(eq),
              f"匹配 {[s for s, e in zip('ABC', eq) if e]}")

    # ---------- 4. 信息增量 ----------
    print("\n[4] 信息增量（MAE 必须随信息增加而下降）")
    mp = os.path.join(OUT, "q2_metrics.csv")
    if not os.path.exists(mp):
        check("q2_metrics.csv 存在", False)
    else:
        md = pd.read_csv(mp, encoding="utf-8-sig").set_index("scheme")
        mae = {s: float(md.loc[s, "MAE"]) for s in md.index}
        check("A 优于基线（同类型同时段均值）",
              mae["A"] < mae["baseline"], f"A={mae['A']:.4f} vs 基线={mae['baseline']:.4f}")
        check("B 优于 A（预测信息有价值）", mae["B"] < mae["A"],
              f"降幅 {(mae['A'] - mae['B']) / mae['A'] * 100:.2f}%")
        check("C 不劣于 B", mae["C"] <= mae["B"] + 1e-6,
              f"C={mae['C']:.4f} vs B={mae['B']:.4f}")

    # ---------- 5. 误差诊断 ----------
    print("\n[5] 误差诊断产出")
    dp = os.path.join(OUT, "q2_error_diag.csv")
    check("q2_error_diag.csv 存在", os.path.exists(dp))
    if os.path.exists(dp):
        d = pd.read_csv(dp, encoding="utf-8-sig")
        check("含 hour 与 day_type 两个维度",
              set(d["维度"].unique()) == {"hour", "day_type"})
        check("分时段覆盖 24 个", (d[d["维度"] == "hour"]["取值"].nunique() == 24))

    print("\n" + "=" * 66)
    if FAILS:
        print(f"✘ 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("✔ 问题2 验证全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
