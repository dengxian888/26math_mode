# -*- coding: utf-8 -*-
"""问题4 验证（T4）。

重点：
  1. 契约：3672 行 / 8 列 / 键与附件6 模板一致；周期表 9 行 = 3 方案 × 3 周期
  2. 一致性：q4_risk 里的 q_det 必须等于问题3 的 q_bid（同键同值）
  3. **局部最优**：在情景池上，q_risk 的目标值不应劣于其邻域点
  4. 无前视：情景池只取 date ≤ D−5 的残差

用法：<venv>/python.exe tests/test_q4.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402

from src.common import fill_att6 as F  # noqa: E402
from src.q4.solve import (ALPHA, LOAD_LAG, PERIODS, SCHEMES,  # noqa: E402
                          cvar, optimal_q, prepare, scenario_costs)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def main():
    print("=" * 66)
    print("问题4 验证")
    print("=" * 66)

    # ---------- 1. 明细表契约 ----------
    print("\n[1] q4_risk.csv 契约")
    rp = os.path.join(OUT, "q4_risk.csv")
    check("q4_risk.csv 存在", os.path.exists(rp))
    r = None
    if os.path.exists(rp):
        r = pd.read_csv(rp, encoding="utf-8-sig")
        check("行数 = 3672", len(r) == 3672, f"{len(r)}")
        need = ["date", "hour", "q_det", "q_risk", "risk_measure",
                "risk_param", "note", "scheme_id"]
        check("8 列齐全", all(c in r.columns for c in need))
        check("无数值缺失", not r[["q_det", "q_risk"]].isna().any().any())
        check("申报量非负", bool((r[["q_det", "q_risk"]] >= 0).all().all()))
        check("申报量量级合理", bool((r[["q_det", "q_risk"]] < 1000).all().all()))
        check("只填一个主方案", r["scheme_id"].nunique() == 1,
              f"{sorted(r['scheme_id'].unique())}")

        wb = load_workbook(F.DEFAULT_TEMPLATE, data_only=True)
        ws = wb["问题4_风险申报"]
        tpl = {(str(ws.cell(i, 1).value)[:10], F.text_to_hour(ws.cell(i, 2).value))
               for i in range(4, 3676)}
        got = set(zip(r["date"], r["hour"]))
        check("键与模板预填完全一致", got == tpl,
              f"缺 {len(tpl - got)} 个，多 {len(got - tpl)} 个")

    # ---------- 2. 与问题3 一致 ----------
    print("\n[2] q_det 必须与问题3 的申报量一致")
    q3p = os.path.join(OUT, "q3_price_bid.csv")
    if r is not None and os.path.exists(q3p):
        q3 = pd.read_csv(q3p, encoding="utf-8-sig")[["date", "hour", "q_bid"]]
        m = r.merge(q3, on=["date", "hour"])
        gap = float((m["q_det"] - m["q_bid"]).abs().max())
        # 问题3 存 6 位小数、问题4 按契约存 4 位，故容差取 1e-3
        check("q_det == 问题3 q_bid", gap < 1e-3, f"最大差 {gap:.2e}")
        check("风险申报 ≠ 确定性申报（确实做了优化）",
              float((r["q_risk"] - r["q_det"]).abs().mean()) > 1e-3,
              f"平均差 {float((r['q_risk'] - r['q_det']).abs().mean()):.2f} MWh")

    # ---------- 3. 周期表契约 ----------
    print("\n[3] q4_cycle.csv 契约")
    cp = os.path.join(OUT, "q4_cycle.csv")
    check("q4_cycle.csv 存在", os.path.exists(cp))
    if os.path.exists(cp):
        c = pd.read_csv(cp, encoding="utf-8-sig")
        check("行数 = 9（3 方案 × 3 周期）", len(c) == 9, f"{len(c)}")
        check("列齐全", {"scheme_id", "days", "start_date", "end_date",
                         "cost_total", "risk_eval", "robustness", "paper_ref"} <= set(c.columns))
        check("3 个方案", c["scheme_id"].nunique() == 3, f"{sorted(c['scheme_id'].unique())}")
        check("3 个周期 5/10/30", sorted(c["days"].unique()) == [5, 10, 30],
              f"{sorted(c['days'].unique())}")
        # 窗口必须是同尾窗口（都结束于 8/31）
        check("同尾窗口（全部结束于 2026-08-31）", set(c["end_date"]) == {"2026-08-31"},
              f"{sorted(set(c['end_date']))}")
        exp_start = {5: "2026-08-27", 10: "2026-08-22", 30: "2026-08-02"}
        ok_start = all(row["start_date"] == exp_start[row["days"]] for _, row in c.iterrows())
        check("起始日期与契约一致", ok_start)

    # ---------- 4. 局部最优性 ----------
    print("\n[4] 优化器局部最优性（抽样 15 个时段）")
    df = prepare()
    dates = sorted(df["date"].unique())
    D = dates[-10]                       # 取靠近窗口末尾的一天
    avail = dates[:max(0, dates.index(D) - LOAD_LAG + 1)]
    pool = df[df["date"].isin(avail)]
    rng = np.random.default_rng(0)
    idx = rng.choice(len(pool), size=200, replace=True)
    e_pool = pool["e_load"].to_numpy(float)[idx]
    f_pool = pool["f_spread"].to_numpy(float)[idx]

    lam = dict((k, l) for k, l, _ in SCHEMES)["R2"]
    worse = 0
    sample = df[df["date"] == D].head(15)
    for _, row in sample.iterrows():
        q, obj = optimal_q(row["L_hat"], row["S_hat"], row["pred_da"],
                           row["contract_q"], row["contract_p"], e_pool, f_pool, lam)
        Ls = np.maximum(row["L_hat"] + e_pool, 0.0)
        Ss = row["S_hat"] + f_pool
        for delta in (-2.0, -1.0, 1.0, 2.0):
            qq = max(0.0, q + delta)
            c = scenario_costs(qq, Ls, Ss, row["pred_da"], row["contract_q"], row["contract_p"])
            if c.mean() + lam * cvar(c) < obj - 1e-6:
                worse += 1
    check("q_risk 不劣于邻域点", worse == 0, f"被超越 {worse} 次")

    # ---------- 5. 无前视 ----------
    print("\n[5] 情景池只能用 ≤ D−5 的残差")
    # 与 rolling_sim 内部逻辑保持一致：avail = dates[:pos-LOAD_LAG+1]
    pos = dates.index(D)
    last_avail = avail[-1]
    check("情景池最后一天 = D−5", dates.index(last_avail) == pos - LOAD_LAG,
          f"D={D}, 池末日={last_avail}")

    print("\n" + "=" * 66)
    if FAILS:
        print(f"✘ 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("✔ 问题4 验证全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
