# -*- coding: utf-8 -*-
"""问题3 验证（T3）。

重点：
  1. 无泄漏：价格特征只能用 D-7 及以前（附件4 披露 T+6）
  2. 两法自洽：spread_calc 必须等于 pred_rt − pred_da
  3. 申报自洽：q_bid 必须等于把预测代入问题1 闭式解的结果
  4. 契约：3672 行、键与附件6 模板一致

用法：<venv>/python.exe tests/test_q3.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402

from src.common import fill_att6 as F  # noqa: E402
from src.common import io  # noqa: E402
from src.q3.features import build_price_panel  # noqa: E402
from src.q3.solve import deterministic_bid  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def main():
    print("=" * 66)
    print("问题3 验证")
    print("=" * 66)

    # ---------- 1. 无泄漏 ----------
    print("\n[1] 时间闸门：价格特征只能来自 D-7 及以前")
    panel = build_price_panel()
    dates = sorted(panel["date"].unique())
    errs = []
    sample = panel.dropna(subset=["da_lag7", "da_lag14"]).sample(60, random_state=1)
    for _, r in sample.iterrows():
        i = dates.index(r["date"])
        if i < 15:
            continue
        for k, col in ((7, "da_lag7"), (14, "da_lag14")):
            ref = panel[(panel["date"] == dates[i - k]) & (panel["hour"] == r["hour"])]["price_da"]
            if len(ref) and abs(float(ref.iloc[0]) - float(r[col])) > 1e-6:
                errs.append((r["date"], r["hour"], col))
    check("da_lag7 / da_lag14 与 D-7 / D-14 实际价格对上", not errs, f"不符 {len(errs)} 处")

    # 历史价差必须由已知价格算出
    d_ok = (panel["s_lag7"] - (panel["rt_lag7"] - panel["da_lag7"])).abs().max()
    check("s_lag7 = rt_lag7 − da_lag7", float(d_ok) < 1e-9, f"最大差 {d_ok:.2e}")

    # 确认 7 天是最短可用滞后：若用 6 天就会泄漏（D-6 的价格在 D-1 时还没披露）
    check("滞留下界为 7 天（D-6 尚未披露）", "da_lag7" in panel.columns and "da_lag6" not in panel.columns)

    # ---------- 2. 契约 ----------
    print("\n[2] 输出契约")
    path = os.path.join(OUT, "q3_price_bid.csv")
    check("q3_price_bid.csv 存在", os.path.exists(path))
    if os.path.exists(path):
        q = pd.read_csv(path, encoding="utf-8-sig")
        check("行数 = 3672", len(q) == 3672, f"{len(q)}")
        need = ["date", "hour", "pred_da", "pred_rt", "pred_spread_direct",
                "pred_spread_calc", "pred_spread_final", "q_bid", "note"]
        check("列齐全", all(c in q.columns for c in need))
        check("无缺失值", not q[need[2:8]].isna().any().any())
        check("申报量非负", bool((q["q_bid"] >= 0).all()))
        check("申报量量级合理", bool((q["q_bid"] < 1000).all()))

        wb = load_workbook(F.DEFAULT_TEMPLATE, data_only=True)
        ws = wb["问题3_价格预测与申报"]
        tpl = {(str(ws.cell(r, 1).value)[:10], F.text_to_hour(ws.cell(r, 2).value))
               for r in range(4, 3676)}
        got = set(zip(q["date"], q["hour"]))
        check("键与模板预填完全一致", got == tpl,
              f"缺 {len(tpl - got)} 个，多 {len(got - tpl)} 个")

    # ---------- 3. 两法自洽 ----------
    print("\n[3] 价差两法自洽")
    if os.path.exists(path):
        diff = (q["pred_spread_calc"] - (q["pred_rt"] - q["pred_da"])).abs().max()
        # CSV 保留 4 位小数，故容差取 1e-3（远小于任何有意义的价格差异）
        check("spread_calc == pred_rt − pred_da", float(diff) < 1e-3, f"最大差 {diff:.2e}")
        eq = [(q["pred_spread_final"] - q[c]).abs().max() < 1e-9
              for c in ("pred_spread_direct", "pred_spread_calc")]
        check("spread_final 等于两法之一", any(eq),
              f"匹配 {[c for c, e in zip(['direct', 'calc'], eq) if e]}")

    # ---------- 4. 申报自洽 ----------
    print("\n[4] 申报量必须 = 把预测代入问题1 闭式解")
    q2p = os.path.join(OUT, "q2_forecast.csv")
    if os.path.exists(path) and os.path.exists(q2p):
        q2 = pd.read_csv(q2p, encoding="utf-8-sig")[["date", "hour", "pred_final"]]
        a5 = io.load_attachments()["att5"]
        m = (q.merge(q2, on=["date", "hour"]).merge(a5[["date", "hour", "contract_q"]],
                                                    on=["date", "hour"]))
        recomputed = deterministic_bid(m["pred_final"].to_numpy(float),
                                       m["pred_spread_final"].to_numpy(float),
                                       m["contract_q"].to_numpy(float))
        gap = float(np.abs(recomputed - m["q_bid"].to_numpy(float)).max())
        check("q_bid 与闭式解一致", gap < 1e-3, f"最大差 {gap:.2e}")

        # 结构：S>0 时 q ≥ 1.2L̂；S<0 时 q ≤ 0.8L̂
        Lh = m["pred_final"].to_numpy(float)
        Sh = m["pred_spread_final"].to_numpy(float)
        qb = m["q_bid"].to_numpy(float)
        up = Sh > 1e-9
        dn = Sh < -1e-9
        ok_up = bool((qb[up] >= 1.2 * Lh[up] - 1e-3).all())
        ok_dn = bool((qb[dn] <= 0.8 * Lh[dn] + 1e-3).all())
        check("结构性质（S>0 多报 / S<0 少报）", ok_up and ok_dn,
              f"S>0 {up.sum()} 个 / S<0 {dn.sum()} 个")

    # ---------- 5. 经济效果表 ----------
    print("\n[5] 经济效果产出")
    ep = os.path.join(OUT, "q3_econ.csv")
    check("q3_econ.csv 存在", os.path.exists(ep))
    if os.path.exists(ep):
        e = pd.read_csv(ep, encoding="utf-8-sig")
        check("含 3 个方案（本文 / 两个基准）", len(e) == 3, f"{len(e)} 行")
        check("含成本与决策损失列",
              {"方案", "总成本", "相对基准1_节省", "相对基准2_决策损失"} <= set(e.columns))

    print("\n" + "=" * 66)
    if FAILS:
        print(f"✘ 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("✔ 问题3 验证全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
