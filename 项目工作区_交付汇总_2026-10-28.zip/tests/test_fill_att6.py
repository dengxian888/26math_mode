# -*- coding: utf-8 -*-
"""T0.3 填表器测试：用合成数据验证契约与填表逻辑。

覆盖：
  正例 —— 5 个 CSV + summary.json 全部合法 → 11136 行明细 + 9 行周期 + 汇总指标；
          回读 xlsx 校验写入位置与数值正确。
  负例 —— 行数不符 / 键缺失 / 问题1 成本不闭合 / 问题3 价差不闭合 → 必须抛 ContractError。

用法：<venv>/python.exe tests/test_fill_att6.py
"""
import json
import os
import shutil
import sys
import tempfile

from openpyxl import load_workbook

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.common import fill_att6 as F  # noqa: E402

FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def template_keys(n, sheet):
    """从模板里读出预填的 (date, hour) 序列，保证合成数据与模板键完全一致。"""
    wb = load_workbook(F.DEFAULT_TEMPLATE, data_only=True)
    ws = wb[sheet]
    out = []
    for r in range(4, 4 + n):
        out.append((str(ws.cell(r, 1).value)[:10], F.text_to_hour(ws.cell(r, 2).value)))
    return out


def make_outputs(d, *, q1_rows=None, drop_key=False, break_q1=False, break_q3=False,
                 shift_key=False):
    """在目录 d 里生成一套合法的上游产出；参数用于制造负例。"""
    import pandas as pd

    # --- Q1 ---
    keys1 = template_keys(120, "问题1_典型日申报")
    rows1 = keys1 if q1_rows is None else keys1[:q1_rows]
    recs = []
    for i, (dt, h) in enumerate(rows1):
        if drop_key and i == 0:
            continue
        if shift_key and i == 0:
            dt = "2026-04-08"   # 行数仍为 120，但键不在模板里
        rec = {"date": dt, "hour": h, "q_bid": 30.0 + i * 0.01,
               "cost_contract": 1000.0, "cost_da_dev": -50.0,
               "cost_rt_dev": -20.0, "cost_recovery": 10.0}
        rec["cost_total"] = (rec["cost_contract"] + rec["cost_da_dev"]
                             + rec["cost_rt_dev"] + rec["cost_recovery"])
        if break_q1 and i == 0:
            rec["cost_total"] += 999.0
        recs.append(rec)
    pd.DataFrame(recs).to_csv(os.path.join(d, "q1_bid.csv"), index=False, encoding="utf-8-sig")

    # --- Q2 ---
    keys2 = template_keys(3672, "问题2_用电量预测")
    pd.DataFrame([{"date": dt, "hour": h, "pred_A": 30.0, "pred_B": 31.0,
                   "pred_C": 32.0, "pred_final": 32.0, "note": "测试"}
                  for dt, h in keys2]).to_csv(
        os.path.join(d, "q2_forecast.csv"), index=False, encoding="utf-8-sig")

    # --- Q3 ---
    recs3 = []
    for dt, h in keys2:
        da, rt = 380.0, 500.0
        calc = rt - da
        if break_q3 and len(recs3) == 0:
            calc += 50.0
        recs3.append({"date": dt, "hour": h, "pred_da": da, "pred_rt": rt,
                      "pred_spread_direct": 120.0, "pred_spread_calc": calc,
                      "pred_spread_final": 120.0, "q_bid": 35.0, "note": "测试"})
    pd.DataFrame(recs3).to_csv(os.path.join(d, "q3_price_bid.csv"),
                               index=False, encoding="utf-8-sig")

    # --- Q4 ---
    pd.DataFrame([{"date": dt, "hour": h, "q_det": 35.0, "q_risk": 34.0,
                   "risk_measure": "CVaR(0.95)", "risk_param": "lambda=0.5",
                   "note": "测试", "scheme_id": "R2"}
                  for dt, h in keys2]).to_csv(
        os.path.join(d, "q4_risk.csv"), index=False, encoding="utf-8-sig")

    # --- 周期结果 9 行 ---
    cyc = []
    for sid in ("R1", "R2", "R3"):
        for days, start in ((5, "2026-08-27"), (10, "2026-08-22"), (30, "2026-08-02")):
            cyc.append({"scheme_id": sid, "days": days, "start_date": start,
                        "end_date": "2026-08-31", "cost_total": 100000.0,
                        "risk_eval": "CVaR=500", "robustness": "稳定",
                        "paper_ref": "§6.3"})
    pd.DataFrame(cyc).to_csv(os.path.join(d, "q4_cycle.csv"),
                             index=False, encoding="utf-8-sig")

    # --- summary.json ---
    days1 = sorted({dt for dt, _ in keys1})
    summary = {
        "q1_cost": [{"date": dt, "energy_cost": 1.0, "recovery": 2.0,
                     "total": 3.0, "note": "测试"} for dt in days1],
        "q2_metrics": [
            {"_key": "A", "mae": 3.1, "rmse": 4.2, "wmape": 0.08, "other_name": "MAPE",
             "other_value": 0.09, "note": "仅历史"},
            {"_key": "B", "mae": 2.8, "rmse": 3.9, "wmape": 0.07, "other_name": "MAPE",
             "other_value": 0.08, "note": "+预测信息"},
            {"_key": "C", "mae": 2.5, "rmse": 3.5, "wmape": 0.06, "other_name": "MAPE",
             "other_value": 0.07, "note": "+实际信息"},
            {"_key": "final", "mae": 2.5, "rmse": 3.5, "wmape": 0.06, "other_name": "MAPE",
             "other_value": 0.07, "note": "采用方案C"},
        ],
        "q3_price_metrics": [
            {"_key": k, "mae": 10.0, "rmse": 14.0, "other_name": "MAPE",
             "other_value": 0.03, "note": "测试"} for k in ("da", "rt", "spread_direct", "spread_calc")
        ],
        "q3_econ": {"avg_daily_cost": 350000.0, "max_daily_cost": 420000.0,
                    "avg_decision_loss": 15000.0, "other_name": "MAPE",
                    "other_value": 0.03, "note": "相对按合约量申报"},
        "q4_compare": [
            {"_key": "det", "avg_daily_cost": 350000.0, "cost_quantile": 400000.0,
             "max_daily_cost": 460000.0, "tail_name": "CVaR", "tail_value": 440000.0,
             "risk_param": "λ=0", "note": "确定性策略"},
            {"_key": "risk", "avg_daily_cost": 355000.0, "cost_quantile": 385000.0,
             "max_daily_cost": 410000.0, "tail_name": "CVaR", "tail_value": 395000.0,
             "risk_param": "λ=0.5", "note": "风险策略"},
        ],
    }
    json.dump(summary, open(os.path.join(d, "summary.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)


def expect_error(name, fn, *a, **kw):
    try:
        fn(*a, **kw)
    except F.ContractError as e:
        check(name, True, str(e)[:70])
        return
    except Exception as e:  # noqa: BLE001
        check(name, False, f"抛了非契约异常 {type(e).__name__}: {e}")
        return
    check(name, False, "应当报错但没有")


def main():
    print("=" * 66)
    print("T0.3 填表器测试")
    print("=" * 66)

    tmp = tempfile.mkdtemp(prefix="att6_")
    try:
        out = os.path.join(tmp, "outputs")
        os.makedirs(out)
        target = os.path.join(tmp, "附件6_提交版.xlsx")

        # ---------- 正例 ----------
        print("\n[1] 正例：合法数据应完整写入")
        make_outputs(out)
        rep = F.fill_att6(out, F.DEFAULT_TEMPLATE, target)
        check("问题1 写入 120 行", rep["details"]["问题1_典型日申报"] == 120)
        check("问题2 写入 3672 行", rep["details"]["问题2_用电量预测"] == 3672)
        check("问题3 写入 3672 行", rep["details"]["问题3_价格预测与申报"] == 3672)
        check("问题4 写入 3672 行", rep["details"]["问题4_风险申报"] == 3672)
        check("周期结果 写入 9 行", rep["cycle"] == 9)
        check("汇总指标写入非空", rep["summary_cells"] > 0, f"{rep['summary_cells']} 个单元格")

        # 回读校验
        wb = load_workbook(target, data_only=True)
        ws1 = wb["问题1_典型日申报"]
        check("问题1 首行申报量正确", abs(ws1.cell(4, 3).value - 30.0) < 1e-9,
              f"C4={ws1.cell(4, 3).value}")
        check("问题1 末行已填", ws1.cell(123, 8).value is not None,
              f"H123={ws1.cell(123, 8).value}")
        check("问题1 日期列未被改写", str(ws1.cell(4, 1).value)[:10] == "2026-04-07",
              f"A4={ws1.cell(4, 1).value}")

        ws2 = wb["问题2_用电量预测"]
        check("问题2 说明列已填", ws2.cell(4, 7).value == "测试")
        check("问题2 末行已填", ws2.cell(3675, 6).value is not None)

        ws3 = wb["问题3_价格预测与申报"]
        check("问题3 申报量已填", abs(ws3.cell(4, 8).value - 35.0) < 1e-9)

        ws4 = wb["问题4_风险申报"]
        check("问题4 方案编号已填", ws4.cell(4, 8).value == "R2")

        wsc = wb["问题4_周期结果"]
        check("周期结果首行已填", wsc.cell(4, 1).value == "R1" and wsc.cell(4, 2).value == 5.0,
              f"A4={wsc.cell(4,1).value} B4={wsc.cell(4,2).value}")
        check("周期结果第 9 行已填", wsc.cell(12, 1).value == "R3")

        wsm = wb["汇总指标"]
        check("汇总指标 问题1 首日已填", wsm.cell(5, 2).value is not None)
        check("汇总指标 问题2 方案A已填", wsm.cell(13, 2).value is not None)
        check("汇总指标 问题4 风险策略已填", wsm.cell(33, 2).value is not None)

        # 完整性：明细 sheet 不应有空白单元格（C 列起）
        blanks = 0
        for sheet, spec in F.DETAILS.items():
            ws = wb[sheet]
            last_col = max(list(spec["cols"]) + list(spec["text_cols"]))
            for r in range(4, 4 + spec["n"]):
                for c in range(3, last_col + 1):
                    if ws.cell(r, c).value in (None, ""):
                        blanks += 1
        check("明细表无空白单元格", blanks == 0, f"空白 {blanks} 个")

        # ---------- 负例 ----------
        print("\n[2] 负例：契约违规必须报错")
        for label, kwargs in (
            ("行数不符（截断 10 行）", dict(q1_rows=110)),
            ("键缺失（少一行）", dict(drop_key=True)),
            ("键不匹配（行数对但日期错）", dict(shift_key=True)),
            ("问题1 成本不闭合", dict(break_q1=True)),
            ("问题3 价差不闭合", dict(break_q3=True)),
        ):
            d2 = os.path.join(tmp, "neg_" + str(abs(hash(label)) % 1000))
            os.makedirs(d2, exist_ok=True)
            make_outputs(d2, **kwargs)
            expect_error(f"  {label}", F.fill_att6, d2, F.DEFAULT_TEMPLATE,
                         os.path.join(tmp, "neg.xlsx"))

        # 缺文件
        d3 = os.path.join(tmp, "empty")
        os.makedirs(d3)
        expect_error("  缺少上游产出文件", F.fill_att6, d3, F.DEFAULT_TEMPLATE,
                     os.path.join(tmp, "neg2.xlsx"))

    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n" + "=" * 66)
    if FAILS:
        print(f"✘ 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("✔ T0.3 填表器测试全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
