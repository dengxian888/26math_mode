# -*- coding: utf-8 -*-
import numpy as np, pandas as pd
from settle import load_inputs
m,_ = load_inputs("..")
piv = m.pivot_table(index="date", columns="hour", values="load_actual")
win = [x for x in piv.index if x >= "2026-04-01"]
for lag in [1, 7]:
    d = (piv.shift(lag) - piv).loc[win].values
    print(f"load 持续性 lag {lag}d  MAE(窗口内) = {np.nanmean(np.abs(d)):.4f}")
idx = list(piv.index); preds = {}
for i, dt in enumerate(idx):
    if i < 28: continue
    preds[dt] = piv.iloc[i-28:i].mean().values
p = pd.DataFrame(preds).T.stack(); a = piv.stack()
cm = sorted(set(p.index) & set(a.index))
cmw = [x for x in cm if x[0] >= "2026-04-01"]
print(f"load 28天同时段均值(不分日类型) MAE(窗口内) = {np.mean(np.abs(p.loc[cmw].values - a.loc[cmw].values)):.4f}")
print(f"load 28天同时段均值(不分日类型) MAE(全样本) = {np.mean(np.abs(p.loc[cm].values - a.loc[cm].values)):.4f}")
# 日类型匹配版（同 day_type 近28天同时段均值）
dt = m.drop_duplicates("date").set_index("date")["day_type"]
preds2 = {}
for i, d0 in enumerate(idx):
    if i < 28: continue
    w = piv.iloc[max(0,i-28):i]
    tp = dt.loc[w.index]
    sel = w[tp == dt.loc[d0]]
    preds2[d0] = (sel.mean() if len(sel) else w.mean()).values
p2 = pd.DataFrame(preds2).T.stack()
c2 = [x for x in sorted(set(p2.index) & set(a.index)) if x[0] >= "2026-04-01"]
print(f"load 同类型28天同时段均值 MAE(窗口内) = {np.mean(np.abs(p2.loc[c2].values - a.loc[c2].values)):.4f}  (被检验 baseline 声称 3.4360)")
