# -*- coding: utf-8 -*-
"""守法约束下的用电量朴素基准（附件2 实际用电 D+4 才披露 => 决策日 D-1 时最新可得为 D-5）"""
import numpy as np, pandas as pd
a2 = pd.read_csv("../data/interim/att2_用电量.csv")
piv = a2.pivot_table(index="date", columns="hour", values="load_actual")
dt = a2.drop_duplicates("date").set_index("date")["day_type"]
idx = list(piv.index); act = piv.stack()
def run(off_end, span, match_type):
    preds = {}
    for i, d0 in enumerate(idx):
        lo, hi = i - off_end - span, i - off_end
        if lo < 0: continue
        w = piv.iloc[lo:hi]
        if match_type:
            tp = dt.loc[w.index]; sel = w[tp == dt.loc[d0]]
            if len(sel) == 0: sel = w
        else:
            sel = w
        preds[d0] = sel.mean().values
    p = pd.DataFrame(preds).T.stack()
    cm = [x for x in sorted(set(p.index) & set(act.index)) if x[0] >= "2026-04-01"]
    return np.mean(np.abs(p.loc[cm].values - act.loc[cm].values)), len(cm)
for off in [0, 4]:
    for span in [28]:
        for mt in [False, True]:
            v, n = run(off, span, mt)
            print(f"窗口=前{span}天(末端再前移{off}天) 日类型匹配={mt}: MAE={v:.4f} (n={n})")
print("\n方案A 声称 3.2234；被检验 baseline 声称 3.4360")
