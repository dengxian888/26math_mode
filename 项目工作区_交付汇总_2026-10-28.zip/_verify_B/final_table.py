# -*- coding: utf-8 -*-
import numpy as np, pandas as pd
from settle import settle_hourly, load_inputs
m, a1 = load_inputs("..")
W = m[(m.date>="2026-04-01")&(m.date<="2026-08-31")].reset_index(drop=True)
d2 = W.merge(pd.read_csv("../outputs/q2_forecast.csv"), on=["date","hour"])
d3 = W.merge(pd.read_csv("../outputs/q3_price_bid.csv"), on=["date","hour"])
d4 = W.merge(pd.read_csv("../outputs/q4_risk.csv")[["date","hour","q_det","q_risk"]], on=["date","hour"])
S = (d3.price_rt-d3.price_da).values
def M(p,y):
    e=p-y; return np.mean(np.abs(e)), np.sqrt(np.mean(e**2)), np.sum(np.abs(e))/np.sum(np.abs(y))*100, np.mean(np.abs(e)/np.abs(y))*100
rows=[]
def add(no,item,mine,claim,unit):
    if claim==0 and mine==0: rel=0.0
    else: rel=(mine-claim)/abs(claim)*100
    v="PASS" if abs(rel)<=5 else ("SUSPECT" if abs(rel)<=15 else "FAIL")
    rows.append(dict(no=no,item=item,mine=mine,claim=claim,rel=rel,verdict=v,unit=unit))
B=[("方案A","pred_A"),("方案B","pred_B"),("方案C","pred_C"),("pred_final","pred_final")]
claimsB={"pred_A":3.2234,"pred_B":2.4912,"pred_C":2.4560,"pred_final":2.4560}
for nm,c in B:
    mae,rmse,wm,mp = M(d2[c].values, d2.load_actual.values)
    add("B", f"问题2 {nm} MAE={claimsB[c]}", mae, claimsB[c], "MWh")
claimsC={"pred_da":70.93,"pred_rt":123.64,"pred_spread_direct":96.66,"pred_spread_calc":108.76}
for c,cl in claimsC.items():
    y = S if "spread" in c else (d3.price_da.values if c=="pred_da" else d3.price_rt.values)
    mae,rmse,wm,mp = M(d3[c].values,y)
    add("C", f"问题3 {c} MAE={cl}", mae, cl, "元/MWh")
t_det=settle_hourly(d3.q_bid,d3.contract_q,d3.contract_p,d3.load_actual,d3.price_da,d3.price_rt).cost_total.sum()
t_base=settle_hourly(d3.contract_q,d3.contract_q,d3.contract_p,d3.load_actual,d3.price_da,d3.price_rt).cost_total.sum()
add("D","问题3 确定性申报总成本",t_det,59431154.68,"元")
add("D","问题3 按合约量申报(对照)",t_base,59056081.09,"元")
r_risk=settle_hourly(d4.q_risk,d4.contract_q,d4.contract_p,d4.load_actual,d4.price_da,d4.price_rt)
r_det=settle_hourly(d4.q_det,d4.contract_q,d4.contract_p,d4.load_actual,d4.price_da,d4.price_rt)
add("E","问题4 q_risk 总成本",r_risk.cost_total.sum(),58283747.74,"元")
add("E","问题4 q_det 总成本",r_det.cost_total.sum(),59431154.68,"元")
g_risk=r_risk.groupby(d4.date.values).cost_total.sum()
for d,(s,e) in {5:("2026-08-27","2026-08-31"),10:("2026-08-22","2026-08-31"),30:("2026-08-02","2026-08-31")}.items():
    cl={5:1806480.67,10:3573451.28,30:10862017.21}[d]
    add("E",f"问题4 周期 R2 {d}天 窗口成本",g_risk.loc[s:e].sum(),cl,"元")
tab=pd.DataFrame(rows)
print(tab.to_string(index=False, float_format=lambda x:f"{x:,.4f}"))
print("\n合计:", tab.verdict.value_counts().to_dict())
tab.to_csv("final_compare.csv", index=False, encoding="utf-8-sig")
