# -*- coding: utf-8 -*-
"""补充诊断：价差符号结构、带宽极端申报、朴素价格基准"""
import numpy as np, pandas as pd
from settle import settle_hourly, load_inputs
m,_ = load_inputs("..")
W = m[(m.date>="2026-04-01")&(m.date<="2026-08-31")].reset_index(drop=True)
f3 = pd.read_csv("../outputs/q3_price_bid.csv"); d = W.merge(f3, on=["date","hour"])
f4 = pd.read_csv("../outputs/q4_risk.csv"); d4 = W.merge(f4[["date","hour","q_det","q_risk"]], on=["date","hour"])
S = d.price_rt - d.price_da
print("== 价差 S=RT-DA 的结构 ==")
print(f"  mean={S.mean():.2f} median={np.median(S):.2f} std={S.std():.2f} "
      f"P(S>0)={np.mean(S>0)*100:.1f}%  sum(S>0)={S[S>0].sum():,.0f}  sum(S<0)={S[S<0].sum():,.0f}")
print(f"  分位 5/25/50/75/95: {np.percentile(S,[5,25,50,75,95]).round(1)}")
print(f"  若某策略'永久押注 S>0'，其期望每人时收益 = mean(S) = {S.mean():.2f} 元/MWh")

def tot(q):
    return settle_hourly(q, d.contract_q, d.contract_p, d.load_actual, d.price_da, d.price_rt).cost_total.sum()
base = tot(d.contract_q)
print("\n== 不同申报规则的 153 天事后结算总成本 ==")
cands = {
    "按合约量申报": d.contract_q.values,
    "恒报 1.2L（永久押注 RT>DA）": 1.2*d.load_actual.values,
    "恒报 0.8L（反向押注）": 0.8*d.load_actual.values,
    "问题3 确定性 q_bid": d.q_bid.values,
    "问题4 q_risk": d4.q_risk.values,
    "完全信息最优 (1.2L if S>0 else 0.8L)": np.where(S>0,1.2*d.load_actual,0.8*d.load_actual),
}
for k, q in cands.items():
    print(f"  {k:38s} {tot(q):16,.2f}   相对按合约量 {tot(q)-base:+14,.2f}")
print(f"  实测用电量作为申报(L)：{tot(d.load_actual.values):,.2f}（完美用电预测、无价格信息）")

print("\n== 价格预测朴素基准（检验 70.93/123.64 是否可信）==")
piv_da = m.pivot_table(index="date", columns="hour", values="price_da")
piv_rt = m.pivot_table(index="date", columns="hour", values="price_rt")
wmask = (piv_da.index >= "2026-04-01")
for nm, piv in [("DA", piv_da), ("RT", piv_rt)]:
    for lag in [1, 7]:
        e = (piv.shift(lag) - piv).abs()
        e = e.loc[wmask].values.ravel(); e = e[~np.isnan(e)]
        print(f"  {nm} 持续性(lag {lag}d) MAE = {e.mean():.3f}")
    # 28天同时段均值
    preds = {}
    idx = list(piv.index)
    for i, dt in enumerate(idx):
        if i < 28: continue
        preds[dt] = piv.iloc[i-28:i].mean().values
    p = pd.DataFrame(preds).T.stack(); a = piv.stack()
    cm = p.index.intersection(a.index)
    cm = [x for x in cm if x[0] >= "2026-04-01"]
    print(f"  {nm} 28天同时段均值 MAE = {np.mean(np.abs(p.loc[cm].values-a.loc[cm].values)):.3f}")

print("\n== Q2/Q3 预测的时段均值剖面是否合理（是否只是常数/均值回归）==")
print("  pred_da 与 实测DA 均值: %.1f / %.1f ; std: %.1f / %.1f" %
      (d.pred_da.mean(), d.price_da.mean(), d.pred_da.std(), d.price_da.std()))
print("  pred_rt 与 实测RT 均值: %.1f / %.1f ; std: %.1f / %.1f" %
      (d.pred_rt.mean(), d.price_rt.mean(), d.pred_rt.std(), d.price_rt.std()))
print("  pred_spread_direct 与 实测S 均值: %.1f / %.1f ; std: %.1f / %.1f" %
      (d.pred_spread_direct.mean(), S.mean(), d.pred_spread_direct.std(), S.std()))
# 分钟级：q_bid 与 q_risk 差
print("\n  q_risk 比 q_det 大的时段占比: %.1f%% ; 两者相等占比: %.1f%%" %
      (np.mean(d4.q_risk > d4.q_det+1e-9)*100, np.mean(np.abs(d4.q_risk-d4.q_det)<1e-9)*100))
print("  q_risk 相对 1.2L 的位置: q_risk/1.2L 中位数 = %.3f" % np.median(d4.q_risk/(1.2*d4.load_actual)))
print("  q_risk == 1.2L(±1e-6) 的时段占比 = %.1f%%" % (np.mean(np.abs(d4.q_risk-1.2*d4.load_actual)<1e-6)*100))
