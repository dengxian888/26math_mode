# -*- coding: utf-8 -*-
import json, numpy as np, pandas as pd
from settle import settle_hourly, load_inputs, settle_frame

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 80)
R = {}
m, a1 = load_inputs("..")
print("实测数据行数:", len(m), " 日期范围:", m.date.min(), "->", m.date.max(),
      " 天数:", m.date.nunique())
W = m[(m.date >= "2026-04-01") & (m.date <= "2026-08-31")].reset_index(drop=True)
print("评估窗口行数:", len(W), "天数:", W.date.nunique())

# ===================== B: 问题2 预测指标 =====================
print("\n" + "=" * 70, "\nB. 问题2 预测指标\n")
f2 = pd.read_csv("../outputs/q2_forecast.csv")
print("q2_forecast 行数:", len(f2), "列:", list(f2.columns))
d2 = W.merge(f2[["date", "hour", "pred_A", "pred_B", "pred_C", "pred_final"]],
             on=["date", "hour"], how="left")
print("merge 后缺失:", d2[["pred_A", "pred_B", "pred_C", "pred_final"]].isna().sum().to_dict())

def metrics(pred, act):
    e = pred - act
    return dict(MAE=np.mean(np.abs(e)), RMSE=np.sqrt(np.mean(e ** 2)),
                WMAPE=np.sum(np.abs(e)) / np.sum(np.abs(act)) * 100,
                MAPE=np.mean(np.abs(e) / np.abs(act)) * 100)

rows = []
for s in ["pred_A", "pred_B", "pred_C", "pred_final"]:
    mm = metrics(d2[s].values, d2["load_actual"].values)
    mm["scheme"] = s
    rows.append(mm)
t2 = pd.DataFrame(rows)[["scheme", "MAE", "RMSE", "WMAPE", "MAPE"]]
print(t2.to_string(index=False))
R["B_mine"] = {r["scheme"]: {k: float(r[k]) for k in ["MAE", "RMSE", "WMAPE", "MAPE"]} for r in rows}

# 仅 153 个整日中的前/后段检查：是否 pred_final == pred_C
print("pred_final 与 pred_C 完全相等的行数:", int((d2.pred_final - d2.pred_C).abs().max() == 0),
      " max|final-C| =", float((d2.pred_final - d2.pred_C).abs().max()))

# ===================== C: 问题3 价格指标 =====================
print("\n" + "=" * 70, "\nC. 问题3 价格预测指标\n")
f3 = pd.read_csv("../outputs/q3_price_bid.csv")
print("q3_price_bid 行数:", len(f3))
d3 = W.merge(f3, on=["date", "hour"], how="left")
print("merge 后缺失:", d3[["pred_da", "pred_rt", "pred_spread_direct", "pred_spread_calc"]].isna().sum().to_dict())
d3["act_spread"] = d3["price_rt"] - d3["price_da"]
print("实测价差(rt-da) 均值 %.4f, 直接预测价差均值 %.4f, 相减预测均值 %.4f" %
      (d3.act_spread.mean(), d3.pred_spread_direct.mean(), d3.pred_spread_calc.mean()))
print("内部一致性 max|pred_spread_calc-(pred_rt-pred_da)| =",
      float((d3.pred_spread_calc - (d3.pred_rt - d3.pred_da)).abs().max()))
c_rows = []
for name, pred in [("pred_da vs price_da", d3.pred_da),
                   ("pred_rt vs price_rt", d3.pred_rt),
                   ("pred_spread_direct vs act_spread", d3.pred_spread_direct),
                   ("pred_spread_calc vs act_spread", d3.pred_spread_calc)]:
    mm = metrics(pred.values, d3["price_da"].values if "price_da" in name else
                 (d3["price_rt"].values if "price_rt" in name else d3["act_spread"].values))
    mm["item"] = name
    c_rows.append(mm)
t3 = pd.DataFrame(c_rows)[["item", "MAE", "RMSE", "WMAPE", "MAPE"]]
print(t3.to_string(index=False))
R["C_mine"] = {r["item"]: {k: float(r[k]) for k in ["MAE", "RMSE", "MAPE"]} for r in c_rows}

# ===================== D: 问题3 经济效果 =====================
print("\n" + "=" * 70, "\nD. 问题3 事后结算（153 天）\n")
d3["contract_q"] = d3["contract_q"]; d3["contract_q_x"] = d3["contract_q"]
res_det = settle_frame(d3, "q_bid")
res_base_q = settle_frame(d3, "contract_q")
# 手工：
for nm, qcol in [("q_bid", "q_bid"), ("contract_q(基准①)", "contract_q")]:
    r = settle_hourly(d3[qcol], d3["contract_q"], d3["contract_p"], d3["load_actual"],
                      d3["price_da"], d3["price_rt"])
    tot = r["cost_total"].sum()
    print(f"{nm:22s} 总成本 = {tot:,.2f}   合约={r.cost_contract.sum():,.2f} "
          f"日前偏差={r.cost_da_dev.sum():,.2f} 实时偏差={r.cost_rt_dev.sum():,.2f} 回收={r.cost_recovery.sum():,.2f}")
    R.setdefault("D_mine", {})[nm] = float(tot)
dd = d3.groupby("date").apply(lambda g: pd.Series({
    "cost": settle_hourly(g["q_bid"], g["contract_q"], g["contract_p"], g["load_actual"],
                          g["price_da"], g["price_rt"])["cost_total"].sum()}), include_groups=False)
print("日均成本 = %.2f  最大单日 = %.2f  最小单日 = %.2f  天数 = %d" %
      (dd.cost.mean(), dd.cost.max(), dd.cost.min(), len(dd)))
R["D_daily"] = {"avg": float(dd.cost.mean()), "max": float(dd.cost.max()), "n_days": int(len(dd))}

# 完全信息最优基准②（用实测值求解闭式）；仅作参考量级
print("\n（参考）被检验方 q3_econ 三行：")
print(pd.read_csv("../outputs/q3_econ.csv").to_string(index=False))

# ===================== E: 问题4 =====================
print("\n" + "=" * 70, "\nE. 问题4 申报结算\n")
f4 = pd.read_csv("../outputs/q4_risk.csv")
print("q4_risk 行数:", len(f4), " scheme_id 唯一值:", f4.scheme_id.unique(),
      " risk_measure:", f4.risk_measure.unique(), " risk_param:", f4.risk_param.unique())
d4 = W.merge(f4[["date", "hour", "q_det", "q_risk"]], on=["date", "hour"], how="left")
print("merge 后缺失:", d4[["q_det", "q_risk"]].isna().sum().to_dict())
print("max|q_det - q3.q_bid| =", float((d4.q_det - d3.q_bid).abs().max()))
for nm in ["q_risk", "q_det"]:
    r = settle_hourly(d4[nm], d4["contract_q"], d4["contract_p"], d4["load_actual"],
                      d4["price_da"], d4["price_rt"])
    print(f"{nm:8s} 总成本 = {r['cost_total'].sum():,.2f}  日均 = {r['cost_total'].sum()/153:,.2f} "
          f" 最大单日 = {r.groupby(d4.date.values)['cost_total'].sum().max():,.2f}"
          f" 回收 = {r['cost_recovery'].sum():,.2f}")
    R.setdefault("E_mine", {})[nm] = float(r["cost_total"].sum())
    if nm == "q_risk":
        daily_risk = r.groupby(d4.date.values)["cost_total"].sum()
    else:
        daily_det = r.groupby(d4.date.values)["cost_total"].sum()

print("\n-- q4_cycle 窗口求和核对（注意：R1/R3 无逐时段 q 数据，只能核 R2）--")
cyc = pd.read_csv("../outputs/q4_cycle.csv")
print(cyc[["scheme_id", "days", "start_date", "end_date", "cost_total"]].to_string(index=False))
for _, row in cyc.iterrows():
    s, e = row.start_date, row.end_date
    mine = None
    if row.scheme_id == "R2":
        mine = float(daily_risk.loc[s:e].sum())
    elif row.scheme_id == "R2det":
        mine = float(daily_det.loc[s:e].sum())
    # 全部方案用 q_det / q_risk 里能拿到的
    alt_det = float(daily_det.loc[s:e].sum())
    alt_risk = float(daily_risk.loc[s:e].sum())
    print(f"{row.scheme_id:3s} {row.days:2d}d claimed={row.cost_total:14,.2f} | R2(q_risk)={alt_risk:14,.2f} "
          f"| det(q_det)={alt_det:14,.2f} | diff_R2={alt_risk-row.cost_total:12,.2f}")
    R.setdefault("E_cycle", []).append(dict(scheme=row.scheme_id, days=int(row.days),
        claimed=float(row.cost_total), mine_if_R2=alt_risk, mine_det=alt_det))
print("\nR2 rel = (mine-claim)/claim :")
for c in R["E_cycle"]:
    if c["scheme"] == "R2":
        print(f"  {c['days']:2d}d  {c['mine_if_R2']:,.2f} vs {c['claimed']:,.2f}  "
              f"rel={100*(c['mine_if_R2']-c['claimed'])/c['claimed']:+.4f}%")

# risk_eval 文本内部一致性
import re
print("\n-- q4_cycle risk_eval/robustness 文本自洽性 --")
for _, row in cyc.iterrows():
    t = row.risk_eval
    m1 = re.search(r"日均 ([\d,\.]+)", t); m2 = re.search(r"标准差 ([\d,\.]+)", t)
    avg = float(m1.group(1).replace(",", "")) if m1 else np.nan
    sd = float(m2.group(1).replace(",", "")) if m2 else np.nan
    exp_avg = row.cost_total / row.days
    flag = "OK" if abs(avg - exp_avg) < 0.01 else "MISMATCH"
    print(f"{row.scheme_id:3s}{row.days:2d}d  claimed日均={avg:12,.2f} cost_total/days={exp_avg:12,.2f} -> {flag}"
          f" | 标准差={sd:,}")
    if row.scheme_id == "R2":
        print(f"        我算的窗口日均={daily_risk.loc[row.start_date:row.end_date].mean():12,.2f}"
              f" 标准差={daily_risk.loc[row.start_date:row.end_date].std(ddof=1):12,.2f}")

json.dump(R, open("verify_bcd.json", "w"), ensure_ascii=False, indent=1)
print("\n已写 verify_bcd.json")
