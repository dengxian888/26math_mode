# -*- coding: utf-8 -*-
"""G. summary.json / q*_metrics 全部对外数字 vs 我的重算；以及可疑点诊断"""
import json, numpy as np, pandas as pd
from settle import settle_hourly, load_inputs
m, a1 = load_inputs("..")
W = m[(m.date >= "2026-04-01") & (m.date <= "2026-08-31")].reset_index(drop=True)
f2 = pd.read_csv("../outputs/q2_forecast.csv"); f3 = pd.read_csv("../outputs/q3_price_bid.csv")
f4 = pd.read_csv("../outputs/q4_risk.csv")
d2 = W.merge(f2, on=["date", "hour"]); d3 = W.merge(f3, on=["date", "hour"])
d4 = W.merge(f4[["date", "hour", "q_det", "q_risk"]], on=["date", "hour"])
summ = json.load(open("../outputs/summary.json", encoding="utf-8"))
q2m = pd.read_csv("../outputs/q2_metrics.csv"); q3m = pd.read_csv("../outputs/q3_metrics.csv")
q3e = pd.read_csv("../outputs/q3_econ.csv")

def M(p, y):
    e = p - y
    return dict(MAE=np.mean(np.abs(e)), RMSE=np.sqrt(np.mean(e ** 2)),
                WMAPE=np.sum(np.abs(e)) / np.sum(np.abs(y)) * 100,
                MAPE=np.mean(np.abs(e) / np.abs(y)) * 100)

rows = []
def add(item, mine, claim, unit=""):
    diff = (mine - claim)
    rel = diff / abs(claim) * 100 if claim else np.nan
    verdict = "PASS" if abs(rel) <= 5 else ("SUSPECT" if abs(rel) <= 15 else "FAIL")
    rows.append(dict(item=item, mine=mine, claim=claim, diff=diff, rel_pct=rel, verdict=verdict, unit=unit))

# Q2
for s, key in [("pred_A", "A"), ("pred_B", "B"), ("pred_C", "C"), ("pred_final", "final")]:
    mm = M(d2[s].values, d2.load_actual.values)
    c = [x for x in summ["q2_metrics"] if x["_key"] == key][0]
    add(f"Q2 {key} MAE", mm["MAE"], c["mae"], "MWh")
for i, (s, key) in enumerate([("pred_A", "A"), ("pred_B", "B"), ("pred_C", "C"), ("pred_final", "final")]):
    mm = M(d2[s].values, d2.load_actual.values)
    c = [x for x in summ["q2_metrics"] if x["_key"] == key][0]
    add(f"Q2 {key} RMSE", mm["RMSE"], c["rmse"], "MWh")
    add(f"Q2 {key} WMAPE", mm["WMAPE"], c["wmape"], "%")
    add(f"Q2 {key} MAPE", mm["MAPE"], c["other_value"], "%")

# Q3 price
act_sp = lambda: (d3.price_rt - d3.price_da).values
tgt = {"da": (d3.pred_da.values, d3.price_da.values, "price_da"),
       "rt": (d3.pred_rt.values, d3.price_rt.values, "price_rt"),
       "spread_direct": (d3.pred_spread_direct.values, act_sp(), "spread_direct"),
       "spread_calc": (d3.pred_spread_calc.values, act_sp(), "spread_calc")}
for k, (p, y, tn) in tgt.items():
    mm = M(p, y)
    c = [x for x in summ["q3_price_metrics"] if x["_key"] == k][0]
    add(f"Q3 {tn} MAE", mm["MAE"], c["mae"], "元/MWh")
    add(f"Q3 {tn} RMSE", mm["RMSE"], c["rmse"], "元/MWh")
    mask = np.abs(y) > 1
    add(f"Q3 {tn} MAPE(|y|>1)", np.mean(np.abs(p - y)[mask] / np.abs(y)[mask]) * 100, c["other_value"], "%")

# Q3 econ
r_det = settle_hourly(d3.q_bid, d3.contract_q, d3.contract_p, d3.load_actual, d3.price_da, d3.price_rt)
r_base = settle_hourly(d3.contract_q, d3.contract_q, d3.contract_p, d3.load_actual, d3.price_da, d3.price_rt)
qs = np.where(d3.price_rt > d3.price_da, 1.2 * d3.load_actual, 0.8 * d3.load_actual)
r_perf = settle_hourly(qs, d3.contract_q, d3.contract_p, d3.load_actual, d3.price_da, d3.price_rt)
tot_det, tot_base, tot_perf = r_det.cost_total.sum(), r_base.cost_total.sum(), r_perf.cost_total.sum()
add("Q3 确定性申报总成本", tot_det, q3e.iloc[0]["总成本"], "元")
add("Q3 按合约量申报(基准①)", tot_base, q3e.iloc[1]["总成本"], "元")
add("Q3 完全信息最优(基准②)", tot_perf, q3e.iloc[2]["总成本"], "元")
add("Q3 相对基准1 节省", tot_det - tot_base, q3e.iloc[0]["相对基准1_节省"], "元")
add("Q3 相对基准2 决策损失", tot_det - tot_perf, q3e.iloc[0]["相对基准2_决策损失"], "元")
g_det = r_det.groupby(d3.date.values).cost_total.sum()
add("Q3 平均日成本", g_det.mean(), summ["q3_econ"][0]["avg_daily_cost"], "元")
add("Q3 最大单日成本", g_det.max(), summ["q3_econ"][0]["max_daily_cost"], "元")
add("Q3 平均决策损失", (tot_det - tot_perf) / 153, summ["q3_econ"][0]["avg_decision_loss"], "元")

# Q4
r_risk = settle_hourly(d4.q_risk, d4.contract_q, d4.contract_p, d4.load_actual, d4.price_da, d4.price_rt)
r_det4 = settle_hourly(d4.q_det, d4.contract_q, d4.contract_p, d4.load_actual, d4.price_da, d4.price_rt)
g_risk = r_risk.groupby(d4.date.values).cost_total.sum()
g_det4 = r_det4.groupby(d4.date.values).cost_total.sum()
add("Q4 q_risk 总成本", r_risk.cost_total.sum(), 58283747.74, "元")
add("Q4 q_det 总成本", r_det4.cost_total.sum(), 59431154.68, "元")
for key, g, c in [("det", g_det4, summ["q4_compare"][0]), ("risk", g_risk, summ["q4_compare"][1])]:
    add(f"Q4 {key} 平均日成本", g.mean(), c["avg_daily_cost"], "元")
    add(f"Q4 {key} 成本分位(90%)", np.quantile(g, 0.9), c["cost_quantile"], "元")
    add(f"Q4 {key} 最大单日", g.max(), c["max_daily_cost"], "元")
    k8 = int(np.ceil(0.05 * len(g)))
    add(f"Q4 {key} CVaR95", np.sort(g)[::-1][:k8].mean(), c["tail_value"], "元")
for c in [dict(scheme="R2", days=5, claimed=1806480.67, window=("2026-08-27", "2026-08-31")),
          dict(scheme="R2", days=10, claimed=3573451.28, window=("2026-08-22", "2026-08-31")),
          dict(scheme="R2", days=30, claimed=10862017.21, window=("2026-08-02", "2026-08-31"))]:
    add(f"Q4 周期 R2 {c['days']}d 成本", g_risk.loc[c["window"][0]:c["window"][1]].sum(), c["claimed"], "元")

# Q1
q1 = pd.read_csv("../outputs/q1_bid.csv"); dq = q1.merge(a1, on=["date", "hour"])
rq = settle_hourly(dq.q_bid, dq.contract_q, dq.contract_p, dq.load_actual, dq.price_da, dq.price_rt)
gq = rq.assign(date=dq.date.values).groupby("date")
for i, c in enumerate(summ["q1_cost"]):
    dt = c["date"]; g = gq.get_group(dt)
    add(f"Q1 {dt} 电能量成本", g[["cost_contract", "cost_da_dev", "cost_rt_dev"]].sum().sum(), c["energy_cost"], "元")
    add(f"Q1 {dt} 回收", g.cost_recovery.sum(), c["recovery"], "元")
    add(f"Q1 {dt} 总成本", g.cost_total.sum(), c["total"], "元")

tab = pd.DataFrame(rows)
pd.set_option("display.width", 220); pd.set_option("display.max_rows", 200)
print(tab.to_string(index=False, float_format=lambda x: f"{x:,.4f}"))
print("\n判定统计:", tab.verdict.value_counts().to_dict())
worst = tab.reindex(tab.rel_pct.abs().sort_values(ascending=False).index).head(6)
print("\n相对差最大的 6 项:\n", worst[["item", "mine", "claim", "diff", "rel_pct"]].to_string(index=False))
tab.to_csv("compare_table.csv", index=False)

print("\n" + "=" * 78, "\n可疑点诊断")
print(f"平均用电 load={d3.load_actual.mean():.3f} MWh/时段；合约量均值={d3.contract_q.mean():.3f}")
print(f"申报量均值: q_bid={d3.q_bid.mean():.3f}  q_det={d4.q_det.mean():.3f}  q_risk={d4.q_risk.mean():.3f}  "
      f"完全信息最优q={qs.mean():.3f}")
print(f"q<0.8L 时段占比: q_bid={np.mean(d3.q_bid<0.8*d3.load_actual)*100:.1f}%  q_risk={np.mean(d4.q_risk<0.8*d4.load_actual)*100:.1f}%")
print(f"q>1.2L 时段占比: q_bid={np.mean(d3.q_bid>1.2*d3.load_actual)*100:.1f}%  q_risk={np.mean(d4.q_risk>1.2*d4.load_actual)*100:.1f}%")
print(f"q 落在带内占比: q_bid={np.mean((d3.q_bid>=0.8*d3.load_actual)&(d3.q_bid<=1.2*d3.load_actual))*100:.1f}%  "
      f"q_risk={np.mean((d4.q_risk>=0.8*d4.load_actual)&(d4.q_risk<=1.2*d4.load_actual))*100:.1f}%")
print(f"实测价差 S=RT-DA: 均值={ (d3.price_rt-d3.price_da).mean():.2f}  P(S>0)={np.mean(d3.price_rt>d3.price_da)*100:.1f}%")
print(f"预测价差(直接)均值={d3.pred_spread_direct.mean():.2f} 与实测价差相关系数={np.corrcoef(d3.pred_spread_direct, d3.price_rt-d3.price_da)[0,1]:.4f}")
print(f"pred_da 与实测 DA 相关系数={np.corrcoef(d3.pred_da, d3.price_da)[0,1]:.4f}; pred_rt~实测RT={np.corrcoef(d3.pred_rt, d3.price_rt)[0,1]:.4f}")
print(f"pred_final 与实测 load 相关系数={np.corrcoef(d2.pred_final, d2.load_actual)[0,1]:.4f}")

print("\n-- Q2 朴素基准（检验 3.22 是否可信，不含泄漏）--")
piv = m.pivot_table(index="date", columns="hour", values="load_actual")
for lag in [1, 7, 14]:
    pred = piv.shift(lag)
    e = (pred - piv).abs().values.ravel(); e = e[~np.isnan(e)]
    print(f"   持续性 pred(D)={lag}天前: MAE={e.mean():.4f}")
# 同类型同时段近28天均值（baseline 声称 3.4360）
dates = sorted(piv.index.tolist())
preds = {}
for i, dt in enumerate(dates):
    if i < 28: continue
    win = piv.iloc[max(0, i - 28):i]
    preds[dt] = win.mean().values
pb = pd.DataFrame(preds).T.stack()
act = piv.stack()
common = pb.index.intersection(act.index)
print(f"   28天同时段均值(全样本): MAE={np.mean(np.abs(pb.loc[common].values-act.loc[common].values)):.4f}")
