# -*- coding: utf-8 -*-
import json, numpy as np, pandas as pd
from settle import load_inputs
m,_ = load_inputs("..")
W = m[(m.date>="2026-04-01")&(m.date<="2026-08-31")].reset_index(drop=True)
f4 = pd.read_csv("../outputs/q4_risk.csv"); d4 = W.merge(f4[["date","hour","q_det","q_risk"]], on=["date","hour"])
from settle import settle_hourly
g = {}
for nm in ["q_det","q_risk"]:
    r = settle_hourly(d4[nm], d4.contract_q, d4.contract_p, d4.load_actual, d4.price_da, d4.price_rt)
    g[nm] = r.groupby(d4.date.values)["cost_total"].sum()
claim = {"q_det": 438469.46, "q_risk": 428432.48}
for nm in g:
    x = g[nm].values
    print(f"### {nm}  声称 cost_quantile={claim[nm]:,.2f}")
    for q in [0.5,0.75,0.8,0.85,0.9,0.925,0.95,0.975,0.99]:
        for meth in ["linear","lower","nearest","higher"]:
            v = np.quantile(x, q, method=meth)
            if abs(v-claim[nm]) < 500:
                print(f"   命中 level={q} method={meth} -> {v:,.2f}")
    print("   常见水平:", {q: round(float(np.quantile(x,q)),2) for q in [0.9,0.95]})
    srt = np.sort(x)[::-1]
    print("   最差8天:", np.round(srt[:8],2))
    print("   最差16天:", np.round(srt[:16],2))
    print("   最差16天均值:", round(srt[:16].mean(),2), " 最差8天均值:", round(srt[:8].mean(),2))
    print("   mean+1.645sd?", round(x.mean()+1.645*x.std(ddof=1),2), " mean+1.96sd:", round(x.mean()+1.96*x.std(ddof=1),2))
