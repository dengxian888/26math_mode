# -*- coding: utf-8 -*-
"""独立实现的逐时段结算（依据赛题 PDF 附录1 原文，不读取 src/）。

每日总购电成本 =
    中长期合约电费  q_c * p_c
  + 日前偏差电费    (q - q_c) * P_DA
  + 实时偏差电费    (L - q)   * P_RT
  + 日前申报偏差收益回收 sum_t R_t

R_t = [ q_t - (1+lam0)L_t ] * S_t          q_t > (1+lam0)L_t 且 S_t > 0
    = [ (1-lam0)L_t - q_t ] * (-S_t)       q_t < (1-lam0)L_t 且 S_t < 0
    = 0                                    其他
其中 S_t = P_RT - P_DA, lam0 = 0.20
"""
import numpy as np
import pandas as pd

LAM0 = 0.20


def settle_hourly(q, q_c, p_c, L, p_da, p_rt, lam0=LAM0):
    """q/q_c/L 为 MWh 数组；p_* 为元/MWh。返回逐时段四项成本 DataFrame。"""
    q = np.asarray(q, dtype=float)
    q_c = np.asarray(q_c, dtype=float)
    p_c = np.asarray(p_c, dtype=float)
    L = np.asarray(L, dtype=float)
    p_da = np.asarray(p_da, dtype=float)
    p_rt = np.asarray(p_rt, dtype=float)

    c_contract = q_c * p_c
    c_da = (q - q_c) * p_da
    c_rt = (L - q) * p_rt

    s = p_rt - p_da
    up = q - (1.0 + lam0) * L
    dn = (1.0 - lam0) * L - q
    rec = np.where((up > 0) & (s > 0), up * s,
          np.where((dn > 0) & (s < 0), dn * (-s), 0.0))

    out = pd.DataFrame({
        "cost_contract": c_contract,
        "cost_da_dev": c_da,
        "cost_rt_dev": c_rt,
        "cost_recovery": rec,
    })
    out["cost_energy"] = out["cost_contract"] + out["cost_da_dev"] + out["cost_rt_dev"]
    out["cost_total"] = out["cost_energy"] + out["cost_recovery"]
    return out


def load_inputs(root="."):
    a2 = pd.read_csv(f"{root}/data/interim/att2_用电量.csv")
    a4 = pd.read_csv(f"{root}/data/interim/att4_价格.csv")
    a5 = pd.read_csv(f"{root}/data/interim/att5_合约.csv")
    a1 = pd.read_csv(f"{root}/data/interim/att1_典型日.csv")
    key = ["date", "hour"]
    m = a2[key + ["load_actual"]].merge(a4[key + ["price_da", "price_rt"]], on=key, how="inner")
    m = m.merge(a5[key + ["contract_q", "contract_p"]], on=key, how="inner")
    m = m.sort_values(key).reset_index(drop=True)
    return m, a1


def settle_frame(df, qcol, lam0=LAM0):
    """df 需含 date,hour,<qcol>,load_actual,price_da,price_rt,contract_q,contract_p"""
    r = settle_hourly(df[qcol], df["contract_q"], df["contract_p"],
                      df["load_actual"], df["price_da"], df["price_rt"], lam0)
    r.insert(0, "hour", df["hour"].values)
    r.insert(0, "date", df["date"].values)
    return r
