# -*- coding: utf-8 -*-
"""F2: 周期结果 sheet 与 q4_cycle 比对；rows 13-23 是否残留；汇总指标说明/备注列；时段列文本格式统计"""
import numpy as np, pandas as pd, openpyxl
wb = openpyxl.load_workbook("../outputs/附件6_提交版.xlsx", data_only=True)
ws = wb["问题4_周期结果"]
print("== 问题4_周期结果 全表 ==")
for r in range(1, 24):
    vals = [ws.cell(row=r, column=c).value for c in range(1, 9)]
    if any(v is not None for v in vals):
        print(f"  r{r}: {vals}")
cyc = pd.read_csv("../outputs/q4_cycle.csv")
print("\n== 与 q4_cycle.csv 比对（E=cost_total, F=risk_eval, G=robustness, H=paper_ref）==")
ok = True
for i in range(9):
    r = 4 + i
    row = [ws.cell(row=r, column=c).value for c in range(1, 9)]
    exp = [cyc.scheme_id[i], cyc.days[i], cyc.start_date[i], cyc.end_date[i], cyc.cost_total[i],
           cyc.risk_eval[i], cyc.robustness[i], cyc.paper_ref[i]]
    diffs = []
    if row[0] != exp[0]: diffs.append(("A", row[0], exp[0]))
    if int(row[1]) != int(exp[1]): diffs.append(("B", row[1], exp[1]))
    if row[2] != exp[2]: diffs.append(("C", row[2], exp[2]))
    if row[3] != exp[3]: diffs.append(("D", row[3], exp[3]))
    if abs(float(row[4]) - float(exp[4])) > 0.01: diffs.append(("E", row[4], exp[4]))
    if str(row[5]) != str(exp[5]): diffs.append(("F", row[5], exp[5]))
    if str(row[6]) != str(exp[6]): diffs.append(("G", row[6], exp[6]))
    if str(row[7]) != str(exp[7]): diffs.append(("H", row[7], exp[7]))
    print(f"  r{r} {row[0]} {row[1]}d: " + ("OK" if not diffs else f"DIFF {diffs}"))
    ok = ok and not diffs

print("\n== 汇总指标：说明/备注列（模板要求的非必填列）==")
ws = wb["汇总指标"]
for r in list(range(5, 10)) + list(range(13, 17)) + list(range(20, 24)) + [27] + [32, 33]:
    cells = {c: ws.cell(row=r, column=c).value for c in range(1, 9)}
    filled = {k: v for k, v in cells.items() if v is not None}
    print(f"  r{r}: {filled}")

print("\n== 各 sheet 时段列文本格式检查（全部 3672/120 行）==")
for name, nc, nrow in [("问题1_典型日申报", 8, 120), ("问题2_用电量预测", 7, 3672),
                       ("问题3_价格预测与申报", 9, 3672), ("问题4_风险申报", 8, 3672)]:
    ws = wb[name]
    types = {}
    bad = []
    for i in range(nrow):
        r = 4 + i
        v = ws.cell(row=r, column=2).value
        types[type(v).__name__] = types.get(type(v).__name__, 0) + 1
        if not isinstance(v, str) or v != f"{(i % 24):02d}:00":
            if len(bad) < 5: bad.append((r, v))
    print(f"  {name}: 时段列类型 {types} 异常 {len(bad)} {bad}")
    # 日期列递增与完整性
    dates = [ws.cell(row=4 + i, column=1).value for i in range(nrow)]
    print(f"     日期首/尾: {dates[0]} / {dates[-1]}  唯一日期数: {len(set(dates))}")

print("\n== 问题2/3/4 sheet 的 note 列是否被截断 ==")
for name, col in [("问题2_用电量预测", 7), ("问题3_价格预测与申报", 9), ("问题4_风险申报", 7)]:
    ws = wb[name]
    v = ws.cell(row=4, column=col).value
    print(f"  {name} r4: {v!r}  (len={len(str(v))})")

print("\n== 检查提交版是否有公式残留/异常类型 ==")
wbf = openpyxl.load_workbook("../outputs/附件6_提交版.xlsx", data_only=False)
nf = 0
for ws2 in wbf.worksheets:
    for row in ws2.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.startswith("="):
                nf += 1
                if nf < 6: print("   公式:", ws2.title, c.coordinate, c.value)
print("   公式单元格总数:", nf)
