# -*- coding: utf-8 -*-
"""自检：用我自己的结算函数重算 q1 典型日的逐时段成本，与被检验方 q1_bid.csv 对比。
若一致，说明我对附录1 规则的实现正确，可继续用于 q3/q4。"""
import pandas as pd, numpy as np
from settle import settle_hourly, load_inputs

a1 = pd.read_csv("../data/interim/att1_典型日.csv")
qb = pd.read_csv("../outputs/q1_bid.csv")
d = qb.merge(a1, on=["date", "hour"], how="left")
assert d["load_actual"].notna().all()
r = settle_hourly(d["q_bid"], d["contract_q"], d["contract_p"],
                  d["load_actual"], d["price_da"], d["price_rt"])
for c in ["cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery"]:
    diff = (r[c].values - d[c].values)
    print(f"{c:14s} max|diff|={np.abs(diff).max():12.6f}  sum_diff={diff.sum():14.4f}")
diff = r["cost_total"].values - d["cost_total"].values
print(f"{'cost_total':14s} max|diff|={np.abs(diff).max():12.6f}  sum_diff={diff.sum():14.4f}")

print("\n-- 我算的逐日总成本 vs summary/q1_cost --")
my = r.groupby(d["date"].values).sum()
qc = pd.read_csv("../outputs/q1_cost.csv")
for _, row in qc.iterrows():
    dt = row["date"]
    m = my.loc[dt]
    print(f"{dt}  mine_total={m['cost_total']:12.2f}  claim_total={row['cost_total']:12.2f}  "
          f"mine_energy={m['cost_energy']:12.2f} claim_energy={row['cost_contract']+row['cost_da_dev']+row['cost_rt_dev']:12.2f}  "
          f"mine_rec={m['cost_recovery']:9.2f} claim_rec={row['cost_recovery']:9.2f}")

print("\n我算的 q1 五个典型日合计: ", my["cost_total"].sum())
print("被检验 q1_cost 合计:      ", qc["cost_total"].sum())
print("\n成本排序自检（q_bid 与 1.2L/0.8L 的关系）:")
up = d["q_bid"] - 1.2*d["load_actual"]; dn = 0.8*d["load_actual"] - d["q_bid"]
print(" q>1.2L 时段数:", (up > 1e-9).sum(), " q<0.8L 时段数:", (dn > 1e-9).sum(),
      " 恰好贴边(|q-1.2L|<1e-6):", (np.abs(up) < 1e-6).sum(), (np.abs(dn) < 1e-6).sum())
