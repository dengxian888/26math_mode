# -*- coding: utf-8 -*-
"""追查 q3_metrics 的 MAPE 定义；并复算完全信息最优基准②；复算 CVaR/分位数。"""
import numpy as np, pandas as pd, json
from settle import settle_hourly, load_inputs

m, _ = load_inputs("..")
W = m[(m.date >= "2026-04-01") & (m.date <= "2026-08-31")].reset_index(drop=True)
f3 = pd.read_csv("../outputs/q3_price_bid.csv")
d = W.merge(f3, on=["date", "hour"])
d["act_spread"] = d.price_rt - d.price_da

print("== 目标列统计 ==")
for nm in ["price_da", "price_rt", "act_spread"]:
    y = d[nm]
    print(f"{nm:12s} mean={y.mean():9.4f} mean|y|={y.abs().mean():9.4f} min={y.min():9.2f} "
          f"max={y.max():9.2f} n(|y|<1)={(y.abs()<1).sum()} n(y<=0)={(y<=0).sum()}")

print("\n== q3_metrics 声称的 MAPE 与各种候选定义对比 ==")
q3m = pd.read_csv("../outputs/q3_metrics.csv").set_index("target")
pairs = [("price_da", "pred_da"), ("price_rt", "pred_rt"),
         ("spread_direct", "pred_spread_direct"), ("spread_calc", "pred_spread_calc")]
for tgt, pcol in pairs:
    y = (d["act_spread"] if "spread" in tgt else d[tgt]).values
    p = d[pcol].values
    e = p - y
    mae = np.mean(np.abs(e))
    cands = {
        "mean(|e|/|y|)": np.mean(np.abs(e) / np.abs(y)) * 100,
        "MAE/mean(y)": mae / y.mean() * 100,
        "MAE/mean(|y|)": mae / np.abs(y).mean() * 100,
        "MAE/mean(|p|)": mae / np.abs(p).mean() * 100,
        "mean(|e|)/mean(|y|) [WMAPE]": np.sum(np.abs(e)) / np.sum(np.abs(y)) * 100,
        "MAE/(max-min)": mae / (y.max() - y.min()) * 100,
        "mean(|e|/|y|) excl |y|<10": np.mean((np.abs(e) / np.abs(y))[np.abs(y) >= 10]) * 100,
    }
    claimed = q3m.loc[tgt, "MAPE"]
    best = min(cands.items(), key=lambda kv: abs(kv[1] - claimed))
    print(f"{tgt:14s} claimed={claimed:9.4f} | " + " | ".join(f"{k}={v:.3f}" for k, v in cands.items()))
    print(f"{'':14s} 最接近: {best[0]}={best[1]:.4f} (差 {best[1]-claimed:+.4f})")

print("\n== 完全信息最优基准②（q = 1.2L if S>0 else 0.8L）==")
s = d.price_rt - d.price_da
q_perf = np.where(s > 0, 1.2 * d.load_actual, 0.8 * d.load_actual)
r = settle_hourly(q_perf, d.contract_q, d.contract_p, d.load_actual, d.price_da, d.price_rt)
print(f"  总成本={r['cost_total'].sum():,.2f}  声称=55,425,239.01  差={r['cost_total'].sum()-55425239.01:,.2f}")
print(f"  (含回收 {r['cost_recovery'].sum():,.2f})")
# 若 q 也允许不受带宽约束（理论上）
q_free = np.where(s > 0, 1e6, 0.0)
r2 = settle_hourly(np.minimum(q_free, 1e5), d.contract_q, d.contract_p, d.load_actual, d.price_da, d.price_rt)
print(f"  说明：无带宽约束的绝对最优会被 1e5 上限与回收罚死，不作为基准")

print("\n== summary.json 中 q4_compare 的 CVaR/分位数复算 ==")
f4 = pd.read_csv("../outputs/q4_risk.csv")
d4 = W.merge(f4[["date", "hour", "q_det", "q_risk"]], on=["date", "hour"])
out = {}
for nm in ["q_det", "q_risk"]:
    rr = settle_hourly(d4[nm], d4.contract_q, d4.contract_p, d4.load_actual, d4.price_da, d4.price_rt)
    g = rr.groupby(d4.date.values)["cost_total"].sum()
    out[nm] = g
    q95 = np.quantile(g, 0.95)
    k = int(np.ceil(0.05 * len(g)))
    sorted_g = np.sort(g)[::-1]
    print(f"{nm}: 均值={g.mean():,.2f} 最大={g.max():,.2f} 最小={g.min():,.2f} "
          f"分位95(np.quantile)={q95:,.2f} 分位95(排序法,第8大)={sorted_g[k-1]:,.2f}")
    print(f"    CVaR95(尾均值,最差{k}天)={sorted_g[:k].mean():,.2f}   CVaR95(>=分位点均值)={g[g>=q95].mean():,.2f}")
    print(f"    日成本std(ddof=1)={g.std(ddof=1):,.2f}  std(ddof=0)={g.std():,.2f}")
    print(f"    总成本={g.sum():,.2f}")
json.dump({k: v.to_dict() for k, v in out.items()}, open("daily_costs.json", "w"))
