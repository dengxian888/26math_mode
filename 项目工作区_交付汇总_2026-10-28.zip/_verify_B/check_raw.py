# -*- coding: utf-8 -*-
"""核对 data/interim/*.csv 是否忠实于原始附件2/4/5（抽样比对），避免"清洗版"失真"""
import pandas as pd, numpy as np
def raw(f):
    d = pd.read_excel(f, sheet_name=None)
    print("  sheets:", list(d.keys())[:5])
    return d
print("### 附件2_用户实际用电量.xlsx")
wb2 = raw("../数理大赛赛题/附件2_用户实际用电量.xlsx")
for k, v in wb2.items():
    print(" ", k, v.shape); print(v.head(3).to_string())
print("\n### 附件4_市场价格.xlsx")
for k, v in raw("../数理大赛赛题/附件4_市场价格.xlsx").items():
    print(" ", k, v.shape); print(v.head(3).to_string())
print("\n### 附件5_中长期合约.xlsx")
for k, v in raw("../数理大赛赛题/附件5_中长期合约.xlsx").items():
    print(" ", k, v.shape); print(v.head(3).to_string())
