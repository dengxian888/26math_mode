# -*- coding: utf-8 -*-
"""v2: 判定 q3_metrics 的 MAPE 到底用了什么定义（含 sMAPE、不同的实际值列组合）"""
import numpy as np, pandas as pd
from settle import load_inputs
m, _ = load_inputs("..")
W = m[(m.date >= "2026-04-01") & (m.date <= "2026-08-31")].reset_index(drop=True)
f3 = pd.read_csv("../outputs/q3_price_bid.csv")
d = W.merge(f3, on=["date", "hour"])
d["act_spread"] = d.price_rt - d.price_da
q3m = pd.read_csv("../outputs/q3_metrics.csv").set_index("target")

cols = {"price_da": d.price_da.values, "price_rt": d.price_rt.values, "act_spread": d.act_spread.values}
preds = {"pred_da": d.pred_da.values, "pred_rt": d.pred_rt.values,
         "pred_spread_direct": d.pred_spread_direct.values, "pred_spread_calc": d.pred_spread_calc.values}

def defs(y, p):
    e = p - y; ae = np.abs(e); ay = np.abs(y)
    o = {}
    o["MAPE"] = np.mean(ae / ay) * 100
    o["MAPE_y>0"] = np.mean((ae / np.abs(y))[y > 0]) * 100
    o["MAPE_ay>1"] = np.mean((ae / ay)[ay > 1]) * 100
    o["MAPE_ay>10"] = np.mean((ae / ay)[ay > 10]) * 100
    o["MAPE_floor1"] = np.mean(ae / np.maximum(ay, 1)) * 100
    o["MAPE_floor50"] = np.mean(ae / np.maximum(ay, 50)) * 100
    o["sMAPE"] = np.mean(2 * ae / (ay + np.abs(p))) * 100
    o["MAE/mean"] = np.mean(ae) / y.mean() * 100
    o["MAE/mean|y|"] = np.mean(ae) / ay.mean() * 100
    o["MAE/mean(y|y>0)"] = np.mean(ae) / y[y > 0].mean() * 100
    return o

print("每个 目标 × 预测 组合的候选定义（只列出与被检验 MAPE 相差 <1 的）")
claims = {t: q3m.loc[t, "MAPE"] for t in q3m.index}
for tgt, y in cols.items():
    print(f"\n### 目标 {tgt}  声称 MAPE={claims.get(tgt, float('nan')):.4f}")
    for pn, p in preds.items():
        o = defs(y, p)
        hits = {k: v for k, v in o.items() if abs(v - claims.get(tgt, -99)) < 1.0}
        if hits:
            print(f"   {pn:20s} 命中: " + ", ".join(f"{k}={v:.4f}" for k, v in hits.items()))
    # 也列出所有定义的数值，方便判断
    for pn, p in preds.items():
        if pn.split("_")[1] in tgt or tgt in ("price_da","price_rt"):
            pass
print("\n-- 详细：各目标用其对应预测列时的全部候选定义 --")
pairs = {"price_da": "pred_da", "price_rt": "pred_rt",
         "spread_direct": "pred_spread_direct", "spread_calc": "pred_spread_calc"}
for tgt, pcol in pairs.items():
    y = cols["act_spread"] if "spread" in tgt else cols[tgt]
    o = defs(y, preds[pcol])
    print(f"{tgt:14s} claim={claims[tgt]:9.4f}  " + "  ".join(f"{k}={v:8.3f}" for k, v in o.items()))

print("\n-- 检查 25.5084 是否 = 某分位数/其他列的 MAPE --")
for c in ["price_da","price_rt","act_spread"]:
    o = defs(cols[c], preds["pred_da"])
    print(f"pred_da vs {c:12s}: " + "  ".join(f"{k}={v:8.3f}" for k, v in o.items()))
print("\n25.5084 的其他可能来源: mean(|e|/|y|) 在 70-80% 区间? 头尾截断?")
e = np.abs(preds["pred_da"] - cols["price_da"]); r = e / np.abs(cols["price_da"])
print(" ratio 分位数 50/75/90/95/99:", np.percentile(r, [50,75,90,95,99]))
print(" 若剔除 |y| 最小的 k 个再算 MAPE:")
idx = np.argsort(np.abs(cols["price_da"]))
for k in [1,2,4,8,16,32]:
    keep = idx[k:]
    print(f"   k={k:2d}: MAPE={np.mean(r[keep])*100:9.4f}  MAE={np.mean(e[keep]):8.4f}")

print("\n-- 顺带：问题2 的 MAPE 是否标准定义（对照）--")
f2 = pd.read_csv("../outputs/q2_forecast.csv")
d2 = W.merge(f2, on=["date","hour"])
for s in ["pred_A","pred_B","pred_C"]:
    y2 = d2.load_actual.values; p2 = d2[s].values; e2 = np.abs(p2-y2)
    print(f"{s}: MAPE={np.mean(e2/y2)*100:.4f}  sMAPE={np.mean(2*e2/(y2+np.abs(p2)))*100:.4f}  "
          f"MAE={e2.mean():.4f}  WMAPE={e2.sum()/y2.sum()*100:.4f}")
