# -*- coding: utf-8 -*-
"""Q1 附加检查：申报量是否为完全信息下的最优（带角点），以及"合约量夹进 ±20% 带"之说"""
import numpy as np, pandas as pd
from settle import settle_hourly
q1 = pd.read_csv("../outputs/q1_bid.csv"); a1 = pd.read_csv("../data/interim/att1_典型日.csv")
d = q1.merge(a1, on=["date","hour"])
d["S"] = d.price_rt - d.price_da
d["up"] = 1.2*d.load_actual; d["dn"] = 0.8*d.load_actual
d["at_up"] = (d.q_bid-d.up).abs() < 1e-3
d["at_dn"] = (d.q_bid-d.dn).abs() < 1e-3
d["corner"] = np.where(d.S > 0, d.up, d.dn)
d["is_opt"] = (d.q_bid-d.corner).abs() < 1e-3
d["clamp_contract"] = np.clip(d.contract_q, d.dn, d.up)
d["is_clamp"] = (d.q_bid-d.clamp_contract).abs() < 1e-3
print("各典型日: 申报量落在完全信息最优角点 / 合约量夹带 的时段数")
print(d.groupby("date")[["is_opt","is_clamp","at_up","at_dn"]].sum())
print("\n非最优时段明细（共 %d 个）:" % (~d.is_opt).sum())
print(d.loc[~d.is_opt, ["date","hour","q_bid","contract_q","load_actual","S","corner","clamp_contract"]]
      .to_string(index=False, float_format=lambda x: f"{x:.4f}"))
print("\n这些时段 S 的分布:", d.loc[~d.is_opt,"S"].describe()[["min","mean","max"]].round(3).to_dict())
print("S==0 的时段数:", (d.S.abs()<1e-9).sum())
# 若改按角点结算，成本会低多少
r_now = settle_hourly(d.q_bid, d.contract_q, d.contract_p, d.load_actual, d.price_da, d.price_rt).cost_total.sum()
r_opt = settle_hourly(d.corner, d.contract_q, d.contract_p, d.load_actual, d.price_da, d.price_rt).cost_total.sum()
print(f"\nQ1 现有申报 5 日总成本 = {r_now:,.2f}")
print(f"Q1 完全信息角点解总成本 = {r_opt:,.2f}   （差 {r_now-r_opt:,.2f}）")
# 与 q4 的 q_det/q_risk 是否相同口径（Q1 是典型日，独立）
print("\nQ1 note 里的 '字典序定解' 是否解释了非角点时段？clamp(contract_q) 命中:", d.is_clamp.sum(), "/", len(d))
