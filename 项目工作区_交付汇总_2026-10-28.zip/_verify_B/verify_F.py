# -*- coding: utf-8 -*-
"""F. 核对 附件6_提交版.xlsx：行数 / 空白 / 与 CSV 数值一致 / 汇总指标填写"""
import re, json
import numpy as np, pandas as pd, openpyxl

XL = "../outputs/附件6_提交版.xlsx"
TPL = "../数理大赛赛题/附件6_结果文件.xlsx"
wb = openpyxl.load_workbook(XL, data_only=True)
res = {}

def blocks(ws, first_row, ncol):
    """返回数据区 (rows x ncol) 的取值，从 first_row 到 ws.max_row"""
    return [[ws.cell(row=r, column=c).value for c in range(1, ncol + 1)]
            for r in range(first_row, ws.max_row + 1)]

print("=" * 78, "\nF1. 数据行数")
spec = {"问题1_典型日申报": (4, 8, 120), "问题2_用电量预测": (4, 7, 3672),
        "问题3_价格预测与申报": (4, 9, 3672), "问题4_风险申报": (4, 8, 3672),
        "问题4_周期结果": (4, 8, 9)}
for name, (r0, nc, want) in spec.items():
    ws = wb[name]
    rows = blocks(ws, r0, nc)
    nonempty = [i for i, row in enumerate(rows) if any(v is not None and str(v).strip() != "" for v in row)]
    n = len(nonempty)
    contiguous = (len(nonempty) > 0 and nonempty[-1] + 1 == n)
    print(f"  {name}: max_row={ws.max_row} 数据区行数(A{r0}:{ws.max_row})={len(rows)} "
          f"非空行={n} 期望={want} {'OK' if n==want else 'MISMATCH'} 连续={contiguous}")
    res.setdefault("rows", {})[name] = dict(max_row=ws.max_row, nonempty=n, want=want)
    if n != want:
        print(f"    非空行下标示例: {nonempty[:3]} ... {nonempty[-3:] if nonempty else []}")
        # 看看第 9 行之后是否为空
        for i in range(min(len(rows), 25)):
            if i + 1 > want + 2 and any(v is not None for v in rows[i]):
                print("    超出期望的行:", r0 + i, rows[i])

print("\n" + "=" * 78, "\nF2. 数据区空白单元格")
CSVS = {
    "问题1_典型日申报": ("../outputs/q1_bid.csv",
        ["date", "hour", "q_bid", "cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery", "cost_total"]),
    "问题2_用电量预测": ("../outputs/q2_forecast.csv",
        ["date", "hour", "pred_A", "pred_B", "pred_C", "pred_final", "note"]),
    "问题3_价格预测与申报": ("../outputs/q3_price_bid.csv",
        ["date", "hour", "pred_da", "pred_rt", "pred_spread_direct", "pred_spread_calc",
         "pred_spread_final", "q_bid", "note"]),
    "问题4_风险申报": ("../outputs/q4_risk.csv",
        ["date", "hour", "q_det", "q_risk", "risk_measure", "risk_param", "note", "scheme_id"]),
}
blanks = {}
for name, (csvf, cols) in CSVS.items():
    r0, nc, _ = spec[name]
    ws = wb[name]
    cnt = 0; where = []
    for r in range(r0, r0 + spec[name][2]):
        for c in range(1, nc + 1):
            v = ws.cell(row=r, column=c).value
            if v is None or (isinstance(v, str) and v.strip() == ""):
                cnt += 1
                if len(where) < 15: where.append(f"{ws.cell(row=r,column=c).coordinate}")
    print(f"  {name}: 数据区空白单元格 {cnt} 个" + (f"  例: {where}" if cnt else ""))
    blanks[name] = dict(n_blank=cnt, examples=where)

# 周期结果
ws = wb["问题4_周期结果"]
cnt = 0; where = []
for r in range(4, 4 + 9):
    for c in range(1, 9):
        v = ws.cell(row=r, column=c).value
        if v is None or (isinstance(v, str) and v.strip() == ""):
            cnt += 1
            if len(where) < 15: where.append(ws.cell(row=r, column=c).coordinate)
print(f"  问题4_周期结果: 9 行数据区空白单元格 {cnt} 个" + (f"  例: {where}" if cnt else ""))
blanks["问题4_周期结果"] = dict(n_blank=cnt, examples=where)
res["blanks"] = blanks

print("\n" + "=" * 78, "\nF3. 与 CSV 数值一致性（全量比对 + 抽样 25 行明细）")
def num_close(a, b, tol=5e-4, rel=1e-6):
    try:
        a = float(a); b = float(b)
    except (TypeError, ValueError):
        return str(a).strip() == str(b).strip()
    return abs(a - b) <= max(tol, rel * abs(b))

mismatch = {}
for name, (csvf, cols) in CSVS.items():
    df = pd.read_csv(csvf)
    r0, nc, nrow = spec[name]
    ws = wb[name]
    assert nrow == len(df), (name, nrow, len(df))
    bad = []
    for i in range(nrow):
        r = r0 + i
        for j, col in enumerate(cols, start=1):
            xv = ws.cell(row=r, column=j).value
            cv = df[col].iloc[i]
            if col == "hour":
                # 时段列应为文本 'HH:00'
                want = f"{int(cv):02d}:00"
                ok = (isinstance(xv, str) and xv.strip() == want)
                if not ok: bad.append((r, j, col, xv, want))
                continue
            if i % 20 == 0 or not num_close(xv, cv, tol=1e-3):
                pass
            if not num_close(xv, cv, tol=1e-3):
                if len(bad) < 20: bad.append((r, j, col, xv, cv))
    print(f"  {name}: 全量 {nrow} 行 × {nc} 列 不匹配 {len(bad)} 处")
    for b in bad[:10]:
        print("     ", b)
    mismatch[name] = bad[:20]
res["mismatch"] = {k: [list(map(str, x)) for x in v] for k, v in mismatch.items()}

print("\n-- 抽样 25 行明细（前 5 / 中 5 / 尾 5 / 随机 10）--")
np.random.seed(42)
for name, (csvf, cols) in CSVS.items():
    df = pd.read_csv(csvf); r0, nc, nrow = spec[name]; ws = wb[name]
    idx = [0, 1, 2, 3, 4, nrow // 2 - 2, nrow // 2, nrow // 2 + 1, nrow - 3, nrow - 2,
           nrow - 1] + sorted(np.random.choice(nrow, 10, replace=False).tolist())
    print(f"\n  ### {name}  抽样行（Excel 行号 / 关键列 我的CSV值 vs 表内值）")
    for i in idx:
        r = r0 + i
        got = [ws.cell(row=r, column=j).value for j in range(1, nc + 1)]
        exp = [df[cols[j - 1]].iloc[i] for j in range(1, nc + 1)]
        ok = all(num_close(g, e, tol=1e-3) for g, e in zip(got, exp)
                 if not isinstance(e, str) or cols[exp.index(e) if e in exp else 0] != "hour")
        print(f"    r{r:5d} {str(got[0]):10s} {str(got[1]):6s} " +
              " ".join(f"{g!r}" for g in got[2:min(nc, 6)]))
    break  # 明细只打印问题1，避免刷屏；下面对每张表单独打印关键行

print("\n" + "=" * 78, "\nF4. 汇总指标 sheet 填写情况")
ws = wb["汇总指标"]
groups = {"问题1 成本(5-9)": (5, 9, [2, 3, 4]), "问题2 指标(13-16)": (13, 16, [2, 3, 4, 5, 6]),
          "问题3 指标(20-23)": (20, 23, [2, 3, 4, 5]),
          "问题3 经济(27)": (27, 27, [2, 3, 4, 5, 6]),
          "问题4 比较(32-33)": (32, 33, [2, 3, 4, 5, 6, 7])}
for g, (r1, r2, colspec) in groups.items():
    print(f"\n  -- {g} --")
    for r in range(r1, r2 + 1):
        lbl = ws.cell(row=r, column=1).value
        vals = [ws.cell(row=r, column=c).value for c in colspec]
        empty = [c for c, v in zip(colspec, vals) if v is None or (isinstance(v, str) and v.strip() == "")]
        # G 列说明
        desc = [ws.cell(row=r, column=c).value for c in range(5, 9) if ws.cell(row=r, column=c).value]
        print(f"    r{r} {str(lbl)[:22]:24s} 值={vals}  {'空白列:' + str(empty) if empty else 'OK'}")

json.dump(res, open("verify_F.json", "w"), ensure_ascii=False, indent=1, default=str)
