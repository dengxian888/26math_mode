# -*- coding: utf-8 -*-
"""全量比对原始 xlsx（附件2/4/5）与 interim csv，确认清洗版无失真"""
import pandas as pd, numpy as np
def norm(df, rename):
    d = df.rename(columns=rename).copy()
    d["date"] = pd.to_datetime(d["日期"]).dt.strftime("%Y-%m-%d")
    d["hour"] = d["时段"].astype(str).str.slice(0, 2).astype(int)
    return d
t2 = pd.read_excel("../数理大赛赛题/附件2_用户实际用电量.xlsx")
c2 = pd.read_csv("../data/interim/att2_用电量.csv")
t2n = norm(t2, {"日期":"日期","实际用电量（MWh）":"load", "可获得日期":"avail", "星期":"weekday", "日期类型":"day_type", "节假日名称":"holiday"})
c2n = c2.rename(columns={"load_actual":"load","available_date":"avail"})
mm = t2n[["date","hour","load"]].merge(c2n[["date","hour","load"]], on=["date","hour"], suffixes=("_xlsx","_csv"))
print("附件2 行数 xlsx=%d csv=%d merged=%d  max|diff|=%.10f  缺失 csv=%d" %
      (len(t2n), len(c2), len(mm), (mm.load_xlsx-mm.load_csv).abs().max(), c2.load_actual.isna().sum()))

t4 = pd.read_excel("../数理大赛赛题/附件4_市场价格.xlsx")
c4 = pd.read_csv("../data/interim/att4_价格.csv")
cols4 = list(t4.columns)
t4n = norm(t4, {cols4[2]:"da", cols4[3]:"rt"})
mm = t4n[["date","hour","da","rt"]].merge(c4[["date","hour","price_da","price_rt"]], on=["date","hour"])
print("附件4 行数 xlsx=%d csv=%d max|dDA|=%.10f max|dRT|=%.10f" %
      (len(t4n), len(c4), (mm.da-mm.price_da).abs().max(), (mm.rt-mm.price_rt).abs().max()))

t5 = pd.read_excel("../数理大赛赛题/附件5_中长期合约.xlsx")
c5 = pd.read_csv("../data/interim/att5_合约.csv")
cols5 = list(t5.columns)
t5n = norm(t5, {cols5[2]:"q", cols5[3]:"p"})
mm = t5n[["date","hour","q","p"]].merge(c5[["date","hour","contract_q","contract_p"]], on=["date","hour"])
print("附件5 行数 xlsx=%d csv=%d max|dq|=%.10f max|dp|=%.10f" %
      (len(t5n), len(c5), (mm.q-mm.contract_q).abs().max(), (mm.p-mm.contract_p).abs().max()))

t1 = pd.read_excel("../数理大赛赛题/附件1_典型日完全信息.xlsx", sheet_name=None)
print("\n附件1 sheets:", list(t1.keys()))
for k,v in t1.items():
    print(" ",k,v.shape, list(v.columns)[:8])
print("\n附件1 日期:", sorted(set(str(x)[:10] for x in t1[list(t1)[0]].iloc[:,0])))
# 与 att1 csv 比对
a1 = pd.read_csv("../data/interim/att1_典型日.csv")
v = t1[list(t1)[0]]
col = list(v.columns)
c1 = a1.merge(norm(v, {col[2]:"cq", col[3]:"cp", col[4]:"L", col[5]:"da", col[6]:"rt"})[["date","hour","cq","cp","L","da","rt"]],
              on=["date","hour"])
print("  att1 csv 行数=%d merged=%d max|dL|=%.8f max|dda|=%.8f" %
      (len(a1), len(c1), (c1.load_actual-c1.L).abs().max(), (c1.price_da-c1.da).abs().max()))
