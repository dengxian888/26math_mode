# -*- coding: utf-8 -*-
"""独立验算 A：求最优日前申报电量与 5 日总成本。

本人独立理解的规则（附录1 (i)(ii)），按小时 t：
  S_t  = P_RT,t - P_DA,t
  电能量成本_t(q_t)
     = q_c,t * p_c,t                       # 中长期合约电费
     + (q_t - q_c,t) * P_DA,t              # 日前偏差电费（可为负）
     + (L_t - q_t) * P_RT,t                # 实时偏差电费（可为负）
  收益回收_t R_t(q_t)  （λ0 = 0.20）：
     q_t > (1+λ0)L_t 且 S_t > 0 :  R_t = [q_t - (1+λ0)L_t] * S_t
     q_t < (1-λ0)L_t 且 S_t < 0 :  R_t = [(1-λ0)L_t - q_t] * (-S_t)
     其他                        :  R_t = 0
  日总成本 = Σ_t [ 电能量成本_t + R_t ]

目标函数（自定）：min 总购电成本（风险中性、期望成本最小；问题1 下参数全部已知）。
"""
import os
import numpy as np
import pandas as pd
from scipy.optimize import linprog

from read_data import load_xlsx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAMBDA0 = 0.20


# ---------------------------------------------------------------- 规则实现
def recovery(q, L, P_DA, P_RT, lam=LAMBDA0):
    """逐时段收益回收费用 R_t（元）。向量化。"""
    S = P_RT - P_DA
    R = np.zeros_like(q, dtype=float)
    up = q > (1.0 + lam) * L
    dn = q < (1.0 - lam) * L
    m1 = up & (S > 0)
    R[m1] = (q[m1] - (1.0 + lam) * L[m1]) * S[m1]
    m2 = dn & (S < 0)
    R[m2] = ((1.0 - lam) * L[m2] - q[m2]) * (-S[m2])
    return R


def cost_terms(q, d, lam=LAMBDA0):
    """返回各分项（元）与被检验的总成本。"""
    q_c, p_c = d["contract_q"].values, d["contract_p"].values
    L, P_DA, P_RT = d["load_actual"].values, d["price_da"].values, d["price_rt"].values
    c_long = q_c * p_c
    c_da = (q - q_c) * P_DA
    c_rt = (L - q) * P_RT
    R = recovery(q, L, P_DA, P_RT, lam)
    return dict(中长期合约电费=c_long, 日前偏差电费=c_da,
                实时偏差电费=c_rt, 收益回收=R,
                合计=c_long + c_da + c_rt + R)


# ---------------------------------------------------------------- 闭式最优
def optimal_cost_closed_form(d, lam=LAMBDA0):
    """把成本写成 q 的分段线性函数后取极小，得到唯一最优值：
       S>0:  min_{q} = base - (1+λ) S L     (q >= (1+λ)L 上整段平坦)
       S<0:  min_{q} = base - (1-λ) S L     (0 <= q <= (1-λ)L 上整段平坦)
       base = q_c(p_c - P_DA) + L P_RT
    """
    q_c, p_c = d["contract_q"].values, d["contract_p"].values
    L, P_DA, P_RT = d["load_actual"].values, d["price_da"].values, d["price_rt"].values
    S = P_RT - P_DA
    base = q_c * (p_c - P_DA) + L * P_RT
    mult = np.where(S > 0, 1.0 + lam, 1.0 - lam)
    # S==0 时 mult 取 1-λ 也无影响（S=0 使该项为 0）
    return base - mult * S * L


def optimal_cost_lp(d, lam=LAMBDA0, qmax_mult=50.0):
    """用 LP（逐时段 epigraph 精确刻画 R_t 的分段线性）独立验证闭式解。
    min  Σ [ q_c(p_c-P_DA) + L P_RT + (P_DA-P_RT) q_t + r_t ]
    s.t. q_t >= 0 ; r_t >= 0 ; r_t >= 该时段唯一可能触发的那一支
    """
    q_c, p_c = d["contract_q"].values, d["contract_p"].values
    L, P_DA, P_RT = d["load_actual"].values, d["price_da"].values, d["price_rt"].values
    S = P_RT - P_DA
    n = len(d)
    c = np.concatenate([P_DA - P_RT, np.ones(n)])          # q 的系数 + r 的系数
    base = float(np.sum(q_c * (p_c - P_DA) + L * P_RT))
    A, b = [], []
    for t in range(n):
        row = np.zeros(2 * n)
        if S[t] > 0:      # r_t - S_t q_t >= -S_t(1+λ)L_t
            row[t] = -S[t]
            row[n + t] = 1.0
            A.append(row); b.append(-S[t] * (1 + lam) * L[t])
        elif S[t] < 0:    # r_t + |S_t| q_t >= |S_t|(1-λ)L_t
            row[t] = -S[t]
            row[n + t] = 1.0
            A.append(row); b.append((-S[t]) * (1 - lam) * L[t])
    A = np.array(A); b = np.array(b)
    bounds = [(0.0, qmax_mult * L[t]) for t in range(n)] + [(0.0, None)] * n
    res = linprog(c, A_ub=-A, b_ub=-b, bounds=bounds, method="highs")
    assert res.status == 0, res.message
    return base + float(res.fun), res.x[:n], res.x[n:]


def solve_q_min_dev_from_load(d, lam=LAMBDA0):
    """定解准则：在最优解集合中取 min Σ|q_t - L_t|（物理偏差最小，最抗预测误差）。
       该准则给出唯一解 q_t = (1+λ)L_t (S>0) 或 (1-λ)L_t (S<0)。"""
    L = d["load_actual"].values
    S = (d["price_rt"] - d["price_da"]).values
    return np.where(S > 0, (1 + lam) * L, (1 - lam) * L)


def baseline_contract(d, lam=LAMBDA0):
    """对照：不做任何调整，直接按中长期合约电量申报 q_t = q_c,t。"""
    return d["contract_q"].values.copy()


if __name__ == "__main__":
    d = load_xlsx().sort_values(["date", "hour"]).reset_index(drop=True)

    print("=" * 92)
    print("一、最优成本的两种独立求法对比（闭式 vs LP）")
    print("=" * 92)
    cf = optimal_cost_closed_form(d)
    lp_total, q_lp, r_lp = optimal_cost_lp(d)
    print(f"闭式（逐时段解析极小）合计 = {cf.sum():,.2f} 元")
    print(f"LP  （HiGHS，精确分段线性） = {lp_total:,.2f} 元")
    print(f"两者差 = {cf.sum() - lp_total:.6f} 元")

    print("\n" + "=" * 92)
    print("二、平台区验证：固定其他时段，单时段扫描目标函数（选 2 个代表时段）")
    print("=" * 92)
    d4 = d[d["date"] == "2026-04-07"].reset_index(drop=True)
    for label, mask in [("2026-04-07 时段08 (S>0)", (d4["price_rt"] > d4["price_da"])),
                        ("2026-06-09 时段12 (S<0)", None)]:
        pass
    # 直接在整体 120 时段上做扫描：对每个时段验证最优值平台
    q0 = solve_q_min_dev_from_load(d)
    L = d["load_actual"].values; S = (d["price_rt"] - d["price_da"]).values
    q_c = d["contract_q"].values; p_c = d["contract_p"].values
    P_DA = d["price_da"].values; P_RT = d["price_rt"].values

    def single_cost(qt, t):
        s = dict(price_da=np.array([P_DA[t]]), price_rt=np.array([P_RT[t]]),
                 load_actual=np.array([L[t]]), contract_q=np.array([q_c[t]]),
                 contract_p=np.array([p_c[t]]))
        df1 = pd.DataFrame(s)
        return cost_terms(np.array([qt]), df1)["合计"][0]

    for t, tag in [(0, "2026-04-07 00:00 (S>0)"),
                   (24 * 3 + 12, "2026-06-09 12:00 (S<0)")]:
        grid = np.linspace(0, 3.0 * L[t], 2001)
        vals = np.array([single_cost(g, t) for g in grid])
        vmin = vals.min()
        flat = grid[vals <= vmin + 1e-7]
        print(f"\n{tag}: L={L[t]:.4f}, q_c={q_c[t]:.4f}, S={S[t]:.2f}")
        print(f"  目标最小值 = {vmin:,.4f} 元")
        print(f"  最优解集（与最小值相差 <=1e-7 元）区间: "
              f"[{flat.min():.3f}, {flat.max():.3f}]  (网格点 {len(flat)} 个 / 2001)")
        print(f"  闭式预测的平坦下界/上界: S>0 → q>={(1+LAMBDA0)*L[t]:.3f}; "
              f"S<0 → q<={(1-LAMBDA0)*L[t]:.3f}")
        print(f"  在 q=q_c 处成本 = {single_cost(q_c[t], t):,.4f} 元；"
              f"理想带内 q=1.0L 处成本 = {single_cost(L[t], t):,.4f} 元")

    print("\n" + "=" * 92)
    print("三、最优方案（定解准则：最优集合内 min Σ|q-L|）")
    print("=" * 92)
    opt = cost_terms(q0, d)
    base = cost_terms(baseline_contract(d), d)

    rows = []
    for dt, g in d.assign(idx=range(len(d))).groupby("date"):
        idx = g["idx"].values
        rows.append({
            "日期": dt,
            "最优_合约": opt["中长期合约电费"][idx].sum(),
            "最优_日前偏差": opt["日前偏差电费"][idx].sum(),
            "最优_实时偏差": opt["实时偏差电费"][idx].sum(),
            "最优_收益回收": opt["收益回收"][idx].sum(),
            "最优_日总成本": opt["合计"][idx].sum(),
            "合约申报_日总成本": base["合计"][idx].sum(),
            "合约申报_收益回收": base["收益回收"][idx].sum(),
            "日节省": base["合计"][idx].sum() - opt["合计"][idx].sum(),
        })
    daily = pd.DataFrame(rows)
    pd.set_option("display.width", 250)
    print(daily.to_string(index=False, float_format=lambda x: f"{x:,.2f}"))

    tot_opt = opt["合计"].sum()
    tot_base = base["合计"].sum()
    print("\n最优 5 日合计:")
    print(f"  中长期合约电费 = {opt['中长期合约电费'].sum():,.2f}")
    print(f"  日前偏差电费   = {opt['日前偏差电费'].sum():,.2f}")
    print(f"  实时偏差电费   = {opt['实时偏差电费'].sum():,.2f}")
    print(f"  收益回收       = {opt['收益回收'].sum():,.2f}")
    print(f"  总购电成本     = {tot_opt:,.2f} 元")
    print("\n按合约量申报 5 日合计:")
    print(f"  中长期合约电费 = {base['中长期合约电费'].sum():,.2f}")
    print(f"  日前偏差电费   = {base['日前偏差电费'].sum():,.2f}")
    print(f"  实时偏差电费   = {base['实时偏差电费'].sum():,.2f}")
    print(f"  收益回收       = {base['收益回收'].sum():,.2f}")
    print(f"  总购电成本     = {tot_base:,.2f} 元")
    print(f"\n节省额 = {tot_base - tot_opt:,.2f} 元；"
          f"节省率 = {(tot_base - tot_opt) / tot_base * 100:.4f}%")
    print("（若按合约量申报且不计收益回收，则 = "
          f"{(base['中长期合约电费'].sum()+base['日前偏差电费'].sum()+base['实时偏差电费'].sum()):,.2f} 元）")

    print("\n" + "=" * 92)
    print("四、与被检验主张逐项比较")
    print("=" * 92)
    claims = {
        "最优 5 日总成本": (tot_opt, 1432352.56),
        "按合约量申报 5 日总成本": (tot_base, 1690664.40),
        "节省额": (tot_base - tot_opt, 258311.84),
        "节省率(%)": ((tot_base - tot_opt) / tot_base * 100, 15.28),
        "2026-04-07 单日最优成本": (daily.loc[daily["日期"] == "2026-04-07", "最优_日总成本"].iloc[0], 243282.74),
        "2026-06-19 单日最优成本": (daily.loc[daily["日期"] == "2026-06-19", "最优_日总成本"].iloc[0], 212568.95),
    }
    print(f"{'项目':<26}{'自算':>16}{'主张':>16}{'差异%':>10}  判定")
    for k, (mine, claim) in claims.items():
        diff = (mine - claim) / abs(claim) * 100
        a = abs(diff)
        verdict = "PASS" if a <= 5 else ("SUSPECT" if a <= 15 else "FAIL")
        print(f"{k:<24}{mine:>16,.2f}{claim:>16,.2f}{diff:>+10.4f}  {verdict}")

    daily.to_csv(os.path.join(os.path.dirname(__file__), "daily_result.csv"),
                 index=False, encoding="utf-8-sig")
    pd.DataFrame({
        "date": d["date"], "hour": d["hour"],
        "q_opt": q0, "q_contract": q_c, "L": L,
        "price_da": P_DA, "price_rt": P_RT, "S": S,
        "R_opt": opt["收益回收"], "R_contract": base["收益回收"],
        "cost_opt": opt["合计"], "cost_contract": base["合计"],
    }).to_csv(os.path.join(os.path.dirname(__file__), "hourly_result.csv"),
              index=False, encoding="utf-8-sig")
    print("\n已写出 daily_result.csv / hourly_result.csv")
