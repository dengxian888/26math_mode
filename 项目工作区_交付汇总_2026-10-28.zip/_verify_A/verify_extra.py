# -*- coding: utf-8 -*-
"""独立验算 A 续：最优性逐时段验证、平台区实测、定解准则对比、舍入溯源、敏感性。"""
import os
import numpy as np
import pandas as pd

from read_data import load_xlsx
from solve_q1 import (LAMBDA0, recovery, cost_terms, optimal_cost_closed_form,
                      optimal_cost_lp, solve_q_min_dev_from_load, baseline_contract)

pd.set_option("display.width", 250)
d = load_xlsx().sort_values(["date", "hour"]).reset_index(drop=True)
d["idx"] = range(len(d))
q_c = d["contract_q"].values; p_c = d["contract_p"].values
L = d["load_actual"].values; P_DA = d["price_da"].values; P_RT = d["price_rt"].values
S = P_RT - P_DA
q0 = solve_q_min_dev_from_load(d)

print("=" * 100)
print("A. 平台区实测：逐时段（120 个）在 [0, 3L] 上密集扫描，检查最小化集合形状")
print("=" * 100)
bad = 0
rowsA = []
for t in range(len(d)):
    grid = np.linspace(0.0, 3.0 * L[t], 3001)
    df = pd.DataFrame(dict(price_da=np.full(len(grid), P_DA[t]),
                           price_rt=np.full(len(grid), P_RT[t]),
                           load_actual=np.full(len(grid), L[t]),
                           contract_q=np.full(len(grid), q_c[t]),
                           contract_p=np.full(len(grid), p_c[t])))
    vals = cost_terms(grid, df)["合计"]
    vmin = vals.min()
    flat = grid[vals <= vmin + 1e-9]
    lo, hi = flat.min(), flat.max()
    if S[t] < 0:
        exp_lo, exp_hi = 0.0, (1 - LAMBDA0) * L[t]
    else:
        exp_lo, exp_hi = (1 + LAMBDA0) * L[t], 3.0 * L[t]
    ok = abs(lo - exp_lo) < 1e-2 and abs(hi - exp_hi) < 1e-2
    bad += (not ok)
    rowsA.append(dict(t=t, date=d["date"][t], hour=d["hour"][t], S=S[t],
                      平坦区下界=lo, 平坦区上界=hi, 期望下界=exp_lo, 期望上界=exp_hi, ok=ok))
A = pd.DataFrame(rowsA)
print(f"120 个时段中，平坦区(最优解集)与解析预测不一致的个数 = {bad}")
print("S>0 的时段其最优解集为 [1.2L, +∞)，S<0 的时段为 [0, 0.8L]：全部确认" if bad == 0 else A[~A.ok])
print("\n示例（每类各 2 个）：")
print(pd.concat([A[A.S > 0].head(2), A[A.S < 0].head(2)]).to_string(index=False, float_format=lambda x: f"{x:,.3f}"))

print("\n" + "=" * 100)
print("B. 每个时段闭式极小值 == 网格扫描极小值？（逐时段独立复核，共 120 个）")
print("=" * 100)
cf_hour = optimal_cost_closed_form(d)
dv = []
for t in range(len(d)):
    grid = np.linspace(0.0, 3.0 * L[t], 3001)
    df = pd.DataFrame(dict(price_da=np.full(len(grid), P_DA[t]),
                           price_rt=np.full(len(grid), P_RT[t]),
                           load_actual=np.full(len(grid), L[t]),
                           contract_q=np.full(len(grid), q_c[t]),
                           contract_p=np.full(len(grid), p_c[t])))
    dv.append(cost_terms(grid, df)["合计"].min() - cf_hour[t])
dv = np.array(dv)
print(f"逐时段 (网格最小值 - 闭式值) 的最大绝对差 = {np.abs(dv).max():.6e} 元")

print("\n" + "=" * 100)
print("C. 不同定解准则 → 完全相同的总成本（成本对平台区位置不敏感）")
print("=" * 100)
crit = {
    "C1 物理偏差最小 argmin Σ|q-L|  → q=1.2L 或 0.8L": q0,
    "C2 调整额度最小 argmin Σ|q-q_c|（向平坦区端点夹紧）":
        np.where(S > 0, np.maximum(q_c, (1 + LAMBDA0) * L), np.minimum(q_c, (1 - LAMBDA0) * L)),
    "C3 申报量最小（S>0 时也取 1.2L；S<0 时取 0）":
        np.where(S > 0, (1 + LAMBDA0) * L, 0.0),
    "C4 带内混合 40% 位置（q=1.2L 与 0.9L 各半，S>0 非最优，仅作反例）":
        np.where(S > 0, 1.2 * L, 0.9 * L),
    "C5 硬约束版 q=clip(q_c, 0.8L, 1.2L)":
        np.clip(q_c, (1 - LAMBDA0) * L, (1 + LAMBDA0) * L),
}
for name, q in crit.items():
    c = cost_terms(q, d)["合计"]
    per = {}
    for dt, g in d.groupby("date"):
        per[dt] = c[g["idx"].values].sum()
    print(f"{name}\n   5日总 = {c.sum():,.2f} 元 | 04-07 = {per['2026-04-07']:,.2f} | "
          f"06-19 = {per['2026-06-19']:,.2f}")

print("\n" + "=" * 100)
print("D. 舍入溯源：主张值 1,432,352.56 与自算 1,432,352.61 差 0.05 元，测试各种舍入口径")
print("=" * 100)
def tot(q):
    return cost_terms(q, d)["合计"].sum()
variants = {
    "不圆整（全精度）": tot(q0),
}
for nd in (1, 2, 3, 4):
    variants[f"q 保留 {nd} 位小数"] = tot(np.round(q0, nd))
for nd in (2, 3, 4):
    variants[f"q 向上(ceil) {nd} 位（保证仍在平坦区）"] = tot(np.ceil(q0 * 10**nd) / 10**nd)
d2 = d.copy()
for c in ["contract_q", "load_actual", "price_da", "price_rt"]:
    if "load_actual" in c or "contract_q" in c:
        d2[c] = np.round(d2[c], 3 if "contract" in c else 3)
variants["L、q_c 先圆整到 3 位再算"] = cost_terms(q0, d2)["合计"].sum()

# 聚合口径溯源：先圆整再求和（Excel 两位小数落表后求和 / 逐日汇总再合计）
hc = cost_terms(q0, d)["合计"]
day = {dt: hc[g["idx"].values].sum() for dt, g in d.groupby("date")}
variants["小时成本先舍 2 位再求和"] = np.round(hc, 2).sum()
variants["逐日成本先舍 2 位再求和"] = sum(round(v, 2) for v in day.values())
variants["逐日成本先舍 2 位(银行家)再求和"] = float(sum(np.round(list(day.values()), 2)))
variants["float32 累加"] = float(np.float32(0).item()) + float(
    np.cumsum(hc.astype(np.float32))[-1])
variants["日成本向上舍 2 位后求和"] = float(sum(np.ceil(np.round(v, 6) * 100) / 100 for v in day.values()))
for k, v in variants.items():
    print(f"  {k:<34} {v:,.4f}   差主张 {v - 1432352.56:+.4f}")

print("\n各日成本（全精度）:")
for dt, g in d.groupby("date"):
    print(f"  {dt}  {cost_terms(q0, d)['合计'][g['idx'].values].sum():,.4f}")

print("\n" + "=" * 100)
print("E. 敏感性：λ0 变化对最优总成本的影响（检验结论是否依赖 λ0=20%）")
print("=" * 100)
for lam in (0.0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.50, 1.00):
    ql = np.where(S > 0, (1 + lam) * L, (1 - lam) * L)
    cc = cost_terms(ql, d, lam)["合计"].sum()
    R = recovery(ql, L, P_DA, P_RT, lam).sum()
    print(f"  λ0={lam:>4.2f}  最优5日总成本={cc:>15,.2f}  其中收益回收={R:>10,.2f}  "
          f"相对合约申报节省={cost_terms(baseline_contract(d), d, lam)['合计'].sum() - cc:>13,.2f}")

print("\n" + "=" * 100)
print("F. 最优方案是否真的支付收益回收？（R>0 的时段数）")
print("=" * 100)
Ropt = recovery(q0, L, P_DA, P_RT)
print(f"  最优方案 R>0 的时段数 = {(Ropt > 1e-9).sum()} / 120；R 合计 = {Ropt.sum():,.2f} 元")
print(f"  合约申报 R>0 的时段数 = {(recovery(q_c, L, P_DA, P_RT) > 1e-9).sum()} / 120")
print(f"  处于恰好边界 (|q/1.2L-1|<1e-9 或 |q/0.8L-1|<1e-9) 的时段数 = "
      f"{int(np.sum(np.isclose(q0, (1 + LAMBDA0) * L) | np.isclose(q0, (1 - LAMBDA0) * L)))}")

print("\n" + "=" * 100)
print("G. 调整额度（问题1 要求的“每日总调整额度”）与结构分解")
print("=" * 100)
adj = np.abs(q0 - q_c)
for dt, g in d.groupby("date"):
    i = g["idx"].values
    pos = (S[i] > 0).sum()
    print(f"  {dt}: Σ|q-q_c| = {adj[i].sum():>10,.3f} MWh ; Σ(q-q_c) = {(q0[i]-q_c[i]).sum():>+10,.3f} MWh ; "
          f"S>0 时段 {pos}/24 ; 最优点与 q_c 相同者 {int(np.isclose(q0[i], q_c[i]).sum())}")
print(f"  合计 Σ|q-q_c| = {adj.sum():,.3f} MWh")
