# -*- coding: utf-8 -*-
"""独立验算 A：只读赛题原文 + 原始数据，自己重建模型。
Step 0: 读原始 xlsx 与 clean csv，逐格交叉校验，确保数据无争议。"""
import os
import pandas as pd
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XLSX = os.path.join(ROOT, "数理大赛赛题", "附件1_典型日完全信息.xlsx")
CSV = os.path.join(ROOT, "data", "interim", "att1_典型日.csv")

COLS = {
    "日期": "date", "时段": "hour",
    "中长期合约电量（MWh）": "contract_q",
    "中长期合约价格\n（元/MWh）": "contract_p",
    "实际用电量（MWh）": "load_actual",
    "日前价格\n（元/MWh）": "price_da",
    "实时价格\n（元/MWh）": "price_rt",
    "日期类型": "day_type", "节假日名称": "holiday",
}


def load_xlsx():
    raw = pd.read_excel(XLSX, sheet_name="典型日数据")
    assert list(raw.columns) == list(COLS.keys()), raw.columns.tolist()
    df = raw.rename(columns=COLS)
    df["date"] = df["date"].astype(str).str[:10]
    df["hour"] = df["hour"].astype(str).str[:2].astype(int)
    return df[["date", "hour", "contract_q", "contract_p", "load_actual",
               "price_da", "price_rt", "day_type", "holiday"]]


def load_csv():
    df = pd.read_csv(CSV, dtype={"date": str})
    df["date"] = df["date"].str[:10]
    return df


def cross_check():
    a = load_xlsx().sort_values(["date", "hour"]).reset_index(drop=True)
    b = load_csv().sort_values(["date", "hour"]).reset_index(drop=True)
    assert len(a) == len(b) == 120, (len(a), len(b))
    assert (a["date"].values == b["date"].values).all()
    assert (a["hour"].values == b["hour"].values).all()
    num = ["contract_q", "contract_p", "load_actual", "price_da", "price_rt"]
    diffs = {}
    for c in num:
        x = a[c].astype(float).values
        y = b[c].astype(float).values
        diffs[c] = float(np.max(np.abs(x - y)))
    return a, diffs


if __name__ == "__main__":
    a, diffs = cross_check()
    print("行数:", len(a))
    print("xlsx 与 csv 最大绝对差:", diffs)
    print("日期列表:", sorted(a["date"].unique()))
    print("\n各日 24 时段行数检查:", a.groupby("date").size().to_dict())
    print("小时覆盖 0..23 每天:", all(sorted(g["hour"]) == list(range(24))
                                      for _, g in a.groupby("date")))
    print("含缺失值:", a.isna().sum().to_dict())
    print("\n价差 S = RT - DA 的符号分布 (120 时段):")
    s = a["price_rt"] - a["price_da"]
    print("  S>0 :", int((s > 0).sum()), " S<0 :", int((s < 0).sum()),
          " S==0 :", int((s == 0).sum()))
    print(a.assign(S=s).groupby("date")["S"].agg(
        lambda x: f"min={x.min():.2f} max={x.max():.2f} 正{int((x>0).sum())} 负{int((x<0).sum())}").to_string())
