# -*- coding: utf-8 -*-
"""独立验算 A：绘制单时段成本曲线，可视化"平台区"（最优解不唯一）。"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

from read_data import load_xlsx
from solve_q1 import LAMBDA0, cost_terms

HERE = os.path.dirname(os.path.abspath(__file__))
d = load_xlsx().sort_values(["date", "hour"]).reset_index(drop=True)
d["idx"] = range(len(d))
L = d["load_actual"].values; P_DA = d["price_da"].values; P_RT = d["price_rt"].values
S = P_RT - P_DA; q_c = d["contract_q"].values; p_c = d["contract_p"].values

cases = [(0, "2026-04-07 00:00   S = P_RT-P_DA > 0"),
         (24 * 2 + 12, "2026-06-09 12:00   S = P_RT-P_DA < 0")]
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
for ax, (t, tag) in zip(axes, cases):
    grid = np.linspace(0, 2.6 * L[t], 1200)
    df = pd.DataFrame(dict(price_da=np.full(len(grid), P_DA[t]),
                           price_rt=np.full(len(grid), P_RT[t]),
                           load_actual=np.full(len(grid), L[t]),
                           contract_q=np.full(len(grid), q_c[t]),
                           contract_p=np.full(len(grid), p_c[t])))
    ct = cost_terms(grid, df)
    tot = ct["合计"]; vmin = tot.min()
    ax.plot(grid, tot, lw=2, color="#1f4e79", label="日成本（该时段）")
    ax.axhline(vmin, ls=":", color="gray", lw=1)
    ax.axvline((1 - LAMBDA0) * L[t], ls="--", color="#c00", lw=1)
    ax.axvline((1 + LAMBDA0) * L[t], ls="--", color="#c00", lw=1)
    ax.axvline(L[t], ls="-.", color="#2a8", lw=1)
    ax.axvline(q_c[t], ls=":", color="#a50", lw=1.2)
    ax.fill_between(grid, tot, vmin, where=(tot <= vmin + 1e-9),
                    color="#ffb", alpha=.9, label="最优解集（平台区）")
    ax.set_title(tag, fontsize=10)
    ax.set_xlabel("日前申报电量 $q_t$ (MWh)")
    ax.set_ylabel("成本 (元)")
    ax.set_ylim(vmin - 0.06 * (tot.max() - vmin), vmin + 0.5 * (tot.max() - vmin))
    ax.legend(fontsize=8, loc="upper right")
    ax.grid(alpha=.3)
fig.suptitle("收益回收机制导致的成本平台区：(1±λ₀)L 边界之外边际收益被 100% 回收，目标函数变为水平",
             fontsize=10)
fig.tight_layout()
out = os.path.join(HERE, "fig_plateau.png")
fig.savefig(out, dpi=150)
print("saved", out)
