# 数理大赛 · 项目 README

赛题：**电力市场中的用电申报与风险决策**（华南理工大学第二十五届"三新集团杯"数理大赛）

> 当前进度：**D1 地基完成 + 口径定案 + 输出契约冻结**，四问代码待实现。
> 工作流程与任务分解见 `docs/规划书.md`；口径以 `DECISIONS.md` 为准。

## 0. 文档导航

开工前先读这三份（都在 `docs/`）：

| 文档 | 什么时候看 |
|---|---|
| [`docs/规划书.md`](docs/规划书.md) | 想知道**接下来做什么、谁做、什么时候交** |
| [`docs/口径说明.md`](docs/口径说明.md) | 想知道**某个争议点为什么这么定**（含数字例子） |
| [`docs/附件6契约.md`](docs/附件6契约.md) | 要**写代码产出结果**时，先看自己的输出该长什么样 |

另有：

| 文档 | 用途 |
|---|---|
| `DECISIONS.md` | **唯一口径来源**，任何指标/公式/假设的最终解释 |
| [`docs/赛题通俗解读.md`](docs/赛题通俗解读.md) | 第一次接触这道题的人先看这个（无公式） |
| [`docs/赛题全文.txt`](docs/赛题全文.txt) | 赛题 PDF 的完整中文文本（便于检索） |

## 1. 目录结构

```
项目工作区/
├─ docs/                  # 规划、口径、契约、赛题解读
├─ 数理大赛赛题/           # 官方赛题原件（只读，勿改）
├─ data/raw/              # 赛题原始附件（只读，勿改）
├─ data/interim/          # 清洗后统一长表（csv, utf-8-sig）
├─ src/common/            # 全队唯一共享内核
│   ├─ io.py              #   纯标准库 xlsx 读取 + 6 附件加载
│   ├─ asof.py            #   信息可得时间闸门
│   ├─ settle.py          #   结算内核（口径见 DECISIONS.md）
│   └─ fill_att6.py       #   附件6 填表器（待实现，契约见 docs/）
├─ src/q1 q2 q3 q4/       # 各问建模脚本（待实现）
├─ tests/                 # 单元测试
├─ outputs/figures/       # 图
├─ reports/               # EDA 报告
├─ paper/                 # 论文（官方 LaTeX 模板已就位，可编译）
├─ DECISIONS.md           # 口径决策清单（唯一口径来源）
├─ requirements.txt       # 依赖锁定
├─ build_data.py          # 构建长表
└─ run_all.py             # 一键复现
```

> 组员的原始交付（分工方案、任务表、甘特图、GATE1 验收记录、调试脚本、原始压缩包等）
> 已归档到上一级的 `../组员原始交付/`，**不再参与本项目**。

## 2. 环境

- **解释器：Python 3.10.11**（本机实际版本；原 README 写的 3.13 与实际不符，已更正）。
- **统一使用项目虚拟环境** `.venv`（位于仓库上一级 `D:\DSH\workspace\shumo\.venv`），**不要用系统 `python`**：
  ```bash
  # Windows
  D:\DSH\workspace\shumo\.venv\Scripts\python.exe run_all.py
  ```
  `.venv` 以 `--system-site-packages` 创建，继承了系统科学计算栈，另补齐了 `openpyxl / python-docx / statsmodels / pulp / highspy / pymupdf`。
- 依赖清单见根目录 [`requirements.txt`](requirements.txt)。**不要升级 numpy 到 2.x**（会顶掉已验证的组合）。
- 原因：系统 Python 缺 `openpyxl`（填表器需要），两个解释器混跑会出现"同样的代码在两个环境里结果不同"。**全队只用 `.venv` 一个解释器。**
- `src/common/io.py` 仍用标准库 `zipfile + ElementTree` 解析 xlsx，**不依赖** `openpyxl`——`openpyxl` 仅用于 `fill_att6.py` 填表与数据核对。

## 3. 运行顺序

```bash
# 统一用 .venv 的解释器（见 §2）
PY="D:/DSH/workspace/shumo/.venv/Scripts/python.exe"

$PY run_all.py            # 一键：数据底座 → 单元测试 → 四问 → 附件6 填表
$PY run_all.py --fast     # 跳过单元测试（快速看结果）
$PY run_all.py --only q1  # 只跑到问题1
# 或分步：
$PY build_data.py         # 生成 data/interim/*.csv 并打印摸底摘要
$PY tests/test_settle.py  # 结算内核 5 项单元测试（Gate1 验收）
$PY reports/make_d1_report.py  # 出 2 张图 + D1 数据摸底报告
```

## 4. 接口契约（三份，任何人不得私自改）

### 契约 1 · 长表 schema
`date(str 'YYYY-MM-DD') | hour(int 0-23) | 指标列(float)`；`available_date` 仅存在于带披露延迟的数据源。

### 契约 2 · 结算函数（唯一实现 `src/common/settle.py`）
```python
settle.settle_hour(q, L, p_da, p_rt, qc, pc, lam0=0.20) -> dict
settle.settle_day(q, L, p_da, p_rt, qc, pc, lam0=0.20)  -> dict  # 24 维数组 + sums
# 返回键：contract / da_dev / rt_dev / recovery(R_t) / total
```

### 契约 3 · 时间闸门（唯一实现 `src/common/asof.py`）
```python
asof.asof(df, decision_date) -> DataFrame  # 只保留 available_date <= decision_date 的行
# 对 D 日申报，在 D-1 收盘决策：asof(df, 'D-1')
```
**任何人禁止直接 `df.lag()`；特征构造一律过 `asof()`。**

## 5. 口径与决策

所有公式、假设、口径争议的最终解释以 **[DECISIONS.md](DECISIONS.md)** 为准。修改口径 → 队长站会裁决 → 追加修订记录 → 重跑受影响结果。

## 6. D1 已完成 / 待办

- ✅ M0 数据底座、M1 结算内核、时间闸门、口径清单、EDA 报告
- 🔜 D2：A 做问题 1（申报上限约束 + 求解）；B 做问题 2（特征 + 基线预测）；C 搭论文骨架
