# -*- coding: utf-8 -*-
"""问题2 EDA：用电规律分析（T2.1）。

产出 3 张图和一份结论，作为论文「数据说明 / 问题2 建模前提」的素材。

用法：<venv>/python.exe -m src.q2.eda
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

TYPE_ORDER = ["普通工作日", "普通周末", "法定节假日", "调休工作日"]
TYPE_COLOR = dict(zip(TYPE_ORDER, [TOL[0], TOL[2], TOL[1], TOL[3]]))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(42)
    apply_style()

    a2 = io.load_attachments()["att2"]
    a2["month"] = a2["date"].str[5:7]

    print("=" * 66)
    print("问题2 EDA · 用电规律")
    print("=" * 66)

    # ---------- 图1：日内形态 ----------
    prof = a2.pivot_table(index="hour", columns="day_type",
                          values="load_actual", aggfunc="mean")
    fig, ax = new_fig(figsize=(7.2, 3.8))
    for t in TYPE_ORDER:
        if t in prof.columns:
            ax.plot(prof.index, prof[t], "o-", ms=3, lw=1.4,
                    color=TYPE_COLOR[t], label=f"{t}（{a2[a2.day_type == t]['date'].nunique()} 天）")
    ax.set_xlabel("时段")
    ax.set_ylabel("平均用电量（MWh）")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(fontsize=7)
    save_fig(fig, "q2_日内形态")

    # ---------- 图2：周内 × 时段 热力图（工作日）----------
    wd = a2[a2["day_type"] == "普通工作日"].copy()
    wd["wd"] = wd["weekday"]
    mat = wd.pivot_table(index="wd", columns="hour", values="load_actual", aggfunc="mean")
    mat = mat.reindex(["周一", "周二", "周三", "周四", "周五"])
    fig, ax = new_fig(figsize=(8.4, 2.6))
    im = ax.imshow(mat.to_numpy(), aspect="auto", cmap="viridis")
    ax.set_yticks(range(len(mat.index)))
    ax.set_yticklabels(mat.index)
    ax.set_xticks(range(0, 24, 2))
    ax.set_xlabel("时段")
    ax.grid(False)
    fig.colorbar(im, ax=ax, label="平均用电量（MWh）")
    save_fig(fig, "q2_周内热力图")

    # ---------- 图3：日平均负荷时间序列（标注节假日）----------
    daily = a2.groupby("date").agg(load=("load_actual", "mean"),
                                   dt=("day_type", "first")).reset_index()
    daily["d"] = pd.to_datetime(daily["date"])
    fig, ax = new_fig(figsize=(9.2, 3.4))
    ax.plot(daily["d"], daily["load"], color=TOL[6], lw=0.9, label="日均负荷")
    for t in TYPE_ORDER:
        s = daily[daily["dt"] == t]
        if t in ("法定节假日",):
            ax.scatter(s["d"], s["load"], s=14, color=TYPE_COLOR[t], zorder=3, label=t)
    ax.set_xlabel("日期")
    ax.set_ylabel("日均用电量（MWh）")
    ax.legend(fontsize=7)
    save_fig(fig, "q2_日负荷序列")

    # ---------- 结论 ----------
    print("\n【结论 1】日内形态按日期类型分层明显")
    for t in TYPE_ORDER:
        s = prof[t].dropna() if t in prof.columns else None
        if s is None or s.empty:
            continue
        print(f"  {t}: 均值 {s.mean():.2f}，峰谷差 {s.max() - s.min():.2f}，"
              f"峰值时段 {int(s.idxmax())} 时，谷值时段 {int(s.idxmin())} 时")

    print("\n【结论 2】工作日内部星期效应弱，日期类型比星期更重要")
    wdv = a2[a2["day_type"] == "普通工作日"].groupby("weekday")["load_actual"].mean()
    print(f"  普通工作日各星期的均值范围：{wdv.min():.2f} ~ {wdv.max():.2f} "
          f"（极差 {wdv.max() - wdv.min():.2f}，仅占均值 {wdv.mean():.1f} 的 "
          f"{(wdv.max() - wdv.min()) / wdv.mean() * 100:.1f}%）")

    print("\n【结论 3】节假日与工作日差异巨大，必须单独建模")
    means = a2.groupby("day_type")["load_actual"].mean()
    print(f"  普通工作日 {means.get('普通工作日', float('nan')):.2f} → "
          f"法定节假日 {means.get('法定节假日', float('nan')):.2f}，"
          f"降幅 {(1 - means.get('法定节假日', 1) / means.get('普通工作日', 1)) * 100:.1f}%")

    print("\n【结论 4】存在明显的月度趋势与春节效应")
    mm = a2.groupby("month")["load_actual"].mean()
    print("  月度均值：" + "，".join(f"{m}月 {v:.1f}" for m, v in mm.items()))
    print(f"  2 月最低（{mm.min():.1f}，春节）；7 月最高（{mm.max():.1f}）")

    print("\n【结论 5】日期类型分布不均衡 → 节假日样本少是误差偏大的主因")
    cnt = a2.groupby("day_type")["date"].nunique().sort_values(ascending=False)
    print("  天数：" + "，".join(f"{k} {v}" for k, v in cnt.items()))

    print("\n产出：q2_日内形态.png、q2_周内热力图.png、q2_日负荷序列.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
