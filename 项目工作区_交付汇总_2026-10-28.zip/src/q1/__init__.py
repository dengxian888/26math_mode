# -*- coding: utf-8 -*-
"""问题1 包。入口见 solve.py。"""
