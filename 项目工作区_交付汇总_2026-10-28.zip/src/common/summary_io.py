# -*- coding: utf-8 -*-
"""汇总指标读写：各问把自己的结果合并进 outputs/summary.json。

为什么需要它：附件6 的「汇总指标」是**一张表**，但数据由四个问题分别产出。
若每个问题直接覆盖写，会互相冲掉。所以统一走“按键合并”。

区块与键（对应 docs/附件6契约.md §3.6）：
    q1_cost           键 = 日期（5 个典型日）
    q2_metrics        键 = A / B / C / final
    q3_price_metrics  键 = da / rt / spread_direct / spread_calc
    q3_econ           键 = det
    q4_compare        键 = det / risk
"""
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(_HERE))
DEFAULT_PATH = os.path.join(ROOT, "outputs", "summary.json")

# 各区块用于去重的键字段
BLOCK_KEY_FIELD = {
    "q1_cost": "date",
    "q2_metrics": "_key",
    "q3_price_metrics": "_key",
    "q3_econ": "_key",
    "q4_compare": "_key",
}


def _key_of(block: str, item: dict) -> str:
    field = BLOCK_KEY_FIELD.get(block, "_key")
    if field in item:
        return str(item[field])
    for f in ("_key", "date", "scheme", "target"):
        if f in item:
            return str(item[f])
    raise ValueError(f"{block} 的条目缺少可识别的键字段：{item}")


def update_summary(path: str | None = None, block: str = None, items=None) -> dict:
    """把 items 合并进 path 的 block 区块（同键覆盖）。返回合并后的完整 dict。"""
    path = path or DEFAULT_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = {}
    if os.path.exists(path):
        try:
            data = json.load(open(path, encoding="utf-8"))
        except json.JSONDecodeError:
            data = {}

    if block:
        if isinstance(items, dict):
            items = [items]
        items = items or []
        cur = {_key_of(block, x): x for x in data.get(block, [])}
        for it in items:
            cur[_key_of(block, it)] = it
        data[block] = list(cur.values())

    json.dump(data, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return data


def read_summary(path: str | None = None) -> dict:
    path = path or DEFAULT_PATH
    if not os.path.exists(path):
        return {}
    return json.load(open(path, encoding="utf-8"))


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    d = read_summary()
    for k, v in d.items():
        print(f"{k}: {len(v)} 条")
