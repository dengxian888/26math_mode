# -*- coding: utf-8 -*-
"""一键复现入口（T0.5）。

流程：数据底座 -> 单元测试 -> 四问求解 -> 附件6 填表

设计原则：
  - **未实现的环节自动跳过**，不阻断整体流程（Day 1 时四问都还没有）
  - 已实现的环节失败则**立即中止**，避免用错误结果继续往下跑
  - 结束时打印状态汇总表，一眼看出哪一步做完了

用法：
    <venv>/python.exe run_all.py            # 完整流程
    <venv>/python.exe run_all.py --fast     # 跳过耗时的单元测试
    <venv>/python.exe run_all.py --only q1  # 只跑到问题1
"""
import argparse
import os
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.abspath(__file__))

# 四问求解入口（未实现则跳过）
QUESTION_SCRIPTS = [
    ("Q1", "src/q1/solve.py", "问题1 完全信息下最优申报"),
    ("Q2", "src/q2/solve.py", "问题2 次日用电量预测"),
    ("Q3", "src/q3/solve.py", "问题3 价格预测与确定性申报"),
    ("Q4", "src/q4/solve.py", "问题4 风险决策与滚动模拟"),
]

# 各问的前置分析（EDA 等），在求解之前跑
EDA_SCRIPTS = [
    ("问题2 EDA", "src/q2/eda.py"),
    ("问题3 EDA", "src/q3/eda.py"),
]

# 四问之后的补充分析（依赖各问产出，但不需要重新训练模型）
EXTRA_STEPS = [
    ("问题1 稳健性检验", "src/q1/robust.py"),
    ("问题3 误差分解", "src/q3/decompose.py"),
]

# 附件6 填表所需的上游产出
ATT6_INPUTS = [
    "outputs/q1_bid.csv", "outputs/q2_forecast.csv", "outputs/q3_price_bid.csv",
    "outputs/q4_risk.csv", "outputs/q4_cycle.csv", "outputs/summary.json",
]

RESULTS = []


def run(label, cmd, required=True):
    """跑一个子步骤。required=False 时失败也继续。"""
    print("\n" + "=" * 66)
    print(">", label)
    print("=" * 66)
    t0 = time.time()
    r = subprocess.run([sys.executable] + cmd, cwd=ROOT)
    dt = time.time() - t0
    if r.returncode != 0:
        if required:
            RESULTS.append((label, "[FAIL] 失败", dt))
            print(f"[FAIL] {label} 失败 (exit {r.returncode}) — 中止")
            summary()
            sys.exit(r.returncode)
        RESULTS.append((label, "[WARN] 失败(忽略)", dt))
        return False
    RESULTS.append((label, "[OK] 完成", dt))
    print(f"[OK] {label} 完成（{dt:.1f}s）")
    return True


def skip(label, reason):
    RESULTS.append((label, "[SKIP] 跳过", 0.0))
    print(f"\n[SKIP] 跳过 {label}：{reason}")


def summary():
    print("\n" + "=" * 66)
    print("运行汇总")
    print("=" * 66)
    for label, status, dt in RESULTS:
        print(f"  {status:<12} {label}" + (f"   {dt:.1f}s" if dt else ""))
    done = sum(1 for _, s, _ in RESULTS if s.startswith("[OK]"))
    skip_n = sum(1 for _, s, _ in RESULTS if s.startswith("[SKIP]"))
    print(f"\n  {done} 完成 / {skip_n} 跳过 / {len(RESULTS) - done - skip_n} 其他")


def main():
    ap = argparse.ArgumentParser(description="一键复现")
    ap.add_argument("--fast", action="store_true", help="跳过单元测试")
    ap.add_argument("--only", default=None, help="只跑到指定环节（q1/q2/q3/q4/att6）")
    a = ap.parse_args()
    stop_at = a.only.lower() if a.only else None

    print("=" * 66)
    print("数理大赛 · 一键复现")
    print("=" * 66)

    # ---------- 1. 数据底座 ----------
    run("数据底座构建", ["build_data.py"])

    # ---------- 2. 单元测试 ----------
    if not a.fast:
        for label, path in (
            ("结算内核测试", "tests/test_settle.py"),
            ("T0 复核（组员产物）", "tests/test_t0_review.py"),
            ("绘图封装测试", "tests/test_plotting.py"),
            ("附件6 填表器测试", "tests/test_fill_att6.py"),
            ("问题1 数学验证", "tests/test_q1.py"),
            ("问题2 预测验证", "tests/test_q2.py"),
            ("问题3 价格验证", "tests/test_q3.py"),
            ("问题4 风险验证", "tests/test_q4.py"),
        ):
            if os.path.exists(os.path.join(ROOT, path)):
                run(label, [path])
            else:
                skip(label, f"未找到 {path}")

    # ---------- 3. 前置分析（EDA）----------
    for label, rel in EDA_SCRIPTS:
        if os.path.exists(os.path.join(ROOT, rel)):
            run(label, ["-m", rel[:-3].replace("/", ".")])
        else:
            skip(label, f"尚未实现（{rel}）")

    # ---------- 4. 四问 ----------
    for key, rel, label in QUESTION_SCRIPTS:
        if not os.path.exists(os.path.join(ROOT, rel)):
            skip(label, f"尚未实现（{rel}）")
        else:
            module = rel[:-3].replace("/", ".")   # src/q1/solve.py -> src.q1.solve
            run(label, ["-m", module])
        if stop_at == key.lower():
            summary()
            return

    # ---------- 5. 补充分析 ----------
    for label, rel in EXTRA_STEPS:
        if os.path.exists(os.path.join(ROOT, rel)):
            run(label, ["-m", rel[:-3].replace("/", ".")])
        else:
            skip(label, f"尚未实现（{rel}）")

    # ---------- 6. 附件6 填表 ----------
    missing = [p for p in ATT6_INPUTS if not os.path.exists(os.path.join(ROOT, p))]
    if missing:
        skip("附件6 填表", f"缺少 {len(missing)} 个上游产出：{', '.join(os.path.basename(m) for m in missing)}")
    else:
        run("附件6 填表", ["-m", "src.common.fill_att6"])

    summary()
    print("\n 流程结束")


if __name__ == "__main__":
    main()
