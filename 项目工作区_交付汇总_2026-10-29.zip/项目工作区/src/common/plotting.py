# -*- coding: utf-8 -*-
"""论文级绘图封装（T0.4）。

把散落在各问脚本里的 matplotlib 设置统一到一处，保证全文图表风格一致。

用法：
    from src.common.plotting import apply_style, save_fig, set_seed, TOL, SEQ
    apply_style(); set_seed(42)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(x, y, color=TOL[0])
    ax.set_xlabel("迭代次数")          # 轴标签写纯中文
    save_fig(fig, "问题1_收敛曲线")     # 自动存到 outputs/figures/

规范（对应论文「图表规范」）：
- 中文 SimSun / 宋体，西文 Times New Roman，负号正常显示
- 色盲友好（Paul Tol Bright），禁用 jet / rainbow；连续量用 viridis / cividis
- **图内不放标题**，标题交给论文 \\caption{}
- 300 DPI，去白边保存

[WARN]️ 两条实测坑（matplotlib 3.10.8 / Windows 11 / Python 3.10）：

1. 字体回退必须写成 **`font.family` 字体名列表**。
   `font.family="serif"` + `font.serif=[...]` 不会逐字形回退，中文会整片变豆腐块。

2. **同一个字符串里不能既写汉字又写 `$...$`**。
   只要串里出现 `$`，matplotlib 就把整串交给 mathtext 排版，而 mathtext 的
   `default` 字体没有汉字字形 -> 汉字全部消失（stderr 报 "does not have a glyph"）。
   可用写法：
   - 轴标签写纯中文：「迭代次数」「目标函数值」
   - 公式单独成串：label=r"$\\alpha=0.95$"（整串就是公式，没问题）
   - 中英混排需要符号时，把符号写进 \\caption{}，或用 ax.annotate 单独放一个公式文本
"""
import os

import matplotlib

matplotlib.use("Agg")  # 无界面环境下稳定出图

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(_HERE))
FIG_DIR = os.path.join(ROOT, "outputs", "figures")

# ---------------------------------------------------------------- 中文字体
_CJK_CANDIDATES = ["SimSun", "宋体", "Microsoft YaHei", "SimHei", "KaiTi", "FangSong"]


def _pick_cjk() -> str:
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in _CJK_CANDIDATES:
        if name in available:
            return name
    raise RuntimeError(
        "没有找到任何中文字体，请检查 C:\\Windows\\Fonts 下的 simsun.ttc / msyh.ttc"
    )


CJK_FONT = _pick_cjk()

# ---------------------------------------------------------------- 配色
# Paul Tol Bright：约 8% 男性有红绿色觉缺陷，此配色可区分
TOL = ["#4477AA", "#EE6677", "#228833", "#CCBB44",
       "#66CCEE", "#AA3377", "#BBBBBB", "#000000"]

SEQ = "viridis"       # 连续色标（替代 jet / rainbow）
SEQ_ALT = "cividis"   # 需要更强对比时用


def apply_style(font_size: float = 9.0, serif: bool = True) -> None:
    """全局套用论文图表样式。画图前调用一次。"""
    rc = {
        "font.size": font_size,
        "axes.unicode_minus": False,
        "axes.titlesize": font_size + 1,
        "axes.labelsize": font_size,
        "xtick.labelsize": font_size - 1,
        "ytick.labelsize": font_size - 1,
        "legend.fontsize": font_size - 1,
        "figure.dpi": 120,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linewidth": 0.6,
        "lines.linewidth": 1.5,
        "lines.markersize": 4,
        "legend.frameon": False,
        "image.cmap": SEQ,
        "mathtext.fontset": "stix",
    }
    if serif:
        rc["font.family"] = ["Times New Roman", CJK_FONT, "DejaVu Serif"]
    else:
        rc["font.family"] = [CJK_FONT, "Microsoft YaHei", "DejaVu Sans"]
    matplotlib.rcParams.update(rc)


def save_fig(fig, name: str, dpi: int = 300, subdir: str = "") -> str:
    """保存到 outputs/figures/。name 可带 .png 后缀，也可不带。

    返回实际保存的路径。
    """
    if not name.lower().endswith((".png", ".pdf", ".svg")):
        name += ".png"
    out_dir = os.path.join(FIG_DIR, subdir) if subdir else FIG_DIR
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name)
    fig.tight_layout()
    fig.savefig(path, dpi=dpi, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print(f"[fig] {path}")
    return path


def set_seed(seed: int = 42) -> None:
    """复现性：全项目统一随机种子。"""
    import random

    import numpy as np

    random.seed(seed)
    np.random.seed(seed)


def new_fig(nrows: int = 1, ncols: int = 1, figsize=None, **kw):
    """建图快捷方式：单图默认 6x4，多子图自动加宽。"""
    if figsize is None:
        figsize = (6 * ncols, 4 * nrows)
    return plt.subplots(nrows, ncols, figsize=figsize, **kw)


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print("中文字体:", CJK_FONT)
    print("图目录:", FIG_DIR)
    print("配色数:", len(TOL))
