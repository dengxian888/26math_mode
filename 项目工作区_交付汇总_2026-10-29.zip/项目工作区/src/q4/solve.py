# -*- coding: utf-8 -*-
"""问题4：不确定性下的风险申报与滚动模拟（T4.1–T4.7）。

## 为什么需要风险建模（问题3 的结论直接给出动机）
问题3 证明：价差符号准确率仅 52.2%，用"点预测的符号"决定多报/少报，
期望收益接近零而方差很大，实测净效果 -0.64%（比按合约量申报更贵）。

**关键修正**：最初以为解法是"向合约量收缩"，但实测期望成本最优的申报量反而更大
（均值 49.5 vs 确定性 37.8）。原因是评估期内真实价差均值 +23.74 元/MWh，
而预测价差均值仅 +2.59——确定性规则被噪声符号反复带偏，
把"系统性多报有利"这个信息浪费掉了。正确的修正是**用分布代替点估计**。

## 不确定性集（T4.1）
用问题2/问题3 滚动回测的**残差对**做情景：
    L_s = L_hat + e_s ,  S_s = S_hat + f_s ,  (e_s, f_s) 成对抽样
成对抽样保留了"负荷误差与价差误差"的相关性（不同时独立扰动）。

**信息约束**：决策日 D 时，负荷实际值只有 <= D-5 的可观测（附件2 T+4），
因此情景池只取 `date <= D-5` 的残差——不偷看未来。

## 风险目标（T4.2–T4.3）
    min_q  E[C(q)] + λ · CVaR_α( C(q) )
λ=0 退化为风险中性（即问题3 的确定性等价）；λ>0 惩罚尾部损失。

## 滚动模拟（T4.4）
三个同尾窗口：5 天（8/27–8/31）、10 天（8/22–8/31）、30 天（8/2–8/31）。
逐日决策、用实际值事后结算、累加成本。

用法：<venv>/python.exe -m src.q4.solve
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common.env import use_project_tmp

use_project_tmp()

from src.common import io  # noqa: E402
from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed  # noqa: E402
from src.common.settle import LAM0  # noqa: E402
from src.common.summary_io import update_summary  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

EVAL_START, EVAL_END = "2026-04-01", "2026-08-31"
LOAD_LAG = 5             # 负荷实际值可用到 D-5（附件2 T+4）
PRICE_LAG = 7            # 价格实际值可用到 D-7（附件4 T+6）
POOL_LAG = max(LOAD_LAG, PRICE_LAG)   # 残差对含价格项，须取二者更严者 = 7
ALPHA = 0.95             # CVaR 置信水平
N_SCEN = 200             # 情景数
N_GRID = 61              # 申报量网格点数
SEED = 42

# 三个风险偏好（契约 §5：R1 低 / R2 中 / R3 高）
SCHEMES = [
    ("R1", 0.0, "λ=0（风险中性，等价于确定性申报）"),
    ("R2", 0.5, "λ=0.5（中等风险厌恶）"),
    ("R3", 2.0, "λ=2.0（强风险厌恶）"),
]
MAIN_SCHEME = "R2"
PERIODS = [(5, "2026-08-27", "2026-08-31"), (10, "2026-08-22", "2026-08-31"),
           (30, "2026-08-02", "2026-08-31")]


# ---------------------------------------------------------------- 情景与目标
def scenario_costs(q, L, S, pda, qc, pc, lam0=LAM0):
    """给定单个申报量 q 与情景 (L,S)，返回各情景下的成本数组。"""
    R = np.where(S > 0, S * np.maximum(0.0, q - (1 + lam0) * L),
                 np.where(S < 0, (-S) * np.maximum(0.0, (1 - lam0) * L - q), 0.0))
    return qc * pc + (q - qc) * pda + (L - q) * (pda + S) + R


def cvar(costs, alpha=ALPHA):
    """CVaR_α：最差 (1-α) 尾部的均值。"""
    k = max(1, int(np.ceil((1 - alpha) * len(costs))))
    return float(np.sort(costs)[-k:].mean())


def optimal_q(L_hat, S_hat, pda, qc, pc, e_pool, f_pool, lam):
    """单时段最优申报量：min_q E[C(q)] + λ·CVaR_α(C(q))。

    **精确性说明**（回应 G7 评审对网格法的两点批评）：
      1. C_s(q) 关于 q 凸且分段线性，CVaR 为凸函数，故目标 F(q) 是凸的；
      2. 因此在连续区间上做**黄金分割搜索**即可，不存在网格的"上界截断"与
         "离散步长"两项误差；
      3. CVaR 按经验分布定义（最差 ⌈(1−α)n⌉ 个情景的均值），与正文报告口径一致；
      4. 搜索区间取 [0, 1.5·max 情景上带]，远宽于任何可能的最优点；
      5. 结束时与若干闭式候选点比较取优；并列时按问题一的字典序准则
         取 |q − Q^c| 最小者，避免"取网格最小点"这类路径依赖。
    """
    n = len(e_pool)
    Ls = np.maximum(L_hat + e_pool, 0.0)
    Ss = S_hat + f_pool

    def F(q):
        c = scenario_costs(q, Ls, Ss, pda, qc, pc)
        return c.mean() + lam * cvar(c)

    # 区间：上界取情景负荷的最大上带，保证不截断
    lo, hi = 0.0, 1.5 * max(float(np.max((1 + LAM0) * Ls)), qc, L_hat, 1e-6)
    g = (np.sqrt(5.0) - 1.0) / 2.0          # 0.618
    a, b = lo, hi
    c1 = b - g * (b - a)
    c2 = a + g * (b - a)
    f1, f2 = F(c1), F(c2)
    for _ in range(90):                     # (0.618)^90 ≈ 1e-19，远超所需精度
        if f1 < f2:
            b, c2, f2 = c2, c1, f1
            c1 = b - g * (b - a)
            f1 = F(c1)
        else:
            a, c1, f1 = c1, c2, f2
            c2 = a + g * (b - a)
            f2 = F(c2)
    q_gold = 0.5 * (a + b)

    # 与闭式候选点比较（黄金分割在"平台区"内只保证取到某一点，需字典序定解）
    cands = [q_gold, qc, max(qc, (1 + LAM0) * L_hat), min(qc, (1 - LAM0) * L_hat)]
    scored = []
    for q in cands:
        q = max(0.0, float(q))
        scored.append((F(q), abs(q - qc), q))     # 先目标值、再 |q−Q^c|
    scored.sort(key=lambda t: (round(t[0], 6), t[1]))
    obj_best, _, q_best = scored[0]
    return float(q_best), float(obj_best)


# ---------------------------------------------------------------- 结算小工具
def settle_day_local(q_day, g):
    """对单日 24 个时段结算，返回 (总成本, 回收费用)。"""
    from src.common.settle import settle_day
    r = settle_day(q_day, g["load_actual"].to_numpy(float), g["price_da"].to_numpy(float),
                   g["price_rt"].to_numpy(float), g["contract_q"].to_numpy(float),
                   g["contract_p"].to_numpy(float))["sums"]
    return r["total"], r["recovery"]


# ---------------------------------------------------------------- 数据准备
def prepare():
    """把预测、实际值、残差对齐到同一张表。"""
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    data = io.load_attachments()

    df = (q3[["date", "hour", "pred_da", "pred_spread_final", "q_bid"]]
          .rename(columns={"q_bid": "q_det"})
          .merge(q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"}),
                 on=["date", "hour"])
          .merge(data["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(data["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(data["att5"][["date", "hour", "contract_q", "contract_p"]], on=["date", "hour"]))
    df["S_hat"] = df["pred_spread_final"]
    df["S_actual"] = df["price_rt"] - df["price_da"]
    df["e_load"] = df["load_actual"] - df["L_hat"]          # 负荷预测残差
    df["f_spread"] = df["S_actual"] - df["S_hat"]           # 价差预测残差
    return df.sort_values(["date", "hour"]).reset_index(drop=True)


# ---------------------------------------------------------------- 滚动模拟
def rolling_sim(df, dates, lam, rng):
    """逐日决策 + 事后结算。返回逐日结果表。"""
    recs = []
    for D in dates:
        pos = dates.index(D)
        today = df[df["date"] == D]
        # 严格只用 <= D-7 的实际值。注意：情景对 (e_load, f_spread) 中的 f_spread
        # 需要 D-5 的实际价格，而价格披露为 T+6（只能到 D-7），故取更严的 D-7。
        # **不得**因样本少就回退到全部历史——那会引入 D-1...D-4 的残差（前视泄漏）。
        avail = dates[:max(0, pos - POOL_LAG + 1)]
        pool = df[df["date"].isin(avail)]

        if len(pool) == 0:
            # 评估期最初几天：还没有任何 <=D-5 的残差可用 -> 退回确定性申报
            qs = [float(v) for v in today["q_det"].to_numpy()]
            recs.append({"date": D, **{f"q_{i}": q for i, q in enumerate(qs)}})
            continue

        idx = rng.choice(len(pool), size=min(N_SCEN, len(pool)), replace=True)
        e_pool = pool["e_load"].to_numpy(float)[idx]
        f_pool = pool["f_spread"].to_numpy(float)[idx]

        qs = []
        for _, r in today.iterrows():
            q, _ = optimal_q(r["L_hat"], r["S_hat"], r["pred_da"],
                             r["contract_q"], r["contract_p"], e_pool, f_pool, lam)
            qs.append(q)
        recs.append({"date": D, **{f"q_{i}": q for i, q in enumerate(qs)}})
    out = pd.DataFrame(recs)
    qcols = [c for c in out.columns if c.startswith("q_")]
    qmat = out[qcols].to_numpy(float)
    return out[["date"]].assign(q=[[*row] for row in qmat])


def settle_plan(df, plan_q, dates):
    """把某方案在各日的 24 个申报量，用实际值结算，返回逐日成本。"""
    rows = []
    for D, q in zip(dates, plan_q):
        g = df[df["date"] == D].sort_values("hour")
        c = scenario_costs(np.array(q), g["load_actual"].to_numpy(float),
                           g["S_actual"].to_numpy(float), g["price_da"].to_numpy(float),
                           g["contract_q"].to_numpy(float), g["contract_p"].to_numpy(float))
        rows.append({"date": D, "cost": float(c.sum())})
    return pd.DataFrame(rows)


def make_figures(df, daily_all, periods_cmp, risk_out):
    apply_style()

    # 图1：残差分布（不确定性集的来源）
    fig, axes = new_fig(1, 2, figsize=(9.4, 3.2))
    axes[0].hist(df["e_load"], bins=70, color=TOL[0], alpha=0.85)
    axes[0].axvline(0, color="black", lw=0.8)
    axes[0].set_xlabel("负荷预测残差（MWh）")
    axes[0].set_ylabel("频数")
    axes[1].hist(df["f_spread"], bins=70, color=TOL[1], alpha=0.85)
    axes[1].axvline(0, color="black", lw=0.8)
    axes[1].set_xlabel("价差预测残差（元/MWh）")
    axes[1].set_ylabel("频数")
    save_fig(fig, "q4_残差分布")

    # 图2：三种风险偏好的日成本曲线（30 天窗口）
    # daily_all 只有 date/cost/scheme_id，没有 days 列——按 30 天窗口的日期区间筛
    d30 = daily_all[(daily_all["date"] >= "2026-08-02") & (daily_all["date"] <= "2026-08-31")]
    fig, ax = new_fig(figsize=(8.6, 3.4))
    for i, sid in enumerate(["R1", "R2", "R3"]):
        s = d30[d30["scheme_id"] == sid].sort_values("date")
        ax.plot(pd.to_datetime(s["date"]), s["cost"], "o-", ms=2.5, lw=1.0,
                color=TOL[i], label=f"{sid}（λ={dict((k, l) for k, l, _ in SCHEMES)[sid]}）")
    ax.set_xlabel("日期")
    ax.set_ylabel("日购电成本（元）")
    ax.legend(fontsize=7)
    save_fig(fig, "q4_日成本对比")

    # 图3：两种决策的申报量分布（确定性 vs 风险）
    fig, ax = new_fig(figsize=(7.4, 3.4))
    ax.hist(risk_out["q_det"] - risk_out["contract_q"], bins=60, alpha=0.55,
            color=TOL[6], label="确定性申报（问题3）")
    ax.hist(risk_out["q_risk"] - risk_out["contract_q"], bins=60, alpha=0.55,
            color=TOL[2], label="风险申报（问题4）")
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel("申报量 - 合约量（MWh）")
    ax.set_ylabel("频数")
    ax.legend(fontsize=7)
    save_fig(fig, "q4_申报分布")

    # 图4：残差相关性（成对抽样保留的含义）
    fig, ax = new_fig(figsize=(5.6, 3.2))
    ax.scatter(df["e_load"], df["f_spread"], s=2, alpha=0.25, color=TOL[0])
    ax.axhline(0, color="black", lw=0.6)
    ax.axvline(0, color="black", lw=0.6)
    ax.set_xlabel("负荷预测残差（MWh）")
    ax.set_ylabel("价差预测残差（元/MWh）")
    save_fig(fig, "q4_残差关系")


# ---------------------------------------------------------------- 入口
def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(SEED)
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)

    print("=" * 66)
    print("问题4 · 不确定性下的风险申报与滚动模拟")
    print("=" * 66)

    df = prepare()
    print(f"数据：{len(df)} 行")
    print(f"负荷残差：均值 {df.e_load.mean():+.3f}，std {df.e_load.std():.3f}，"
          f"MAE {df.e_load.abs().mean():.3f}")
    print(f"价差残差：均值 {df.f_spread.mean():+.2f}，std {df.f_spread.std():.2f}，"
          f"MAE {df.f_spread.abs().mean():.2f}")
    print(f"两者相关系数：{df.e_load.corr(df.f_spread):+.3f}")

    # ---------- 主结果：整个评估期都按 R2 决策，供附件6 明细表 ----------
    print(f"\n[1] 逐日风险决策（主方案 {MAIN_SCHEME}）")
    dates_eval = sorted(df[df["date"] <= EVAL_END]["date"].unique())
    plans = {}
    for sid, lam, desc in SCHEMES:
        p = rolling_sim(df, dates_eval, lam, np.random.default_rng(SEED))
        plans[sid] = p
        print(f"  {sid}（λ={lam}）完成 {len(p)} 天")

    # 与确定性申报、按合约量对比
    det_g = (df[df["date"].isin(dates_eval)].sort_values(["date", "hour"])
             .groupby("date")["q_det"].apply(lambda s: s.to_numpy()))
    plans["DET"] = pd.DataFrame({"date": dates_eval,
                                 "q": [list(det_g[d]) for d in dates_eval]})

    daily = []
    for sid, p in plans.items():
        d = settle_plan(df, p["q"].tolist(), dates_eval)
        d["scheme_id"] = sid
        daily.append(d)
    daily_all = pd.concat(daily, ignore_index=True)
    # 基准统一取"按合约量申报"（什么都不做），而非确定性申报
    qc_vec = df["contract_q"].to_numpy(float)
    base_all = float(sum(settle_day_local(qc_vec[g.index], g)[0]
                         for _, g in df.groupby("date", sort=False)))

    print("\n[2] 全期成本对比（153 天，事后结算）")
    base = daily_all[daily_all.scheme_id == "DET"]["cost"].sum()
    for sid in ("DET", "R1", "R2", "R3"):
        s = daily_all[daily_all.scheme_id == sid]["cost"]
        print(f"  {sid:<4} 总成本 {s.sum():>15,.2f} 元 | 日均 {s.mean():>10,.2f} | "
              f"相对DET {(s.sum() - base) / base * 100:+6.2f}% | "
              f"日成本CVaR95 {cvar(s.to_numpy()):>10,.2f}")

    # ---------- 三周期滚动模拟 ----------
    print("\n[3] 三周期滚动模拟（同尾窗口）")
    cyc = []
    for days, s0, s1 in PERIODS:
        wdates = [d for d in dates_eval if s0 <= d <= s1]
        for sid in ("DET", "R1", "R2", "R3"):
            s = daily_all[(daily_all.scheme_id == sid) & (daily_all.date.isin(wdates))]["cost"]
            cyc.append({"scheme_id": sid, "days": days, "start_date": s0, "end_date": s1,
                        "cost_total": round(float(s.sum()), 2),
                        "avg_daily": round(float(s.mean()), 2),
                        "max_daily": round(float(s.max()), 2),
                        "cvar95": round(cvar(s.to_numpy()), 2),
                        "std_daily": round(float(s.std()), 2)})
    cyc_df = pd.DataFrame(cyc)
    print(cyc_df.to_string(index=False))

    # ---------- 输出 q4_risk.csv（只填主方案 R2）----------
    main_plan = plans[MAIN_SCHEME]
    out = df[["date", "hour", "q_det"]].copy()
    qmap = {d: q for d, q in zip(main_plan["date"], main_plan["q"])}
    out["q_risk"] = [qmap[d][h] for d, h in zip(out["date"], out["hour"])]
    out["risk_measure"] = f"CVaR(α={ALPHA})"
    out["risk_param"] = f"λ={dict((k, l) for k, l, _ in SCHEMES)[MAIN_SCHEME]}"
    out["note"] = "残差情景 bootstrap，E[C]+λ·CVaR 网格寻优；与问题3 确定性申报对比"
    out["scheme_id"] = MAIN_SCHEME
    for c in ("q_det", "q_risk"):
        out[c] = out[c].round(4)
    out.to_csv(os.path.join(OUT, "q4_risk.csv"), index=False, encoding="utf-8-sig")

    # ---------- 输出 q4_plans.csv：三个风险偏好 + 确定性的逐时段电量 ----------
    # 目的：q4_cycle 报的是 R1/R2/R3 的成本，必须给出各自的逐时段电量才算可复算
    plans_out = df[["date", "hour", "q_det"]].copy()
    for sid, _, _ in SCHEMES:
        pm = {d: q for d, q in zip(plans[sid]["date"], plans[sid]["q"])}
        plans_out[f"q_{sid}"] = [pm[d][h] for d, h in zip(plans_out["date"], plans_out["hour"])]
    for c in ("q_det", "q_R1", "q_R2", "q_R3"):
        plans_out[c] = plans_out[c].round(4)
    plans_out.to_csv(os.path.join(OUT, "q4_plans.csv"), index=False, encoding="utf-8-sig")

    # ---------- 输出 q4_benchmark.csv：与"平凡规则"的对比 ----------
    # 独立验算指出：一条不需要价差预测的规则（恒报 1.2L_hat）可能胜过风险优化。
    # 这里把它固化成产物，供论文如实讨论"收益到底来自哪里"。
    from src.q1.solve import q_star as _qstar
    Lh = df["L_hat"].to_numpy(float)
    Ltrue = df["load_actual"].to_numpy(float)
    qcv = df["contract_q"].to_numpy(float)
    bench = [
        ("baseline", "按合约量申报", qcv, "合法", "不做任何调整"),
        ("det", "确定性申报（问题3）", df["q_det"].to_numpy(float), "合法", "点预测代入闭式解"),
        ("R1", "风险申报 λ=0", plans["R1"]["q"].tolist(), "合法", "E[C] 最小"),
        ("R2", "风险申报 λ=0.5（交付主方案）", plans["R2"]["q"].tolist(), "合法", "E[C]+0.5·CVaR95"),
        ("R3", "风险申报 λ=2.0", plans["R3"]["q"].tolist(), "合法", "E[C]+2·CVaR95"),
        ("up12", "恒报 1.2·L_hat（零模型）", 1.2 * Lh, "合法", "只信负荷预测，不看价差"),
        ("up12_qc", "恒报 max(1.2·L_hat, Qc)", np.maximum(1.2 * Lh, qcv), "合法", "同上且不低于合约量"),
        ("flat", "恒报 L_hat", Lh, "合法", "按预测负荷原样申报"),
        ("dn08", "恒报 0.8·L_hat", 0.8 * Lh, "合法", "系统性少报"),
        ("oracle12", "恒报 1.2·实际L", 1.2 * Ltrue, "**不合法**", "需知道实测值，仅作上界参考"),
        ("oracle", "完全信息最优（问题1）", _qstar(Ltrue, df["price_da"].to_numpy(float),
                                                 df["price_rt"].to_numpy(float), qcv), "**不合法**", "理论下界"),
    ]
    rows_bench = []
    for key, name, q, legal, desc in bench:
        qq = np.asarray(q, dtype=float).reshape(-1)   # plans 里是列表的列表，须摊平
        tot, rec = 0.0, 0.0
        for _, g in df.groupby("date", sort=False):
            r = settle_day_local(qq[g.index], g)
            tot += r[0]; rec += r[1]
        rows_bench.append({"key": key, "方案": name, "总成本": round(tot, 2),
                           "相对基准_pct": round((tot - base_all) / base_all * 100, 3),
                           "回收费用": round(rec, 2), "合法性": legal, "说明": desc})
    pd.DataFrame(rows_bench).to_csv(os.path.join(OUT, "q4_benchmark.csv"),
                                    index=False, encoding="utf-8-sig")
    print("\n[4] 与平凡规则的对比（基准 = 按合约量申报；详见 outputs/q4_benchmark.csv）")
    for r in rows_bench:
        print(f"  {r['方案']:<26} {r['总成本']:>15,.2f}  {r['相对基准_pct']:>+7.3f}%  [{r['合法性']}]")

    # ---------- 输出 q4_cycle.csv（3 方案 x 3 周期 = 9 行）----------
    ref = {("R1", 5): "§8.3 表8-1", ("R2", 5): "§8.3 表8-1", ("R3", 5): "§8.3 表8-1"}
    rows = []
    for _, r in cyc_df.iterrows():
        sid = r["scheme_id"]
        if sid == "DET":
            continue
        rows.append({
            "scheme_id": sid, "days": int(r["days"]),
            "start_date": r["start_date"], "end_date": r["end_date"],
            "cost_total": r["cost_total"],
            "risk_eval": f"日均 {r['avg_daily']:,.2f}；CVaR95 {r['cvar95']:,.2f}；"
                         f"日成本标准差 {r['std_daily']:,.2f}",
            "robustness": f"最大单日 {r['max_daily']:,.2f}；窗口内无缺失、无违约",
            "paper_ref": f"§8.3 表8-{int(r['days'])//5}",
        })
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "q4_cycle.csv"), index=False, encoding="utf-8-sig")

    # ---------- 图 ----------
    risk_out = out.merge(df[["date", "hour", "contract_q"]], on=["date", "hour"])
    make_figures(df, daily_all, cyc_df, risk_out)

    # ---------- 汇总指标：行 32–33（本文主方案 vs 确定性）----------
    det_all = daily_all[daily_all.scheme_id == "DET"]["cost"]
    r2_all = daily_all[daily_all.scheme_id == MAIN_SCHEME]["cost"]
    items = []
    for key, s, note in (("det", det_all, "问题3 确定性申报（基准对比）"),
                         ("risk", r2_all, f"问题4 风险申报 {MAIN_SCHEME}（主方案）")):
        items.append({
            "_key": key,
            "avg_daily_cost": round(float(s.mean()), 2),
            "cost_quantile": round(float(np.percentile(s, 90)), 2),
            "max_daily_cost": round(float(s.max()), 2),
            "tail_name": "CVaR(95%)",
            "tail_value": round(cvar(s.to_numpy()), 2),
            "risk_param": (f"λ={dict((k, l) for k, l, _ in SCHEMES)[MAIN_SCHEME]}"
                           if key == "risk" else "λ=0（确定性等价）"),
            "note": note,
        })
    update_summary(None, "q4_compare", items)

    print(f"\n产出：q4_risk.csv（{len(out)} 行）、q4_cycle.csv（{len(rows)} 行）、4 张图")
    return 0


if __name__ == "__main__":
    sys.exit(main())
