# -*- coding: utf-8 -*-
"""问题2：次日 24 小时实际用电量预测（T2.3–T2.7）。

## 三档信息条件（附件6 定义）
    A  仅附件2 历史用电 + 日期属性
    B  A + 附件3 预测信息（D 日可得）
    C  B + 附件3 实际运行信息（D-3 可得）

**三档用同一个模型族、只换特征**——这样误差差异才能归因到"信息"而非"模型"（T2.6）。

## 滚动回测
评估区间 2026-04-01 ~ 2026-08-31（153 天）。逐周重估一次：
对以 W 起始的那一周，训练样本取 `date <= W-5`（此时目标值已可观测），
预测该周每天的 24 个时段。特征本身已按 asof 规则滞后，不会泄漏。

## 产出
    outputs/q2_forecast.csv   3672 行（契约 §3.2，直接进附件6）
    outputs/q2_metrics.csv    三档 + 最终采用的误差指标
    outputs/q2_error_diag.csv 分时段 / 分日期类型的误差诊断
    outputs/figures/q2_*.png  论文用图
    outputs/summary.json      q2_metrics 区块

用法：<venv>/python.exe -m src.q2.solve
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common.env import use_project_tmp

use_project_tmp()

from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed  # noqa: E402
from src.common.summary_io import update_summary  # noqa: E402
from src.q2.features import FEAT_A, FEAT_B, FEAT_C, build_panel  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

EVAL_START = "2026-04-01"
EVAL_END = "2026-08-31"
REFIT_DAYS = 7          # 逐周重估
TRAIN_LAG = 5           # 训练样本的 date 必须 <= W-5（目标值届时可观测）
SEED = 42

SCHEMES = [
    ("A", FEAT_A, "仅历史用电+日期属性"),
    ("B", FEAT_B, "A+系统预测信息"),
    ("C", FEAT_C, "C=A+B+系统实际信息(D-3)"),
]


# ---------------------------------------------------------------- 指标
def metrics(y, yhat):
    e = yhat - y
    ae = np.abs(e)
    with np.errstate(divide="ignore", invalid="ignore"):
        mape = np.mean(ae[np.abs(y) >= 0.1] / np.abs(y[np.abs(y) >= 0.1])) * 100
    return {
        "MAE": float(ae.mean()),
        "RMSE": float(np.sqrt(np.mean(e ** 2))),
        "WMAPE": float(ae.sum() / np.abs(y).sum() * 100),
        "MAPE": float(mape),
    }


# ---------------------------------------------------------------- 基线
def build_baseline(panel: pd.DataFrame) -> pd.Series:
    """朴素基线：同日期类型、同时段的近 28 天均值（窗口截止到 D-5）。

    做法：对每种 day_type 建一张 (日期x时段) 的掩码宽表，做 28 天滚动均值，
    再 shift(5) 使 D 日的取值只用到 <=D-5 的样本。
    """
    out = pd.Series(np.nan, index=panel.index)
    dt = panel["day_type_code"].values
    dates = sorted(panel["date"].unique())
    lw = panel.pivot_table(index="date", columns="hour", values="load_actual",
                           aggfunc="last").sort_index()

    per_type = {}
    for t in sorted(panel["day_type_code"].unique()):
        mask = pd.Series(
            [1 if panel[(panel["date"] == d)]["day_type_code"].iloc[0] == t else 0
             for d in lw.index], index=lw.index)
        masked = lw.where(mask.astype(bool))
        rm = masked.rolling(28, min_periods=1).mean().shift(TRAIN_LAG)
        per_type[t] = rm

    for t, rm in per_type.items():
        sel = panel["day_type_code"].values == t
        idx = panel.loc[sel, ["date", "hour"]]
        vals = rm.stack(future_stack=True).rename("v").reset_index()
        merged = idx.merge(vals, on=["date", "hour"], how="left")
        out.loc[sel] = merged["v"].values

    # 兜底：滚动均值 -> 同期滞后值
    fallback = panel["roll7_mean"].fillna(panel["lag5"])
    return out.fillna(fallback)


# ---------------------------------------------------------------- 滚动回测
def walk_forward(panel: pd.DataFrame, feats, label: str):
    """逐周重估的滚动回测，返回 (预测 DataFrame[date,hour,yhat], 训练记录)。"""
    from sklearn.ensemble import HistGradientBoostingRegressor

    dates = sorted(panel["date"].unique())
    eval_dates = [d for d in dates if EVAL_START <= d <= EVAL_END]
    recs = []
    week_start = 0
    i = 0
    while i < len(eval_dates):
        week = eval_dates[i:i + REFIT_DAYS]
        W = week[0]
        # 训练截止：W 往前数 TRAIN_LAG 天（该日及以前的目标值已可观测）
        pos = dates.index(W)
        train_end = dates[max(0, pos - TRAIN_LAG)]
        tr = panel[panel["date"] <= train_end].dropna(subset=["load_actual"])
        te = panel[panel["date"].isin(week)]

        model = HistGradientBoostingRegressor(
            max_iter=300, learning_rate=0.06, max_leaf_nodes=31,
            min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
        model.fit(tr[feats], tr["load_actual"])
        pred = np.clip(model.predict(te[feats]), 0, None)

        frame = te[["date", "hour"]].copy()
        frame["yhat"] = pred
        frame["scheme"] = label
        recs.append(frame)
        i += REFIT_DAYS

    return pd.concat(recs, ignore_index=True)


# ---------------------------------------------------------------- 作图
def make_figures(panel, pred_all, metrics_df, best_pred, best_sid):
    apply_style()
    dates = sorted(panel["date"].unique())

    # 图1：三档预测对比（选一段代表期）
    seg_start, seg_end = "2026-07-01", "2026-07-07"
    seg = pred_all[(pred_all["date"] >= seg_start) & (pred_all["date"] <= seg_end)]
    fig, ax = new_fig(figsize=(8.6, 3.8))
    for i, (sid, feats, desc) in enumerate(SCHEMES):
        s = seg[seg["scheme"] == sid].sort_values(["date", "hour"])
        ax.plot(range(len(s)), s["yhat"].to_numpy(), lw=1.0, color=TOL[i], label=f"方案{sid}")
    truth = seg[seg["scheme"] == "A"].sort_values(["date", "hour"])["y"].to_numpy()
    ax.plot(range(len(truth)), truth, color="black", lw=1.2, ls="--", label="实际值")
    ax.set_xlabel("时段序号（2026-07-01 起连续 7 天 x 24 小时）")
    ax.set_ylabel("用电量（MWh）")
    ax.legend(fontsize=7, ncol=4)
    save_fig(fig, "q2_三档预测对比")

    # 图2：误差指标对比
    fig, axes = new_fig(1, 2, figsize=(9, 3.2))
    m = metrics_df[metrics_df["scheme"].isin(["A", "B", "C"])]
    axes[0].bar(m["scheme"], m["MAE"], color=[TOL[0], TOL[1], TOL[2]], width=0.55)
    axes[0].set_ylabel("MAE（MWh）")
    axes[0].set_xlabel("信息条件")
    axes[1].bar(m["scheme"], m["WMAPE"], color=[TOL[0], TOL[1], TOL[2]], width=0.55)
    axes[1].set_ylabel("WMAPE（%）")
    axes[1].set_xlabel("信息条件")
    save_fig(fig, "q2_误差对比")

    # 图3：最终采用方案的预测 vs 实际（散点 + 分时段偏差）
    f = best_pred.rename(columns={"yhat": "yhat"})
    fig, axes = new_fig(1, 2, figsize=(9, 3.6))
    axes[0].scatter(f["y"], f["yhat"], s=3, alpha=0.35, color=TOL[0])
    lim = [min(f["y"].min(), f["yhat"].min()) * 0.95, max(f["y"].max(), f["yhat"].max()) * 1.05]
    axes[0].plot(lim, lim, "k--", lw=0.8)
    axes[0].set_xlabel("实际用电量（MWh）")
    axes[0].set_ylabel("预测用电量（MWh）")
    axes[0].set_xlim(lim)
    axes[0].set_ylim(lim)

    err_by_hour = (f["yhat"] - f["y"]).groupby(f["hour"]).mean()
    axes[1].bar(err_by_hour.index, err_by_hour.values, color=TOL[1], width=0.7)
    axes[1].axhline(0, color="black", lw=0.8)
    axes[1].set_xlabel("时段")
    axes[1].set_ylabel("平均误差（MWh）")
    save_fig(fig, "q2_预测诊断")


# ---------------------------------------------------------------- 入口
def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(SEED)
    os.makedirs(OUT, exist_ok=True)

    print("=" * 66)
    print("问题2 · 次日 24 小时用电量预测")
    print("=" * 66)

    panel = build_panel()
    print(f"面板：{panel.shape[0]} 行 x {panel.shape[1]} 列（{panel['date'].nunique()} 天）")

    # 真实值表（评估区间）
    truth = panel[(panel["date"] >= EVAL_START) & (panel["date"] <= EVAL_END)][
        ["date", "hour", "load_actual"]].rename(columns={"load_actual": "y"})

    # ---- 基线 ----
    base = build_baseline(panel)
    panel = panel.assign(baseline=base)
    bl = panel[(panel["date"] >= EVAL_START) & (panel["date"] <= EVAL_END)][
        ["date", "hour", "baseline"]]
    bl_df = truth.merge(bl, on=["date", "hour"])
    m_base = metrics(bl_df["y"].to_numpy(), bl_df["baseline"].to_numpy())
    print(f"\n基线（同类型同时段近 28 天均值）：MAE={m_base['MAE']:.4f}  "
          f"WMAPE={m_base['WMAPE']:.2f}%  MAPE={m_base['MAPE']:.2f}%")

    # ---- 三档模型 ----
    preds = {}
    rows = [{"scheme": "baseline", "desc": "同类型同时段近28天均值",
             **m_base}]
    for sid, feats, desc in SCHEMES:
        pr = walk_forward(panel, feats, sid)
        merged = truth.merge(pr, on=["date", "hour"])
        assert len(merged) == len(truth) == 3672, f"方案{sid} 覆盖不完整：{len(merged)}"
        m = metrics(merged["y"].to_numpy(), merged["yhat"].to_numpy())
        preds[sid] = merged
        rows.append({"scheme": sid, "desc": desc, **m})
        print(f"方案{sid}：MAE={m['MAE']:.4f}  RMSE={m['RMSE']:.4f}  "
              f"WMAPE={m['WMAPE']:.2f}%  MAPE={m['MAPE']:.2f}%")

    metrics_df = pd.DataFrame(rows)

    # ---- 选最终方案：按 MAE 最小（DECISIONS 口径 #5，事先声明）----
    cand = metrics_df[metrics_df["scheme"].isin(["A", "B", "C"])]
    best = cand.loc[cand["MAE"].idxmin(), "scheme"]
    print(f"\n按 MAE 最小，最终采用：方案 {best}")

    out = preds["A"][["date", "hour"]].copy()
    for sid, _, _ in SCHEMES:
        out[f"pred_{sid}"] = preds[sid]["yhat"].to_numpy()
    out["pred_final"] = preds[best]["yhat"].to_numpy()
    mb = metrics_df.set_index("scheme")
    out["note"] = (f"最终采用方案{best}（GBDT，{dict((s, d) for s, _, d in SCHEMES)[best]}）；"
                   f"MAE A/B/C={mb.loc['A','MAE']:.2f}/{mb.loc['B','MAE']:.2f}/{mb.loc['C','MAE']:.2f}")

    for c in ["pred_A", "pred_B", "pred_C", "pred_final"]:
        out[c] = out[c].round(4)
    out = out.sort_values(["date", "hour"]).reset_index(drop=True)
    out.to_csv(os.path.join(OUT, "q2_forecast.csv"), index=False, encoding="utf-8-sig")

    # ---- 误差诊断（分时段 / 分日期类型）----
    fin = preds[best].merge(panel[["date", "hour", "day_type_code"]], on=["date", "hour"])
    fin["err"] = fin["yhat"] - fin["y"]
    def _diag(g, dim, col):
        return pd.DataFrame({
            "维度": dim, "取值": g[col].to_numpy(),
            "MAE": g["err"].abs().to_numpy(),
            "平均误差": g["err"].to_numpy(),
            "样本数": g["err"].size,
        })

    dh = (fin.groupby("hour")["err"]
          .agg(MAE=lambda x: x.abs().mean(), 平均误差="mean", 样本数="size")
          .reset_index().rename(columns={"hour": "取值"}))
    dh.insert(0, "维度", "hour")
    dty = (fin.groupby("day_type_code")["err"]
           .agg(MAE=lambda x: x.abs().mean(), 平均误差="mean", 样本数="size")
           .reset_index().rename(columns={"day_type_code": "取值"}))
    dty.insert(0, "维度", "day_type")
    diag = pd.concat([dh, dty], ignore_index=True)

    diag.to_csv(os.path.join(OUT, "q2_error_diag.csv"), index=False, encoding="utf-8-sig")
    metrics_df.to_csv(os.path.join(OUT, "q2_metrics.csv"), index=False, encoding="utf-8-sig")

    # ---- 信息增量（T2.6）----
    print("\n信息增量（相对方案A 的 MAE 降幅）：")
    for sid in ("B", "C"):
        drop = (mb.loc["A", "MAE"] - mb.loc[sid, "MAE"]) / mb.loc["A", "MAE"] * 100
        print(f"  A -> {sid}: {drop:+.2f}%")

    # ---- 图 ----
    # preds 里每个方案都已 merge 过 truth，自带 y 列，无需再 merge
    pred_final = pd.concat(preds.values(), ignore_index=True)
    make_figures(panel, pred_final, metrics_df, preds[best], best)

    # ---- 汇总指标 ----
    items = []
    for sid, key in (("A", "A"), ("B", "B"), ("C", "C")):
        r = mb.loc[sid]
        items.append({"_key": key, "mae": round(r["MAE"], 4), "rmse": round(r["RMSE"], 4),
                      "wmape": round(r["WMAPE"], 4), "other_name": "MAPE",
                      "other_value": round(r["MAPE"], 4),
                      "note": dict((s, d) for s, _, d in SCHEMES)[sid]})
    r = mb.loc[best]
    items.append({"_key": "final", "mae": round(r["MAE"], 4), "rmse": round(r["RMSE"], 4),
                  "wmape": round(r["WMAPE"], 4), "other_name": "MAPE",
                  "other_value": round(r["MAPE"], 4), "note": f"采用方案{best}（MAE 最小）"})
    update_summary(None, "q2_metrics", items)

    print(f"\n产出：q2_forecast.csv（{len(out)} 行）、q2_metrics.csv、q2_error_diag.csv、3 张图")
    return 0


if __name__ == "__main__":
    sys.exit(main())
