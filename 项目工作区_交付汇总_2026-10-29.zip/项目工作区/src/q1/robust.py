# -*- coding: utf-8 -*-
"""问题一的稳健性检验：结论是否被单日或极端价差撑起？

背景（G7 盲评提出）：2026-04-07 的日均价差为 +973 元/MWh，按全样本均值 +10.2、
标准差 137.4 计，偏离约 34 个标准误；该日节省 134,752 元，占 5 日总节省的 52.2%。
因此"节省 15.28%"这一结论可能高度依赖单日，需要做稳健性检验。

本脚本做两组：
  1. **留一法**：逐一剔除一个典型日，重算其余各日的合计节省率
  2. **价差裁剪（winsorize）**：把每个时段价差裁剪到 ±k 倍标准差，重算最优申报

输出 `outputs/q1_robust.csv`，不改动主结果。

用法：<venv>/python.exe -m src.q1.robust
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day
from src.q1.solve import baseline_day, solve_day

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")


def day_pair(df, lam0=0.20):
    """返回某日 (最优成本, 按合约量成本)。"""
    out, r = solve_day(df, lam0)
    return r["sums"]["total"], baseline_day(df, lam0)["total"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = io.load_attachments()
    df_all = data["att1"].copy()

    per_day = {}
    for d, df in df_all.groupby("date"):
        per_day[d] = day_pair(df)

    opt = sum(v[0] for v in per_day.values())
    base = sum(v[1] for v in per_day.values())
    saving = base - opt

    rows = []
    # ---------- 1. 留一法 ----------
    for drop in per_day:
        o = sum(v[0] for k, v in per_day.items() if k != drop)
        b = sum(v[1] for k, v in per_day.items() if k != drop)
        rows.append({"检验": "留一法", "剔除或参数": f"剔除 {drop}",
                     "剩余天数": len(per_day) - 1,
                     "最优成本": round(o, 2), "基准成本": round(b, 2),
                     "节省额": round(b - o, 2), "节省率_pct": round((b - o) / b * 100, 3)})

    # ---------- 2. 价差裁剪 ----------
    S_all = (df_all["price_rt"] - df_all["price_da"]).to_numpy(float)
    mu, sd = S_all.mean(), S_all.std()
    for k in (1.0, 2.0, 3.0, 5.0):
        d2 = df_all.copy()
        S = (d2["price_rt"] - d2["price_da"]).to_numpy(float)
        Sc = np.clip(S, mu - k * sd, mu + k * sd)
        d2["price_rt"] = d2["price_da"] + Sc
        o = b = 0.0
        for _, gdf in d2.groupby("date"):
            oo, bb = day_pair(gdf)
            o += oo; b += bb
        rows.append({"检验": "价差裁剪", "剔除或参数": f"±{k:.0f}σ",
                     "剩余天数": len(per_day),
                     "最优成本": round(o, 2), "基准成本": round(b, 2),
                     "节省额": round(b - o, 2), "节省率_pct": round((b - o) / b * 100, 3)})

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q1_robust.csv"), index=False, encoding="utf-8-sig")

    print("=" * 72)
    print("问题一 稳健性检验")
    print("=" * 72)
    print(f"全样本：最优 {opt:,.2f} | 基准 {base:,.2f} | 节省 {saving:,.2f}（{saving / base * 100:.3f}%）")
    print(f"全样本价差：均值 {mu:.2f}，标准差 {sd:.2f}")
    print()
    print(out.to_string(index=False))
    print()
    lo = out[out["检验"] == "留一法"]["节省率_pct"]
    print(f"留一法节省率区间：{lo.min():.2f}% ~ {lo.max():.2f}%（全样本 {saving / base * 100:.2f}%）")
    print(f"\n产出：{os.path.join(OUT, 'q1_robust.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
