# -*- coding: utf-8 -*-
"""问题1：完全信息下的最优日前申报（T1）。

## 模型

单时段成本（口径见 DECISIONS.md）：

    C_t(q) = Qc_t·Pc_t + (q - Qc_t)·P_DA_t + (L_t - q)·P_RT_t + R_t(q)

    R_t(q) =  S_t·max(0, q - (1+lambda0)L_t)      若 S_t > 0
             (-S_t)·max(0, (1-lambda0)L_t - q)    若 S_t < 0
             0                               若 S_t = 0

记 S_t = P_RT_t - P_DA_t，lambda0 = 20%。

## 定解（字典序：先最小化成本，再最小化 |q - Qc|）

    S_t > 0 : q* = max(Qc_t, (1+lambda0)L_t)
    S_t < 0 : q* = max(0, min(Qc_t, (1-lambda0)L_t))
    S_t = 0 : q* = Qc_t

经济含义：把合约量"夹进"允许偏差带内，朝有利价差那一侧夹；已在带内则不动。

## 带总额度约束

若另加每日总调整额度 Σ_t|q_t - Qc_t| <= K（口径 #2，主模型不设硬值、仅作敏感性），
24 时段通过该约束耦合，闭式解不再适用，改用线性规划（pulp/CBC）求解。

## 产出

    outputs/q1_bid.csv            120 行（契约 §3.1，直接进附件6）
    outputs/q1_cost.csv           5 行日汇总
    outputs/q1_sens_spread.csv    价差倍数敏感性
    outputs/q1_sens_K.csv         总额度 K 敏感性
    outputs/q1_sens_lam0.csv      允许偏差率 lambda0 敏感性
    outputs/q1_sens_qbar.csv      申报上限 q 对照（被否决方案）
    outputs/figures/q1_*.png      论文用图
    outputs/summary.json          q1_cost 区块

用法：<venv>/python.exe -m src.q1.solve
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.env import use_project_tmp

use_project_tmp()   # pulp 的 CBC 会写临时 .mps/.sol，必须避开 AppData\Local\Temp

from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed  # noqa: E402
from src.common.settle import LAM0, settle_day  # noqa: E402
from src.common.summary_io import update_summary  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")


# ---------------------------------------------------------------- 模型
def q_star(L, p_da, p_rt, qc, lam0=LAM0):
    """字典序定解下的单时段最优申报量（闭式）。"""
    L = np.asarray(L, dtype=float)
    qc = np.asarray(qc, dtype=float)
    S = np.asarray(p_rt, dtype=float) - np.asarray(p_da, dtype=float)

    up = (1 + lam0) * L
    dn = (1 - lam0) * L
    q_up = np.maximum(qc, up)
    q_dn = np.maximum(0.0, np.minimum(qc, dn))
    return np.where(S > 0, q_up, np.where(S < 0, q_dn, qc))


def solve_day(df, lam0=LAM0):
    """给定一个典型日的完全信息，返回逐时段结果 DataFrame。"""
    L = df["load_actual"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)

    q = q_star(L, pda, prt, qc, lam0)
    r = settle_day(q, L, pda, prt, qc, pc, lam0)

    out = df[["date", "hour"]].copy()
    out["q_bid"] = q
    out["cost_contract"] = r["contract"]
    out["cost_da_dev"] = r["da_dev"]
    out["cost_rt_dev"] = r["rt_dev"]
    out["cost_recovery"] = r["recovery"]
    out["cost_total"] = r["total"]
    return out, r


# ---------------------------------------------------------------- 带约束（LP）
def solve_day_lp(df, K=None, qbar=None, lam0=LAM0):
    """线性规划求解：可加总额度 K 和申报上限 q（后者仅作对照）。

    K : 每日总调整额度 Σ|q_t - Qc_t| 的上限；None 表示不约束
    qbar : 申报上限数组/标量；None 表示不约束
    """
    import pulp

    L = df["load_actual"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    S = prt - pda
    n = len(df)

    prob = pulp.LpProblem("q1", pulp.LpMinimize)
    up = [None if qbar is None else (float(qbar) if np.isscalar(qbar) else float(qbar[t]))
          for t in range(n)]
    q = [pulp.LpVariable(f"q{t}", lowBound=0, upBound=up[t]) for t in range(n)]
    r = [pulp.LpVariable(f"r{t}", lowBound=0) for t in range(n)]
    d = [pulp.LpVariable(f"d{t}", lowBound=0) for t in range(n)]

    prob += pulp.lpSum((q[t] - qc[t]) * pda[t] + (L[t] - q[t]) * prt[t] + r[t]
                       for t in range(n))

    for t in range(n):
        if S[t] > 0:
            prob += r[t] >= S[t] * (q[t] - (1 + lam0) * L[t])
        elif S[t] < 0:
            prob += r[t] >= (-S[t]) * ((1 - lam0) * L[t] - q[t])
        else:
            prob += r[t] == 0
        prob += d[t] >= q[t] - qc[t]
        prob += d[t] >= qc[t] - q[t]

    if K is not None:
        prob += pulp.lpSum(d) <= float(K)

    status = prob.solve(pulp.PULP_CBC_CMD(msg=False))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(f"LP 未取得最优解：{pulp.LpStatus[status]}")

    qv = np.array([v.value() for v in q])
    return settle_day(qv, L, pda, prt, qc, pc, lam0)["sums"], qv


# ---------------------------------------------------------------- 主流程
def baseline_day(df, lam0=LAM0):
    """对照基准：直接按合约量申报（q = Qc），即"不做任何调整"的策略。"""
    L = df["load_actual"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    return settle_day(qc, L, df["price_da"].to_numpy(float),
                      df["price_rt"].to_numpy(float), qc,
                      df["contract_p"].to_numpy(float), lam0)["sums"]


def daily_summary(bid: pd.DataFrame) -> pd.DataFrame:
    g = bid.groupby("date", as_index=False).agg(
        cost_contract=("cost_contract", "sum"),
        cost_da_dev=("cost_da_dev", "sum"),
        cost_rt_dev=("cost_rt_dev", "sum"),
        cost_recovery=("cost_recovery", "sum"),
        cost_total=("cost_total", "sum"),
        q_sum=("q_bid", "sum"),
    )
    return g


def sens_spread(df_all, thetas=(0.0, 0.5, 1.0, 1.5, 2.0), lam0=LAM0):
    """价差敏感性：P_RT' = P_DA + θ·S（θ 缩放价差）。"""
    rows = []
    for th in thetas:
        tot, rec = 0.0, 0.0
        for d, df in df_all.groupby("date"):
            d2 = df.copy()
            S = d2["price_rt"] - d2["price_da"]
            d2["price_rt"] = d2["price_da"] + th * S
            _, r = solve_day(d2, lam0)
            tot += r["sums"]["total"]
            rec += r["sums"]["recovery"]
        rows.append({"theta": th, "total_cost": tot, "recovery": rec})
    return pd.DataFrame(rows)


def sens_K(df_all, kappas=(0.0, 0.25, 0.5, 0.75, 1.0), lam0=LAM0):
    """总额度敏感性：K = κ x 无约束最优的调整量之和。κ 越小越紧。"""
    rows = []
    for d, df in df_all.groupby("date"):
        base, _ = solve_day(df, lam0)
        qc = df["contract_q"].to_numpy(float)
        A0 = float(np.abs(base["q_bid"].to_numpy(float) - qc).sum())
        for kp in list(kappas) + [np.inf]:
            if np.isinf(kp):
                r = settle_day(base["q_bid"].to_numpy(float),
                               df["load_actual"].to_numpy(float),
                               df["price_da"].to_numpy(float),
                               df["price_rt"].to_numpy(float),
                               qc, df["contract_p"].to_numpy(float), lam0)["sums"]
                qsum = float(base["q_bid"].sum())
            else:
                K = kp * A0
                r, qv = solve_day_lp(df, K=K, lam0=lam0)
                qsum = float(qv.sum())
                adjust = float(np.abs(qv - qc).sum())
            if np.isinf(kp):
                adjust = A0
            rows.append({"date": d, "kappa": kp,
                         "K": (kp * A0 if np.isfinite(kp) else np.inf),
                         "adjust": adjust,
                         "total_cost": r["total"], "recovery": r["recovery"], "q_sum": qsum})
    return pd.DataFrame(rows)


def sens_lam0(df_all, lam0s=(0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5)):
    """允许偏差率 lambda0 敏感性（lambda0 变化同时改变 R_t 触发边界）。"""
    rows = []
    for l0 in lam0s:
        tot, rec, qs = 0.0, 0.0, 0.0
        for d, df in df_all.groupby("date"):
            out, r = solve_day(df, l0)
            tot += r["sums"]["total"]
            rec += r["sums"]["recovery"]
            qs += float(out["q_bid"].sum())
        rows.append({"lam0": l0, "total_cost": tot, "recovery": rec, "q_sum": qs})
    return pd.DataFrame(rows)


def sens_qbar(df_all, betas=(1.0, 1.2, 1.5, 2.0, 3.0), lam0=LAM0):
    """申报上限 q = β·Qc 的对照方案（口径 #1 中被否决的读法）。"""
    rows = []
    for b in list(betas) + [np.inf]:
        tot, rec, qs = 0.0, 0.0, 0.0
        for d, df in df_all.groupby("date"):
            if np.isinf(b):
                out, r = solve_day(df, lam0)
                qsum = float(out["q_bid"].sum())
                tot += r["sums"]["total"]
                rec += r["sums"]["recovery"]
                qs += qsum
            else:
                cap = b * df["contract_q"].to_numpy(float)
                r, qv = solve_day_lp(df, qbar=cap, lam0=lam0)
                tot += r["total"]
                rec += r["recovery"]
                qs += float(qv.sum())
        rows.append({"beta": b, "total_cost": tot, "recovery": rec, "q_sum": qs})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- 作图
def make_figures(bid, cost_daily, s_spread, s_K, s_lam0, df_all):
    apply_style()
    days = sorted(bid["date"].unique())

    # 图1：申报量 vs 合约量 vs 实际负荷
    fig, axes = new_fig(2, 3, figsize=(11, 6))
    axes = axes.ravel()
    for i, d in enumerate(days):
        ax = axes[i]
        sub = bid[bid["date"] == d].sort_values("hour")
        src = df_all[df_all["date"] == d].sort_values("hour")
        ax.plot(sub["hour"], src["load_actual"], color=TOL[6], lw=1.2, label="实际用电量")
        ax.plot(sub["hour"], src["contract_q"], color=TOL[0], lw=1.2, ls="--", label="合约电量")
        ax.plot(sub["hour"], sub["q_bid"], color=TOL[1], lw=1.8, label="最优申报量")
        ax.set_title(f"{d}（{src['day_type'].iloc[0]}）")
        ax.set_xlabel("时段")
        ax.set_ylabel("电量（MWh）")
        if i == 0:
            ax.legend(fontsize=7, loc="upper left")
    axes[5].axis("off")
    save_fig(fig, "q1_申报量对比")

    # 图2：成本构成（正负分向堆叠——实时偏差电费可能为负，普通堆叠会画反）
    fig, ax = new_fig(figsize=(8.4, 4.2))
    x = np.arange(len(cost_daily))
    comp = [("cost_contract", "中长期合约电费", TOL[0]),
            ("cost_da_dev", "日前偏差电费", TOL[2]),
            ("cost_rt_dev", "实时偏差电费", TOL[3]),
            ("cost_recovery", "偏差风险调整费用", TOL[1])]
    pos = np.zeros(len(cost_daily))
    neg = np.zeros(len(cost_daily))
    for col, lab, c in comp:
        v = cost_daily[col].to_numpy(float)
        up = np.where(v >= 0, v, 0.0)
        dn = np.where(v < 0, v, 0.0)
        ax.bar(x, up, bottom=pos, color=c, label=lab, width=0.6)
        ax.bar(x, dn, bottom=neg, color=c, width=0.6)
        pos += up
        neg += dn
    # 净额单独用轮廓柱画在右侧：正值堆叠 - 负值堆叠 = 净额，避免读者自己心算
    ax.bar(x + 0.34, cost_daily["cost_total"].to_numpy(float), width=0.24,
           color="none", edgecolor="black", lw=1.0, label="日总成本（净额）", zorder=5)
    ax.set_xticks(x)
    ax.set_xticklabels([d[5:] for d in cost_daily["date"]])
    ax.set_xlabel("典型日（月-日）")
    ax.set_ylabel("成本（元）")
    ax.axhline(0, color="black", lw=0.8)
    ax.legend(fontsize=7, loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False)
    save_fig(fig, "q1_成本构成")

    # 图3：三组敏感性
    fig, axes = new_fig(1, 3, figsize=(11, 3.4))
    ax = axes[0]
    ax.plot(s_spread["theta"], s_spread["total_cost"], "o-", color=TOL[0])
    ax.set_xlabel("价差缩放倍数")
    ax.set_ylabel("5 日总成本（元）")

    ax = axes[1]
    d0 = s_K[s_K["kappa"] == 0].iloc[0]["date"] if "date" in s_K else None
    for i, d in enumerate(sorted(s_K["date"].unique())[:3]):
        sub = s_K[s_K["date"] == d].sort_values("kappa")
        xs = [k if np.isfinite(k) else sub["kappa"].max() * 1.2 for k in sub["kappa"]]
        ax.plot(xs, sub["total_cost"], "o-", color=TOL[i], label=d[5:])
    ax.set_xlabel("调整额度系数 κ")
    ax.set_ylabel("日总成本（元）")
    ax.legend(fontsize=7)

    ax = axes[2]
    ax.plot(s_lam0["lam0"], s_lam0["total_cost"], "o-", color=TOL[2])
    ax.set_xlabel("允许偏差率")
    ax.set_ylabel("5 日总成本（元）")

    save_fig(fig, "q1_敏感性")


# ---------------------------------------------------------------- 入口
def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(42)
    os.makedirs(OUT, exist_ok=True)

    data = io.load_attachments()
    df_all = data["att1"].copy()

    # ---- 主结果 ----
    parts = []
    for d, df in df_all.groupby("date"):
        out, _ = solve_day(df)
        parts.append(out)
    bid = pd.concat(parts, ignore_index=True)
    # 先用**未舍入**的值做日汇总，保证 q1_cost.csv 里的逐日/合计是真实经济值；
    # 再对明细做舍入（填表器要求每行四项之和严格等于该行总成本）
    cost_daily = daily_summary(bid)

    bid["q_bid"] = bid["q_bid"].round(6)
    for c in ("cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery"):
        bid[c] = bid[c].round(2)
    bid["cost_total"] = (bid["cost_contract"] + bid["cost_da_dev"]
                         + bid["cost_rt_dev"] + bid["cost_recovery"]).round(2)
    bid.to_csv(os.path.join(OUT, "q1_bid.csv"), index=False, encoding="utf-8-sig")

    # 与"按合约量申报"基准对照
    base = {d: baseline_day(df)["total"] for d, df in df_all.groupby("date")}
    cost_daily["baseline_total"] = cost_daily["date"].map(base).round(2)
    cost_daily["saving"] = (cost_daily["baseline_total"] - cost_daily["cost_total"]).round(2)
    cost_daily["saving_pct"] = (cost_daily["saving"] / cost_daily["baseline_total"] * 100).round(2)
    cost_daily = cost_daily[[
        "date", "cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery",
        "cost_total", "baseline_total", "saving", "saving_pct", "q_sum"]]
    cost_daily.to_csv(os.path.join(OUT, "q1_cost.csv"), index=False, encoding="utf-8-sig")

    print("=" * 66)
    print("问题1 · 完全信息下的最优日前申报")
    print("=" * 66)
    print(cost_daily[["date", "cost_contract", "cost_da_dev", "cost_rt_dev",
                      "cost_recovery", "cost_total", "baseline_total",
                      "saving", "saving_pct"]].to_string(index=False))
    tot = cost_daily["cost_total"].sum()
    bl = cost_daily["baseline_total"].sum()
    print(f"\n5 日总成本：优化 {tot:,.2f} 元 | 基准（按合约量）{bl:,.2f} 元 "
          f"| 节省 {bl - tot:,.2f} 元（{(bl - tot) / bl * 100:.2f}%）")

    # ---- 敏感性 ----
    s_spread = sens_spread(df_all)
    s_K = sens_K(df_all)
    s_lam0 = sens_lam0(df_all)
    s_qbar = sens_qbar(df_all)

    for name, df in (("q1_sens_spread.csv", s_spread), ("q1_sens_K.csv", s_K),
                     ("q1_sens_lam0.csv", s_lam0), ("q1_sens_qbar.csv", s_qbar)):
        df.to_csv(os.path.join(OUT, name), index=False, encoding="utf-8-sig")

    print("\n敏感性（价差倍数 θ）：")
    print(s_spread.round(2).to_string(index=False))
    print("\n敏感性（lambda0）：")
    print(s_lam0.round(2).to_string(index=False))

    # ---- 图 ----
    make_figures(bid, cost_daily, s_spread, s_K, s_lam0, df_all)

    # ---- 汇总指标 ----
    items = []
    for _, r in cost_daily.iterrows():
        energy = r["cost_contract"] + r["cost_da_dev"] + r["cost_rt_dev"]
        items.append({
            "date": r["date"],
            "energy_cost": round(float(energy), 2),
            "recovery": round(float(r["cost_recovery"]), 2),
            "total": round(float(r["cost_total"]), 2),
            "note": "字典序定解：合约量夹进 +/-20% 带",
        })
    update_summary(None, "q1_cost", items)

    print(f"\n产出：q1_bid.csv（{len(bid)} 行）、q1_cost.csv（{len(cost_daily)} 行）、"
          f"4 个敏感性表、3 张图")
    return 0


if __name__ == "__main__":
    sys.exit(main())
