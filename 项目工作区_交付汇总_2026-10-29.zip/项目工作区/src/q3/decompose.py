# -*- coding: utf-8 -*-
"""问题3 的 2x2 误差分解（T3.7 补充产物）。

为什么单独成文：这个分解是 T3 结论的核心证据（"用电量预测贡献 -5.30%，价差误差把收益全部吃掉"），
但它原来只写在报告里，没有可追溯的产物文件。这里把它固化成 `outputs/q3_decompose.csv`，
使论文引用的每个数字都能从数据复现。

四象限取自「用什么 L 决策」x「用什么 S 决策」：
    q 由闭式解 max(Qc, (1+lambda0)L) / max(0, min(Qc, (1-lambda0)L)) 决定，其中 L、S 分别取实测值或预测值；
    所有方案都用**实测** L / P_DA / P_RT 事后结算。

用法：<venv>/python.exe -m src.q3.decompose
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day
from src.q1.solve import q_star
from src.q3.solve import deterministic_bid

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")


def settle_total(df, q):
    """按实测值结算一组申报量，返回 153 天总成本。"""
    tot = 0.0
    for _, g in df.groupby("date", sort=False):
        tot += settle_day(q[g.index], g["load_actual"].to_numpy(float),
                          g["price_da"].to_numpy(float), g["price_rt"].to_numpy(float),
                          g["contract_q"].to_numpy(float), g["contract_p"].to_numpy(float))["sums"]["total"]
    return float(tot)


def main():
    sys.stdout.reconfigure(encoding="utf-8")

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")[
        ["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")[
        ["date", "hour", "pred_spread_final"]].rename(columns={"pred_spread_final": "S_hat"})
    data = io.load_attachments()

    df = (q2.merge(q3, on=["date", "hour"])
            .merge(data["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
            .merge(data["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
            .merge(data["att5"][["date", "hour", "contract_q", "contract_p"]], on=["date", "hour"]))
    df["S_actual"] = df["price_rt"] - df["price_da"]
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    L = df["load_actual"].to_numpy(float)
    Lh = df["L_hat"].to_numpy(float)
    S = df["S_actual"].to_numpy(float)
    Sh = df["S_hat"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)

    plans = [
        ("A_oracle", "实L+实S", "完全信息最优（理论下界）", q_star(L, pda, prt, qc)),
        ("B_spread_only", "实L+预S", "仅含价差预测误差", deterministic_bid(L, Sh, qc)),
        ("C_load_only", "预L+实S", "仅含用电量预测误差", deterministic_bid(Lh, S, qc)),
        ("D_both", "预L+预S", "本文确定性申报（两者都有）", deterministic_bid(Lh, Sh, qc)),
        ("E_baseline", "按合约量", "不做任何调整（对照基准）", qc),
    ]

    rows = []
    for key, combo, desc, q in plans:
        cost = settle_total(df, q)
        rows.append({"key": key, "组合": combo, "说明": desc,
                     "总成本": round(cost, 2),
                     "相对基准_元": None, "相对基准_pct": None})
    out = pd.DataFrame(rows)
    base = float(out.loc[out["key"] == "E_baseline", "总成本"].iloc[0])
    out["相对基准_元"] = (out["总成本"] - base).round(2)
    out["相对基准_pct"] = ((out["总成本"] - base) / base * 100).round(2)

    path = os.path.join(OUT, "q3_decompose.csv")
    out.to_csv(path, index=False, encoding="utf-8-sig")

    print("=" * 66)
    print("问题3 的 2x2 误差分解（事后结算，153 天）")
    print("=" * 66)
    print(out[["组合", "说明", "总成本", "相对基准_pct"]].to_string(index=False))

    d = dict(zip(out["key"], out["相对基准_pct"]))
    print(f"\n用电量预测的贡献：{d['C_load_only']:+.2f}% （相对基准）")
    print(f"价差预测的破坏：  {d['D_both'] - d['C_load_only']:+.2f} 个百分点")
    print(f"完全信息的潜力：  {d['A_oracle']:+.2f}%")
    print(f"\n产出：{path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
