# -*- coding: utf-8 -*-
"""问题3：价格/价差预测与确定性日前申报（T3.2–T3.7）。

## 三个预测目标
    price_da  日前价格
    price_rt  实时价格
    spread    价差（= price_rt - price_da，赛题定义）

## 两法对比（赛题明确要求）
    直接法：把 spread 当作独立目标预测
    间接法：分别预测两个价格，再相减 spread_calc = pred_rt - pred_da
    最终采用：按 MAE 最小（口径 #5 事先声明）

## 关键性质（写进论文）
    单时段成本的导数 dC/dq = P_DA - P_RT + dR/dq **不含 P_DA 的绝对水平**。
    所以最优申报量只取决于**价差的方向与大小**，与日前价格的绝对水平无关。
    推论：日前价格预测的"水平偏差"不影响申报决策，只有"价差符号判断"才重要。

## 确定性申报
    把问题2 的用电量预测 L_hat 与问题3 的价差预测 S_hat 代入问题1 的闭式解：
        S_hat > 0 : q = max(Qc, (1+lambda0)L_hat)
        S_hat < 0 : q = max(0, min(Qc, (1-lambda0)L_hat))
        S_hat = 0 : q = Qc

## 经济效果评价
    用**实际** L / P_DA / P_RT 事后结算这笔申报，与两个基准比较：
        基准(1)  按合约量申报（q = Qc）
        基准(2)  完全信息最优（问题1 的解，理论下界）
    决策损失 = 本方案成本 - 完全信息最优成本

用法：<venv>/python.exe -m src.q3.solve
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common.env import use_project_tmp

use_project_tmp()

from src.common import io  # noqa: E402
from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed  # noqa: E402
from src.common.settle import LAM0, settle_day  # noqa: E402
from src.common.summary_io import update_summary  # noqa: E402
from src.q1.solve import q_star  # noqa: E402
from src.q3.features import FEAT_FULL, build_price_panel  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

EVAL_START, EVAL_END = "2026-04-01", "2026-08-31"
REFIT_DAYS = 7
PRICE_LAG = 7          # 价格披露 T+6 -> 训练目标须 <= W-7
SEED = 42

# 中位数回归（quantile 0.5）——直接优化 MAE，对价格尖峰稳健
# 实测：三个目标上均优于平方损失（价差 MAE 低 20.4%）
LOSS = dict(loss="quantile", quantile=0.5)

CLIP = {"price_da": (-150.0, 1600.0), "price_rt": (-150.0, 1600.0),
        "spread": (-600.0, 1100.0)}


def metrics(y, yhat):
    e = yhat - y
    ae = np.abs(e)
    m = np.abs(y) >= 1.0
    return {"MAE": float(ae.mean()), "RMSE": float(np.sqrt(np.mean(e ** 2))),
            "MAPE": float(np.mean(ae[m] / np.abs(y[m])) * 100) if m.any() else float("nan")}


def _gbdt(feats, y, seed=SEED):
    """中位数回归。实测在三个目标上均优于平方损失（价差 MAE 低 20%+）。"""
    from sklearn.ensemble import HistGradientBoostingRegressor
    m = HistGradientBoostingRegressor(
        max_iter=300, learning_rate=0.06, max_leaf_nodes=31,
        min_samples_leaf=20, l2_regularization=1.0, random_state=seed, **LOSS)
    m.fit(feats, y)
    return m


ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)
VAL_DAYS = 21          # 内部验证窗口（用于决定"信模型多少"）


def walk_forward(panel, target):
    """逐周重估 + **收缩估计**。

    为什么收缩：实测实时价与价差的 GBDT 反而不如"分时段中位数"这一朴素基准，
    说明当前信息集下信号极弱、复杂模型在拟合噪声。于是不再硬选模型，而是
        pred = α · GBDT + (1-α) · 分时段中位数
    α 由**训练集内部**最后 3 周的验证误差决定（不碰评估集，避免选择性偏差）：
    信号强时 α->1（信模型），信号弱时 α->0（退化成稳健基准）。
    """
    dates = sorted(panel["date"].unique())
    eval_dates = [d for d in dates if EVAL_START <= d <= EVAL_END]
    recs = []
    alphas = []
    # 已实现残差：存 (日期, 残差)，校正时按"披露可得"过滤
    past_pairs = []
    i = 0
    while i < len(eval_dates):
        week = eval_dates[i:i + REFIT_DAYS]
        W = week[0]
        pos = dates.index(W)
        train_end = dates[max(0, pos - PRICE_LAG)]
        tr = panel[panel["date"] <= train_end].dropna(subset=[target])

        # ---- 内部验证定 α ----
        alpha = 1.0
        if len(tr) > VAL_DAYS * 24 * 2:
            val_start = dates[max(0, pos - PRICE_LAG - VAL_DAYS)]
            tr_early = tr[tr["date"] < val_start]
            tr_val = tr[tr["date"] >= val_start]
            if len(tr_early) > 500 and len(tr_val) > 100:
                m_early = _gbdt(tr_early[FEAT_FULL], tr_early[target])
                prof_early = tr_early.groupby("hour")[target].median()
                pg = m_early.predict(tr_val[FEAT_FULL])
                pp = tr_val["hour"].map(prof_early).to_numpy(float)
                yv = tr_val[target].to_numpy(float)
                scores = {a: float(np.abs(a * pg + (1 - a) * pp - yv).mean()) for a in ALPHAS}
                alpha = min(scores, key=scores.get)

        # ---- 用全训练集重拟合，按 α 组合 ----
        model = _gbdt(tr[FEAT_FULL], tr[target])
        prof = tr.groupby("hour")[target].median()
        te = panel[panel["date"].isin(week)]
        pg = model.predict(te[FEAT_FULL])
        pp = te["hour"].map(prof).to_numpy(float)
        raw = alpha * pg + (1 - alpha) * pp

        # ---- 滚动偏差校正（严格无前视：只用实际值已披露的残差）----
        # 动机：价差预测存在系统性水平偏差（实测约 +21 元/MWh）。而由
        # dC/dq 不含绝对水平可知，偏差会整体移动"多报/少报"的判断倾向，
        # 校正它虽可能降低符号"准确率"，却显著改善期望成本。
        # 只有"实际值在决策时刻已披露"的残差才能进校正池：
        #   价格 T+6、负荷 T+4 → 对周首日 W 的决策（W-1 日），残差日须 ≤ W-7
        cutoff = dates[max(0, pos - PRICE_LAG)]
        usable = [r for d, r in past_pairs if d <= cutoff]
        bias = float(np.mean(usable)) if usable else 0.0
        pred = raw + bias
        lo, hi = CLIP[target]
        pred = np.clip(pred, lo, hi)

        f = te[["date", "hour"]].copy()
        f["yhat"] = pred
        recs.append(f)
        alphas.append(alpha)
        # 用**未加校正**的原始预测计算残差，供后续周使用
        for dv, rv in zip(te["date"].to_numpy(), te[target].to_numpy(float) - raw):
            if not np.isnan(rv):
                past_pairs.append((dv, float(rv)))
        i += REFIT_DAYS

    out = pd.concat(recs, ignore_index=True)
    out.attrs["alphas"] = alphas
    return out


def profile_only(panel, target):
    """对照：纯分时段中位数（不学习）。"""
    dates = sorted(panel["date"].unique())
    eval_dates = [d for d in dates if EVAL_START <= d <= EVAL_END]
    recs = []
    for W in eval_dates:
        pos = dates.index(W)
        tr = panel[panel["date"] <= dates[max(0, pos - PRICE_LAG)]].dropna(subset=[target])
        med = tr.groupby("hour")[target].median()
        te = panel[panel["date"] == W]
        f = te[["date", "hour"]].copy()
        f["yhat"] = te["hour"].map(med).to_numpy(float)
        recs.append(f)
    return pd.concat(recs, ignore_index=True)


def deterministic_bid(L_hat, S_hat, qc, lam0=LAM0):
    """把点预测代入问题1 的闭式解。"""
    up = (1 + lam0) * L_hat
    dn = (1 - lam0) * L_hat
    q = np.where(S_hat > 0, np.maximum(qc, up),
                 np.where(S_hat < 0, np.maximum(0.0, np.minimum(qc, dn)), qc))
    return q


def make_figures(panel, pred, metrics_df, eval_df):
    apply_style()

    # 图1：三价预测 vs 实际（选 5 天）
    seg = pred[(pred["date"] >= "2026-07-01") & (pred["date"] <= "2026-07-05")].sort_values(["date", "hour"])
    fig, axes = new_fig(1, 2, figsize=(10.4, 3.4))
    axes[0].plot(seg["price_da"], color=TOL[0], lw=1.0, label="日前价实际")
    axes[0].plot(seg["pred_da"], color=TOL[0], lw=1.0, ls="--", label="日前价预测")
    axes[0].set_xlabel("时段序号（07-01 起 5 天 x 24h）")
    axes[0].set_ylabel("价格（元/MWh）")
    axes[0].legend(fontsize=7)
    axes[1].plot(seg["price_rt"], color=TOL[1], lw=1.0, label="实时价实际")
    axes[1].plot(seg["pred_rt"], color=TOL[1], lw=1.0, ls="--", label="实时价预测")
    axes[1].set_xlabel("时段序号（07-01 起 5 天 x 24h）")
    axes[1].set_ylabel("价格（元/MWh）")
    axes[1].legend(fontsize=7)
    save_fig(fig, "q3_价格预测")

    # 图2：两法价差误差对比
    fig, axes = new_fig(1, 2, figsize=(9, 3.3))
    m = metrics_df[metrics_df["target"].isin(["spread_direct", "spread_calc"])]
    lab = ["直接预测价差", "两价相减"]
    axes[0].bar(lab, m["MAE"], color=[TOL[2], TOL[3]], width=0.5)
    axes[0].set_ylabel("MAE（元/MWh）")
    axes[1].bar(lab, m["RMSE"], color=[TOL[2], TOL[3]], width=0.5)
    axes[1].set_ylabel("RMSE（元/MWh）")
    for ax in axes:
        ax.set_xlabel("方法")
    save_fig(fig, "q3_两法对比")

    # 图3：价差符号判断 + 申报量
    fig, axes = new_fig(1, 2, figsize=(9.6, 3.4))
    corr = (np.sign(eval_df["S_hat"]) == np.sign(eval_df["spread"])).mean() * 100
    axes[0].hist(eval_df["spread"], bins=60, color=TOL[6], alpha=0.7, label="实际价差")
    axes[0].axvline(0, color="black", lw=0.8)
    axes[0].set_xlabel("价差（元/MWh）")
    axes[0].set_ylabel("频数")
    axes[0].legend(fontsize=7)

    axes[1].plot(eval_df["q_bid"].to_numpy()[:240], color=TOL[2], lw=1.0, label="确定性申报量")
    axes[1].plot(eval_df["qc"].to_numpy()[:240], color=TOL[6], lw=0.9, ls="--", label="合约量")
    axes[1].set_xlabel("时段序号（前 10 天）")
    axes[1].set_ylabel("电量（MWh）")
    axes[1].legend(fontsize=7)
    save_fig(fig, "q3_价差与申报")
    return corr


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(SEED)
    os.makedirs(OUT, exist_ok=True)

    print("=" * 66)
    print("问题3 · 价格/价差预测与确定性申报")
    print("=" * 66)

    panel = build_price_panel()
    print(f"价格面板：{panel.shape[0]} 行 x {panel.shape[1]} 列")

    # ---------- 三个目标的预测 ----------
    print("\n[1] 逐周重估预测（中位数回归）")
    preds = {}
    for tgt in ("price_da", "price_rt", "spread"):
        preds[tgt] = walk_forward(panel, tgt)
    obs = panel[(panel["date"] >= EVAL_START) & (panel["date"] <= EVAL_END)][
        ["date", "hour", "price_da", "price_rt", "spread"]]

    # ---- 与朴素基准（分时段中位数）对比 ----
    prof_ref = {t: profile_only(panel, t) for t in ("price_da", "price_rt", "spread")}
    print("\n[1b] 对照：分时段中位数（24 个数的朴素基准）")
    for t in ("price_da", "price_rt", "spread"):
        yv = obs[t].to_numpy(float)
        mp = metrics(yv, prof_ref[t]["yhat"].to_numpy(float))
        alpha = preds[t].attrs.get("alphas", [])
        n_full = sum(1 for a in alpha if a >= 0.99)
        print(f"  {t:<11} 基准 MAE={mp['MAE']:7.2f} | 本文 MAE={md0.get(t, float('nan')) if False else metrics(yv, preds[t]['yhat'].to_numpy(float))['MAE']:7.2f}"
              f" | α 中位 {np.median(alpha):.2f}，α=1 的周数 {n_full}/{len(alpha)}")

    ev = obs.copy()
    ev["pred_da"] = preds["price_da"]["yhat"].to_numpy()
    ev["pred_rt"] = preds["price_rt"]["yhat"].to_numpy()
    ev["pred_spread_direct"] = preds["spread"]["yhat"].to_numpy()
    ev["pred_spread_calc"] = ev["pred_rt"] - ev["pred_da"]

    rows = []
    for name, ycol, pcol in (("price_da", "price_da", "pred_da"),
                             ("price_rt", "price_rt", "pred_rt"),
                             ("spread_direct", "spread", "pred_spread_direct"),
                             ("spread_calc", "spread", "pred_spread_calc")):
        mm = metrics(ev[ycol].to_numpy(float), ev[pcol].to_numpy(float))
        rows.append({"target": name, **mm})
        print(f"  {name:<14} MAE={mm['MAE']:7.2f}  RMSE={mm['RMSE']:7.2f}  MAPE={mm['MAPE']:6.1f}%")
    metrics_df = pd.DataFrame(rows)

    # ---------- 两法对比：按 MAE 最小选 ----------
    md = metrics_df.set_index("target")
    best_method = "direct" if md.loc["spread_direct", "MAE"] <= md.loc["spread_calc", "MAE"] else "calc"
    drop = abs(md.loc["spread_direct", "MAE"] - md.loc["spread_calc", "MAE"]) / \
        max(md.loc["spread_direct", "MAE"], md.loc["spread_calc", "MAE"]) * 100
    print(f"\n[2] 价差两法：直接法 MAE={md.loc['spread_direct','MAE']:.2f}，"
          f"相减法 MAE={md.loc['spread_calc','MAE']:.2f} -> 采用 {best_method}（差 {drop:.1f}%）")
    ev["pred_spread_final"] = ev["pred_spread_direct"] if best_method == "direct" else ev["pred_spread_calc"]

    # ---------- 确定性申报 ----------
    print("\n[3] 确定性申报（Q2 用电量预测 + Q3 价差预测 + 附件5 合约）")
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q2 = q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
    if len(q2) != 3672:
        raise RuntimeError(f"q2_forecast.csv 行数异常：{len(q2)}")

    a5 = panel[["date", "hour"]].merge(
        io.load_attachments()["att5"], on=["date", "hour"], how="left")
    ev = ev.merge(q2, on=["date", "hour"], how="left")
    ev = ev.merge(a5[["date", "hour", "contract_q", "contract_p"]], on=["date", "hour"], how="left")
    ev = ev.rename(columns={"contract_q": "qc", "contract_p": "pc"})
    if ev["L_hat"].isna().any() or ev["qc"].isna().any():
        raise RuntimeError("用电量预测或合约数据存在缺失，检查 Q2 产出与附件5")

    ev["S_hat"] = ev["pred_spread_final"]
    ev["q_bid"] = deterministic_bid(ev["L_hat"].to_numpy(float),
                                    ev["S_hat"].to_numpy(float),
                                    ev["qc"].to_numpy(float))

    # ---------- 经济效果：事后结算三种方案 ----------
    print("\n[4] 经济效果（用实际 L / P_DA / P_RT 事后结算）")
    L = ev["load_actual"] = ev.merge(
        io.load_attachments()["att2"][["date", "hour", "load_actual"]],
        on=["date", "hour"], how="left")["load_actual"].to_numpy(float)
    pda = ev["price_da"].to_numpy(float)
    prt = ev["price_rt"].to_numpy(float)
    qc = ev["qc"].to_numpy(float)
    pc = ev["pc"].to_numpy(float)

    q_oracle = q_star(L, pda, prt, qc)            # 完全信息最优（理论下界）
    plans = {
        "确定性申报（本文）": ev["q_bid"].to_numpy(float),
        "按合约量申报（基准(1)）": qc,
        "完全信息最优（基准(2)）": q_oracle,
    }
    econ = {}
    for name, q in plans.items():
        tot = 0.0
        for d, idx in ev.groupby("date").indices.items():
            tot += settle_day(q[idx], L[idx], pda[idx], prt[idx], qc[idx], pc[idx])["sums"]["total"]
        econ[name] = tot
        print(f"  {name:<22} {tot:,.2f} 元")

    det = econ["确定性申报（本文）"]
    base = econ["按合约量申报（基准(1)）"]
    orc = econ["完全信息最优（基准(2)）"]
    print(f"\n  相对基准(1) 节省 {base - det:,.2f} 元（{(base - det) / base * 100:.2f}%）")
    print(f"  相对基准(2) 决策损失 {det - orc:,.2f} 元（占基准(1) 的 {(det - orc) / base * 100:.2f}%）")

    # ---------- 输出 ----------
    out = ev[["date", "hour"]].copy()
    # 先定两位价格的舍入值，再让"相减法价差"严格等于舍入后两价之差，
    # 否则文件里 spread_calc != pred_rt - pred_da（读者一核对就发现对不上）
    out["pred_da"] = ev["pred_da"].round(4).to_numpy()
    out["pred_rt"] = ev["pred_rt"].round(4).to_numpy()
    out["pred_spread_direct"] = ev["pred_spread_direct"].round(4).to_numpy()
    out["pred_spread_calc"] = (out["pred_rt"] - out["pred_da"]).round(4)
    out["pred_spread_final"] = (out["pred_spread_direct"] if best_method == "direct"
                                else out["pred_spread_calc"])
    out["q_bid"] = deterministic_bid(
        ev["L_hat"].to_numpy(float),
        out["pred_spread_final"].to_numpy(float),
        ev["qc"].to_numpy(float)).round(6)
    out["note"] = (f"价格用中位数回归逐周重估；价差采用{'直接法' if best_method == 'direct' else '相减法'}"
                   f"（MAE 最小）；申报按 Q1 闭式解代入预测")
    out = out.sort_values(["date", "hour"]).reset_index(drop=True)
    out.to_csv(os.path.join(OUT, "q3_price_bid.csv"), index=False, encoding="utf-8-sig")

    metrics_df.to_csv(os.path.join(OUT, "q3_metrics.csv"), index=False, encoding="utf-8-sig")
    pd.DataFrame([{"方案": k, "总成本": round(v, 2),
                   "相对基准1_节省": round(base - v, 2),
                   "相对基准2_决策损失": round(v - orc, 2)} for k, v in econ.items()]
                 ).to_csv(os.path.join(OUT, "q3_econ.csv"), index=False, encoding="utf-8-sig")

    # ---------- 图 ----------
    pred = ev.copy()
    corr = make_figures(panel, pred, metrics_df, ev)
    print(f"\n[5] 价差符号判断准确率：{corr:.1f}%")

    # ---------- 汇总指标 ----------
    items = []
    for key, name in (("da", "price_da"), ("rt", "price_rt"),
                      ("spread_direct", "spread_direct"), ("spread_calc", "spread_calc")):
        r = md.loc[name]
        items.append({"_key": key, "mae": round(r["MAE"], 4), "rmse": round(r["RMSE"], 4),
                      "other_name": "MAPE", "other_value": round(r["MAPE"], 4),
                      "note": {"da": "日前价格", "rt": "实时价格",
                               "spread_direct": "直接预测价差", "spread_calc": "两价相减"}[key]})
    update_summary(None, "q3_price_metrics", items)
    update_summary(None, "q3_econ", [{
        "_key": "det", "avg_daily_cost": round(det / 153, 2),
        "max_daily_cost": round(max(
            sum(settle_day(ev["q_bid"].to_numpy(float)[i],
                           L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                for i in idx)
            for idx in ev.groupby("date").indices.values()), 2),
        "avg_decision_loss": round((det - orc) / 153, 2),
        "other_name": "相对基准节省", "other_value": round(base - det, 2),
        "note": "确定性申报，事后结算"}])

    print(f"\n产出：q3_price_bid.csv（{len(out)} 行）、q3_metrics.csv、q3_econ.csv、3 张图")
    return 0


if __name__ == "__main__":
    sys.exit(main())
