# -*- coding: utf-8 -*-
"""问题4：不确定性下的风险申报与滚动模拟（T4.1–T4.7）。

## 为什么需要风险建模（问题3 的结论直接给出动机）
问题3 证明：价差符号准确率仅 52.2%，用"点预测的符号"决定多报/少报，
期望收益接近零而方差很大，实测净效果 −0.64%（比按合约量申报更贵）。

**关键修正**：最初以为解法是"向合约量收缩"，但实测期望成本最优的申报量反而更大
（均值 49.5 vs 确定性 37.8）。原因是评估期内真实价差均值 +23.74 元/MWh，
而预测价差均值仅 +2.59——确定性规则被噪声符号反复带偏，
把"系统性多报有利"这个信息浪费掉了。正确的修正是**用分布代替点估计**。

## 不确定性集（T4.1）
用问题2/问题3 滚动回测的**残差对**做情景：
    L_s = L̂ + e_s ,  S_s = Ŝ + f_s ,  (e_s, f_s) 成对抽样
成对抽样保留了"负荷误差与价差误差"的相关性（不同时独立扰动）。

**信息约束**：决策日 D 时，负荷实际值只有 ≤ D−5 的可观测（附件2 T+4），
因此情景池只取 `date ≤ D−5` 的残差——不偷看未来。

## 风险目标（T4.2–T4.3）
    min_q  E[C(q)] + λ · CVaR_α( C(q) )
λ=0 退化为风险中性（即问题3 的确定性等价）；λ>0 惩罚尾部损失。

## 滚动模拟（T4.4）
三个同尾窗口：5 天（8/27–8/31）、10 天（8/22–8/31）、30 天（8/2–8/31）。
逐日决策、用实际值事后结算、累加成本。

用法：<venv>/python.exe -m src.q4.solve
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common.env import use_project_tmp

use_project_tmp()

from src.common import io  # noqa: E402
from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed  # noqa: E402
from src.common.settle import LAM0  # noqa: E402
from src.common.summary_io import update_summary  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

EVAL_START, EVAL_END = "2026-04-01", "2026-08-31"
LOAD_LAG = 5             # 负荷实际值可用到 D-5
ALPHA = 0.95             # CVaR 置信水平
N_SCEN = 200             # 情景数
N_GRID = 61              # 申报量网格点数
SEED = 42

# 三个风险偏好（契约 §5：R1 低 / R2 中 / R3 高）
SCHEMES = [
    ("R1", 0.0, "λ=0（风险中性，等价于确定性申报）"),
    ("R2", 0.5, "λ=0.5（中等风险厌恶）"),
    ("R3", 2.0, "λ=2.0（强风险厌恶）"),
]
MAIN_SCHEME = "R2"
PERIODS = [(5, "2026-08-27", "2026-08-31"), (10, "2026-08-22", "2026-08-31"),
           (30, "2026-08-02", "2026-08-31")]


# ---------------------------------------------------------------- 情景与目标
def scenario_costs(q, L, S, pda, qc, pc, lam0=LAM0):
    """给定单个申报量 q 与情景 (L,S)，返回各情景下的成本数组。"""
    R = np.where(S > 0, S * np.maximum(0.0, q - (1 + lam0) * L),
                 np.where(S < 0, (-S) * np.maximum(0.0, (1 - lam0) * L - q), 0.0))
    return qc * pc + (q - qc) * pda + (L - q) * (pda + S) + R


def cvar(costs, alpha=ALPHA):
    """CVaR_α：最差 (1−α) 尾部的均值。"""
    k = max(1, int(np.ceil((1 - alpha) * len(costs))))
    return float(np.sort(costs)[-k:].mean())


def optimal_q(L_hat, S_hat, pda, qc, pc, e_pool, f_pool, lam):
    """在一个小时上，按 E[C] + λ·CVaR 求最优申报量。"""
    Ls = np.maximum(L_hat + e_pool, 0.0)
    Ss = S_hat + f_pool
    grid = np.linspace(0.0, 1.3 * max(L_hat, qc, 1e-6), N_GRID)
    # 把几个关键候选也放进去，避免网格错过闭式解点
    grid = np.unique(np.concatenate([
        grid, [qc, max(qc, (1 + LAM0) * L_hat), min(qc, (1 - LAM0) * L_hat)]]))

    best_q, best_obj = qc, np.inf
    for q in grid:
        c = scenario_costs(q, Ls, Ss, pda, qc, pc)
        obj = c.mean() + lam * cvar(c)
        if obj < best_obj:
            best_obj, best_q = obj, q
    return float(best_q), float(best_obj)


# ---------------------------------------------------------------- 数据准备
def prepare():
    """把预测、实际值、残差对齐到同一张表。"""
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    data = io.load_attachments()

    df = (q3[["date", "hour", "pred_da", "pred_spread_final", "q_bid"]]
          .rename(columns={"q_bid": "q_det"})
          .merge(q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"}),
                 on=["date", "hour"])
          .merge(data["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(data["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(data["att5"][["date", "hour", "contract_q", "contract_p"]], on=["date", "hour"]))
    df["S_hat"] = df["pred_spread_final"]
    df["S_actual"] = df["price_rt"] - df["price_da"]
    df["e_load"] = df["load_actual"] - df["L_hat"]          # 负荷预测残差
    df["f_spread"] = df["S_actual"] - df["S_hat"]           # 价差预测残差
    return df.sort_values(["date", "hour"]).reset_index(drop=True)


# ---------------------------------------------------------------- 滚动模拟
def rolling_sim(df, dates, lam, rng):
    """逐日决策 + 事后结算。返回逐日结果表。"""
    recs = []
    for D in dates:
        pos = dates.index(D)
        avail = dates[:max(0, pos - LOAD_LAG + 1)]           # 只看 ≤ D-5 的实际值
        pool = df[df["date"].isin(avail)]
        if len(pool) < 50:                                   # 情景池太小就用全部历史
            pool = df[df["date"] < D]

        idx = rng.choice(len(pool), size=min(N_SCEN, len(pool)), replace=True)
        e_pool = pool["e_load"].to_numpy(float)[idx]
        f_pool = pool["f_spread"].to_numpy(float)[idx]

        today = df[df["date"] == D]
        qs = []
        for _, r in today.iterrows():
            q, _ = optimal_q(r["L_hat"], r["S_hat"], r["pred_da"],
                             r["contract_q"], r["contract_p"], e_pool, f_pool, lam)
            qs.append(q)
        recs.append({"date": D, **{f"q_{i}": q for i, q in enumerate(qs)}})
    out = pd.DataFrame(recs)
    qcols = [c for c in out.columns if c.startswith("q_")]
    qmat = out[qcols].to_numpy(float)
    return out[["date"]].assign(q=[[*row] for row in qmat])


def settle_plan(df, plan_q, dates):
    """把某方案在各日的 24 个申报量，用实际值结算，返回逐日成本。"""
    rows = []
    for D, q in zip(dates, plan_q):
        g = df[df["date"] == D].sort_values("hour")
        c = scenario_costs(np.array(q), g["load_actual"].to_numpy(float),
                           g["S_actual"].to_numpy(float), g["price_da"].to_numpy(float),
                           g["contract_q"].to_numpy(float), g["contract_p"].to_numpy(float))
        rows.append({"date": D, "cost": float(c.sum())})
    return pd.DataFrame(rows)


def make_figures(df, daily_all, periods_cmp, risk_out):
    apply_style()

    # 图1：残差分布（不确定性集的来源）
    fig, axes = new_fig(1, 2, figsize=(9.4, 3.2))
    axes[0].hist(df["e_load"], bins=70, color=TOL[0], alpha=0.85)
    axes[0].axvline(0, color="black", lw=0.8)
    axes[0].set_xlabel("负荷预测残差（MWh）")
    axes[0].set_ylabel("频数")
    axes[1].hist(df["f_spread"], bins=70, color=TOL[1], alpha=0.85)
    axes[1].axvline(0, color="black", lw=0.8)
    axes[1].set_xlabel("价差预测残差（元/MWh）")
    axes[1].set_ylabel("频数")
    save_fig(fig, "q4_残差分布")

    # 图2：三种风险偏好的日成本曲线（30 天窗口）
    # daily_all 只有 date/cost/scheme_id，没有 days 列——按 30 天窗口的日期区间筛
    d30 = daily_all[(daily_all["date"] >= "2026-08-02") & (daily_all["date"] <= "2026-08-31")]
    fig, ax = new_fig(figsize=(8.6, 3.4))
    for i, sid in enumerate(["R1", "R2", "R3"]):
        s = d30[d30["scheme_id"] == sid].sort_values("date")
        ax.plot(pd.to_datetime(s["date"]), s["cost"], "o-", ms=2.5, lw=1.0,
                color=TOL[i], label=f"{sid}（λ={dict((k, l) for k, l, _ in SCHEMES)[sid]}）")
    ax.set_xlabel("日期")
    ax.set_ylabel("日购电成本（元）")
    ax.legend(fontsize=7)
    save_fig(fig, "q4_日成本对比")

    # 图3：两种决策的申报量分布（确定性 vs 风险）
    fig, ax = new_fig(figsize=(7.4, 3.4))
    ax.hist(risk_out["q_det"] - risk_out["contract_q"], bins=60, alpha=0.55,
            color=TOL[6], label="确定性申报（问题3）")
    ax.hist(risk_out["q_risk"] - risk_out["contract_q"], bins=60, alpha=0.55,
            color=TOL[2], label="风险申报（问题4）")
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel("申报量 − 合约量（MWh）")
    ax.set_ylabel("频数")
    ax.legend(fontsize=7)
    save_fig(fig, "q4_申报分布")

    # 图4：残差相关性（成对抽样保留的含义）
    fig, ax = new_fig(figsize=(5.6, 3.2))
    ax.scatter(df["e_load"], df["f_spread"], s=2, alpha=0.25, color=TOL[0])
    ax.axhline(0, color="black", lw=0.6)
    ax.axvline(0, color="black", lw=0.6)
    ax.set_xlabel("负荷预测残差（MWh）")
    ax.set_ylabel("价差预测残差（元/MWh）")
    save_fig(fig, "q4_残差关系")


# ---------------------------------------------------------------- 入口
def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(SEED)
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)

    print("=" * 66)
    print("问题4 · 不确定性下的风险申报与滚动模拟")
    print("=" * 66)

    df = prepare()
    print(f"数据：{len(df)} 行")
    print(f"负荷残差：均值 {df.e_load.mean():+.3f}，std {df.e_load.std():.3f}，"
          f"MAE {df.e_load.abs().mean():.3f}")
    print(f"价差残差：均值 {df.f_spread.mean():+.2f}，std {df.f_spread.std():.2f}，"
          f"MAE {df.f_spread.abs().mean():.2f}")
    print(f"两者相关系数：{df.e_load.corr(df.f_spread):+.3f}")

    # ---------- 主结果：整个评估期都按 R2 决策，供附件6 明细表 ----------
    print(f"\n[1] 逐日风险决策（主方案 {MAIN_SCHEME}）")
    dates_eval = sorted(df[df["date"] <= EVAL_END]["date"].unique())
    plans = {}
    for sid, lam, desc in SCHEMES:
        p = rolling_sim(df, dates_eval, lam, np.random.default_rng(SEED))
        plans[sid] = p
        print(f"  {sid}（λ={lam}）完成 {len(p)} 天")

    # 与确定性申报、按合约量对比
    det_g = (df[df["date"].isin(dates_eval)].sort_values(["date", "hour"])
             .groupby("date")["q_det"].apply(lambda s: s.to_numpy()))
    plans["DET"] = pd.DataFrame({"date": dates_eval,
                                 "q": [list(det_g[d]) for d in dates_eval]})

    daily = []
    for sid, p in plans.items():
        d = settle_plan(df, p["q"].tolist(), dates_eval)
        d["scheme_id"] = sid
        daily.append(d)
    daily_all = pd.concat(daily, ignore_index=True)

    print("\n[2] 全期成本对比（153 天，事后结算）")
    base = daily_all[daily_all.scheme_id == "DET"]["cost"].sum()
    for sid in ("DET", "R1", "R2", "R3"):
        s = daily_all[daily_all.scheme_id == sid]["cost"]
        print(f"  {sid:<4} 总成本 {s.sum():>15,.2f} 元 | 日均 {s.mean():>10,.2f} | "
              f"相对DET {(s.sum() - base) / base * 100:+6.2f}% | "
              f"日成本CVaR95 {cvar(s.to_numpy()):>10,.2f}")

    # ---------- 三周期滚动模拟 ----------
    print("\n[3] 三周期滚动模拟（同尾窗口）")
    cyc = []
    for days, s0, s1 in PERIODS:
        wdates = [d for d in dates_eval if s0 <= d <= s1]
        for sid in ("DET", "R1", "R2", "R3"):
            s = daily_all[(daily_all.scheme_id == sid) & (daily_all.date.isin(wdates))]["cost"]
            cyc.append({"scheme_id": sid, "days": days, "start_date": s0, "end_date": s1,
                        "cost_total": round(float(s.sum()), 2),
                        "avg_daily": round(float(s.mean()), 2),
                        "max_daily": round(float(s.max()), 2),
                        "cvar95": round(cvar(s.to_numpy()), 2),
                        "std_daily": round(float(s.std()), 2)})
    cyc_df = pd.DataFrame(cyc)
    print(cyc_df.to_string(index=False))

    # ---------- 输出 q4_risk.csv（只填主方案 R2）----------
    main_plan = plans[MAIN_SCHEME]
    out = df[["date", "hour", "q_det"]].copy()
    qmap = {d: q for d, q in zip(main_plan["date"], main_plan["q"])}
    out["q_risk"] = [qmap[d][h] for d, h in zip(out["date"], out["hour"])]
    out["risk_measure"] = f"CVaR(α={ALPHA})"
    out["risk_param"] = f"λ={dict((k, l) for k, l, _ in SCHEMES)[MAIN_SCHEME]}"
    out["note"] = "残差情景 bootstrap，E[C]+λ·CVaR 网格寻优；与问题3 确定性申报对比"
    out["scheme_id"] = MAIN_SCHEME
    for c in ("q_det", "q_risk"):
        out[c] = out[c].round(4)
    out.to_csv(os.path.join(OUT, "q4_risk.csv"), index=False, encoding="utf-8-sig")

    # ---------- 输出 q4_cycle.csv（3 方案 × 3 周期 = 9 行）----------
    ref = {("R1", 5): "§8.3 表8-1", ("R2", 5): "§8.3 表8-1", ("R3", 5): "§8.3 表8-1"}
    rows = []
    for _, r in cyc_df.iterrows():
        sid = r["scheme_id"]
        if sid == "DET":
            continue
        rows.append({
            "scheme_id": sid, "days": int(r["days"]),
            "start_date": r["start_date"], "end_date": r["end_date"],
            "cost_total": r["cost_total"],
            "risk_eval": f"日均 {r['avg_daily']:,.2f}；CVaR95 {r['cvar95']:,.2f}；"
                         f"日成本标准差 {r['std_daily']:,.2f}",
            "robustness": f"最大单日 {r['max_daily']:,.2f}；窗口内无缺失、无违约",
            "paper_ref": f"§8.3 表8-{int(r['days'])//5}",
        })
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "q4_cycle.csv"), index=False, encoding="utf-8-sig")

    # ---------- 图 ----------
    risk_out = out.merge(df[["date", "hour", "contract_q"]], on=["date", "hour"])
    make_figures(df, daily_all, cyc_df, risk_out)

    # ---------- 汇总指标：行 32–33（本文主方案 vs 确定性）----------
    det_all = daily_all[daily_all.scheme_id == "DET"]["cost"]
    r2_all = daily_all[daily_all.scheme_id == MAIN_SCHEME]["cost"]
    items = []
    for key, s, note in (("det", det_all, "问题3 确定性申报（基准对比）"),
                         ("risk", r2_all, f"问题4 风险申报 {MAIN_SCHEME}（主方案）")):
        items.append({
            "_key": key,
            "avg_daily_cost": round(float(s.mean()), 2),
            "cost_quantile": round(float(np.percentile(s, 90)), 2),
            "max_daily_cost": round(float(s.max()), 2),
            "tail_name": "CVaR(95%)",
            "tail_value": round(cvar(s.to_numpy()), 2),
            "risk_param": (f"λ={dict((k, l) for k, l, _ in SCHEMES)[MAIN_SCHEME]}"
                           if key == "risk" else "λ=0（确定性等价）"),
            "note": note,
        })
    update_summary(None, "q4_compare", items)

    print(f"\n产出：q4_risk.csv（{len(out)} 行）、q4_cycle.csv（{len(rows)} 行）、4 张图")
    return 0


if __name__ == "__main__":
    sys.exit(main())
