"""数字溯源检查：把正文里所有 >=4 位数字抽出来，看能否在产物中找到来源。"""
import pymupdf, re, glob, os
import pandas as pd

# 1) 建立数字语料库：所有产物 CSV 里的数值（含千分位与小数形式）
corpus=set()
for f in glob.glob('outputs/*.csv'):
    try: df=pd.read_csv(f,encoding='utf-8-sig')
    except Exception: continue
    for c in df.columns:
        for v in df[c].dropna():
            if isinstance(v,(int,float)):
                for fmt in (f'{v:,.2f}', f'{v:,.0f}', f'{v:.3f}', f'{v:.2f}', f'{v:.4f}'):
                    corpus.add(fmt)
            else:
                for m in re.findall(r'\d[\d,]*\.?\d*', str(v)): corpus.add(m)

d=pymupdf.open('paper/论文.pdf')
apx=[k+1 for k in range(d.page_count) if '附录A' in d[k].get_text()][0]
body='\n'.join(d[i].get_text() for i in range(apx-1))

# 2) 抽出正文中的数字
nums=set(re.findall(r'\d[\d,]{2,}(?:\.\d+)?', body))
unknown=[]
for n in sorted(nums):
    if n in corpus: continue
    core=n.replace(',','')
    if any(core in c.replace(',','') for c in corpus): continue
    unknown.append(n)

print(f'  正文中 >=4 位数字: {len(nums)} 个')
print(f'  可在产物中直接找到: {len(nums)-len(unknown)}')
print(f'  未直接找到: {len(unknown)}（多为派生值/百分比/年份，需人工确认）')
print()
for n in unknown:
    print('   ', n)
