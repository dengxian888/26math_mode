import pandas as pd, re, os

def load(f):
    return pd.read_csv(os.path.join('outputs',f), encoding='utf-8-sig')

def table_block(label):
    s=open('paper/论文.tex',encoding='utf-8').read()
    i=s.index('\\label{%s}'%label)
    j=s.index('\\end{tabular}', i)
    k=s.rindex('\\begin{tabular}', 0, i)
    return s[k:j].replace('{,}',',')

def check(label, df, cols, name, tol_digits=0):
    blk=table_block(label)
    ok=0; bad=[]
    for c in cols:
        if c not in df.columns: continue
        for v in df[c].dropna():
            try: fv=float(v)
            except Exception: continue
            cand=[f'{fv:,.0f}', f'{fv:,.2f}', f'{fv:.2f}', f'{fv:.3f}', f'{fv:.4f}']
            if any(c2 in blk for c2 in cand): ok+=1
            else: bad.append((c, cand[0]))
    print(f'  {name}: 命中 {ok}/{ok+len(bad)}')
    for c,v in bad[:4]: print(f'     !! {c}={v} 未在表中')

print('='*70); print('逐表对账：表中每个数字都必须能在对应 CSV 里找到'); print('='*70)

check('tab:q4risk', load('q4_risk_metrics.csv'), ['日均','标准差','VaR95','CVaR95','最大单日'], '表18 风险指标')
check('tab:q4bench', load('q4_benchmark.csv'), ['总成本'], '表17 全期对照')
check('tab:q4switch', load('q4_switch.csv'), ['总成本'], '表19 切换规则')
check('tab:q4month', load('q4_monthly.csv'), ['R2减零模型_元'], '表20 逐月')
check('tab:q4sens', load('q4_sensitivity.csv'), ['总成本'], '表22 敏感性')
check('tab:shrink_q', load('q3_shrinkage.csv'), ['相对基准_pct'], '表16 收缩')
check('tab:q4opt', load('q4_optimizer_check.csv') if os.path.exists('outputs/q4_optimizer_check.csv') else pd.DataFrame(), [], '表24 优化器验证')
