# -*- coding: utf-8 -*-
"""T0.4 绘图封装测试。

两层验证：
  1. 本进程内出图：样式可套用、图能存下来、尺寸合理
  2. 子进程捕获 stderr：确认没有 "does not have a glyph"（中文变豆腐块的唯一可靠判据）
     —— matplotlib 的缺字形提示走 C++ 层 stderr，Python 的 warnings 抓不到

用法：<venv>/python.exe tests/test_plotting.py
"""
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np  # noqa: E402

FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def main():
    print("=" * 66)
    print("T0.4 绘图封装测试")
    print("=" * 66)

    from src.common.plotting import (CJK_FONT, FIG_DIR, SEQ, TOL,  # noqa: E402
                                     apply_style, new_fig, save_fig, set_seed)

    print(f"\n中文字体: {CJK_FONT}")

    # ---------- 1. 本进程出图 ----------
    print("\n[1] 本进程出图")
    apply_style()
    set_seed(42)

    fig, axes = new_fig(1, 3)
    ax = axes[0]
    t = np.arange(0, 101)
    for i, (a, lab) in enumerate([(0.95, r"$\alpha=0.95$"), (0.60, r"$\alpha=0.60$")]):
        ax.plot(t, -np.exp(-a * t / 10), color=TOL[i], label=lab)
    ax.set_xlabel("迭代次数")
    ax.set_ylabel("目标函数值")
    ax.legend(loc="lower right")

    ax = axes[1]
    ax.bar(["方案甲", "方案乙", "方案丙"], [0.82, 0.91, 0.74],
           color=[TOL[0], TOL[1], TOL[2]], width=0.6)
    ax.set_ylabel("综合得分")

    ax = axes[2]
    rng = np.random.default_rng(42)
    im = ax.imshow(rng.random((8, 8)), cmap=SEQ, aspect="auto")
    ax.set_xlabel("决策变量")
    ax.set_ylabel("约束条件")
    ax.grid(False)
    fig.colorbar(im, ax=ax, label="灵敏度")

    path = save_fig(fig, "_t0_plotting_selfcheck.png")
    check("图片已生成", os.path.exists(path), path)
    check("图片大小合理", os.path.getsize(path) > 5000,
          f"{os.path.getsize(path) / 1024:.0f} KB")
    check("保存目录为 outputs/figures", os.path.dirname(path) == FIG_DIR)

    import matplotlib
    fam = matplotlib.rcParams["font.family"]
    check("font.family 是列表且含中文字体", isinstance(fam, list) and CJK_FONT in fam, f"{fam}")
    check("负号显示已开启", matplotlib.rcParams["axes.unicode_minus"] is False)
    check("DPI = 300", matplotlib.rcParams["savefig.dpi"] == 300)

    # ---------- 2. 子进程 stderr 校验 ----------
    print("\n[2] 子进程渲染，检查是否缺字形")
    code = r'''
import sys, os
sys.path.insert(0, os.getcwd())
import numpy as np
from src.common.plotting import apply_style, new_fig, save_fig
apply_style()
fig, ax = new_fig()
ax.plot([0, 1], [0, -1])
ax.set_xlabel("迭代次数")
ax.set_ylabel("目标函数值")
ax.set_title("")           # 图内不放标题，这里只是占位
save_fig(fig, "_t0_plotting_stderr_probe.png")
'''
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    r = subprocess.run([sys.executable, "-c", code], cwd=os.getcwd(),
                       capture_output=True, text=True, encoding="utf-8", env=env)
    combined = (r.stdout or "") + (r.stderr or "")
    n_glyph = combined.count("does not have a glyph")
    check("无缺字形提示", n_glyph == 0, f"发现 {n_glyph} 次" if n_glyph else "")
    check("子进程退出码为 0", r.returncode == 0, f"exit={r.returncode}")
    if n_glyph:
        for line in combined.split("\n"):
            if "glyph" in line:
                print("      ", line.strip()[:110])

    # 清理探针图
    for f in ("_t0_plotting_selfcheck.png", "_t0_plotting_stderr_probe.png"):
        p = os.path.join(FIG_DIR, f)
        if os.path.exists(p):
            os.remove(p)

    print("\n" + "=" * 66)
    if FAILS:
        print(f"[X] 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("[OK] T0.4 绘图封装测试全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
