# -*- coding: utf-8 -*-
"""T0.7 复核：组员产物的可信度抽验。

复核两件事：
  1. `src/common/io.py`（纯标准库解析 xlsx）的结果与 openpyxl 是否一致——抽验全部单元格
  2. `data/interim/` 6 张长表的完整性：行数、日期覆盖、时段覆盖、重复键、缺失值

用法：
    <venv>/python.exe tests/test_t0_review.py
退出码 0 = 全部通过；非 0 = 有失败项。
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402

from src.common import io  # noqa: E402

FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def compare_workbook(path, skip_title_rows=0, tol=1e-9):
    """把 io.read_xlsx 与 openpyxl 逐单元格比对（只比数值与文本）。"""
    mine = io.read_xlsx(path)
    wb = load_workbook(path, data_only=True)
    total = 0
    diff = 0
    worst = 0.0
    for sheet_name, df in mine.items():
        if sheet_name not in wb.sheetnames:
            FAILS.append(f"{os.path.basename(path)}/{sheet_name} openpyxl 里不存在")
            continue
        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))[skip_title_rows:]
        if not rows:
            continue
        header = rows[0]
        body = rows[1:]
        # 逐格比对（行列顺序应与 io 一致）
        for r, row in enumerate(body):
            if r >= len(df):
                break
            for c, val in enumerate(row):
                if c >= df.shape[1]:
                    break
                cell = df.iat[r, c]
                if val is None and (cell is None or pd.isna(cell)):
                    continue
                if val is None or cell is None or (isinstance(cell, float) and pd.isna(cell)):
                    if val is not None or cell is not None:
                        diff += 1
                    continue
                total += 1
                if isinstance(val, (int, float)) and isinstance(cell, (int, float)):
                    d = abs(float(val) - float(cell))
                    worst = max(worst, d)
                    if d > tol:
                        diff += 1
                else:
                    if str(val).strip() != str(cell).strip():
                        diff += 1
    return total, diff, worst


def main():
    print("=" * 66)
    print("T0.7 复核 · 组员产物")
    print("=" * 66)

    # ---------- 1. io.py 与 openpyxl 一致性 ----------
    print("\n[1] io.py 解析结果 vs openpyxl（全文逐格）")
    # 附件1~5 表头在第 1 行；附件6 有标题行+空行，表头在第 3 行
    skip = {}
    for name, fn in io.ATTACHMENTS.items():
        if name == "att6":
            continue  # 附件6 是结果模板，版面不规则，见 [1c]
        path = os.path.join(io.RAW_DIR, fn)
        if not os.path.exists(path):
            check(f"{name} 存在", False, path)
            continue
        total, diff, worst = compare_workbook(path, skip_title_rows=skip.get(name, 0))
        check(f"{name} 一致性", diff == 0, f"比对 {total} 个数值格，差异 {diff}，最大绝对误差 {worst:.2e}")

    # 附件6 是结果模板：多表头位置 + 多区块混排，DataFrame 模型不适用
    print("\n[1c] 附件6 版面校验（对照 docs/附件6契约.md）")
    wb6 = load_workbook(os.path.join(io.RAW_DIR, io.ATTACHMENTS["att6"]), data_only=True)
    expect_sheets = ["填写说明", "问题1_典型日申报", "问题2_用电量预测",
                     "问题3_价格预测与申报", "问题4_风险申报", "问题4_周期结果", "汇总指标"]
    check("sheet 名称与顺序", wb6.sheetnames == expect_sheets, f"实际 {wb6.sheetnames}")

    # 明细 sheet：数据从第 4 行起，A/B 列已预填
    detail = {"问题1_典型日申报": 120, "问题2_用电量预测": 3672,
              "问题3_价格预测与申报": 3672, "问题4_风险申报": 3672}
    for sh, n in detail.items():
        ws = wb6[sh]
        dates = [ws.cell(r, 1).value for r in range(4, 4 + n)]
        hours = [ws.cell(r, 2).value for r in range(4, 4 + n)]
        ok_d = all(d not in (None, "") for d in dates)
        ok_h = all(isinstance(h, str) and h.endswith(":00") for h in hours)
        # 末行之后不应再有数据
        extra = ws.cell(4 + n, 1).value
        check(f"{sh} 预填 {n} 行", ok_d and ok_h and extra in (None, ""),
              f"日期{'齐' if ok_d else '缺'} 时段{'合规' if ok_h else '异常'} 越界行{'无' if extra in (None,'') else '有'}")

    # 周期结果：应完全空白
    ws4 = wb6["问题4_周期结果"]
    # max_row 可能是空行带格式造成的，只检查第 4 行起是否真的没有内容
    filled = [(r, c) for r in range(4, ws4.max_row + 1) for c in range(1, 9)
              if ws4.cell(r, c).value not in (None, "")]
    check("问题4_周期结果 无预填数据", not filled,
          f"max_row={ws4.max_row}（含空行格式），实际有内容单元格 {len(filled)} 个")

    # 汇总指标的固定标签行
    expect_labels = {
        13: "方案A", 14: "方案B", 15: "方案C", 16: "最终采用模型",
        20: "日前价格", 21: "实时价格", 22: "直接预测价差", 23: "由两价预测计算价差",
        27: "确定性申报策略", 32: "问题3确定性策略", 33: "风险决策策略",
    }
    wsm = wb6["汇总指标"]
    bad = []
    for r, key in expect_labels.items():
        v = wsm.cell(r, 1).value
        if v is None or key not in str(v):
            bad.append((r, key, v))
    check("汇总指标 标签行位置", not bad, f"不符 {bad}" if bad else "12 个标签全部对位")

    # 顺带验证 workbook sheet 顺序与 xml 文件名顺序一致（io.py 的隐含假设）
    print("\n[2] io.py 的隐含假设：sheet 顺序 == sheetN.xml 文件名顺序")
    import re
    import zipfile
    for name, fn in io.ATTACHMENTS.items():
        path = os.path.join(io.RAW_DIR, fn)
        with zipfile.ZipFile(path) as z:
            names = sorted(
                int(re.match(r"xl/worksheets/sheet(\d+)\.xml$", n).group(1))
                for n in z.namelist()
                if re.match(r"xl/worksheets/sheet(\d+)\.xml$", n)
            )
        wb = load_workbook(path, data_only=True)
        check(f"{name} sheet 数一致", len(names) == len(wb.sheetnames),
              f"xml {len(names)} 个 / workbook {len(wb.sheetnames)} 个")

    # ---------- 3. 长表完整性 ----------
    print("\n[3] data/interim 长表完整性")
    spec = {
        "att1_典型日.csv": (120, 5, None),
        "att2_用电量.csv": (5832, 243, 4),
        "att3_预测信息.csv": (5832, 243, -1),
        "att3_实际信息.csv": (5832, 243, 2),
        "att4_价格.csv": (5832, 243, 6),
        "att5_合约.csv": (5832, 243, None),
    }
    for fn, (rows, days, delay) in spec.items():
        path = os.path.join(io.INTERIM_DIR, fn)
        if not os.path.exists(path):
            check(fn, False, "文件缺失")
            continue
        df = pd.read_csv(path, encoding="utf-8-sig")
        ok_rows = len(df) == rows
        n_days = df["date"].nunique()
        ok_days = (n_days == days) if days else True
        ok_hours = sorted(df["hour"].unique()) == list(range(24))
        ok_dup = not df.duplicated(subset=["date", "hour"]).any()
        # 数值列缺失
        num_cols = [c for c in df.columns if c not in ("date", "hour", "available_date", "weekday", "day_type", "holiday")]
        n_nan = int(df[num_cols].isna().sum().sum())
        ok_nan = n_nan == 0
        detail = f"行{len(df)}/{rows} 天{n_days}/{days} 时段{'24' if ok_hours else '异常'} 重复{'无' if ok_dup else '有'} 缺失{n_nan}"
        check(fn, ok_rows and ok_days and ok_hours and ok_dup and ok_nan, detail)

    # ---------- 4. 披露延迟复核 ----------
    print("\n[4] 披露延迟（用长表重算）")
    for fn, expect in (("att2_用电量.csv", 4), ("att3_预测信息.csv", -1),
                       ("att3_实际信息.csv", 2), ("att4_价格.csv", 6)):
        df = pd.read_csv(os.path.join(io.INTERIM_DIR, fn), encoding="utf-8-sig")
        d = pd.to_datetime(df["date"])
        a = pd.to_datetime(df["available_date"])
        delays = (a - d).dt.days.unique()
        check(f"{fn} 延迟 == {expect}", len(delays) == 1 and int(delays[0]) == expect,
              f"实测 {sorted(delays.tolist())}")

    # ---------- 5. 附件1 与附件2 的交叉一致性 ----------
    print("\n[5] 附件1 的 5 个典型日应能在附件2 中找到相同的实际用电量")
    a1 = pd.read_csv(os.path.join(io.INTERIM_DIR, "att1_典型日.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(io.INTERIM_DIR, "att2_用电量.csv"), encoding="utf-8-sig")
    merged = a1.merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"],
                      suffixes=("_att1", "_att2"))
    max_diff = (merged["load_actual_att1"] - merged["load_actual_att2"]).abs().max()
    check("典型日负荷与全量一致", max_diff is not None and max_diff < 1e-6,
          f"比对 {len(merged)} 行，最大差 {max_diff:.2e}")

    print("\n" + "=" * 66)
    if FAILS:
        print(f"[X] 有 {len(FAILS)} 项失败：")
        for f in FAILS:
            print("   -", f)
        sys.exit(1)
    print("[OK] T0.7 复核全部通过")


if __name__ == "__main__":
    main()
