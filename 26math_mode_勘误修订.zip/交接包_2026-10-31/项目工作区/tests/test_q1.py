# -*- coding: utf-8 -*-
"""问题1 求解的数学验证（T1）。

不是"看一眼结果像不像"，而是逐条验证数学性质：
  1. 契约：q1_bid.csv 120 行、列齐、无缺失、四项成本之和 == 总成本
  2. 结构：S>0 时 q >= (1+lambda0)L；S<0 时 q <= (1−lambda0)L；S=0 时 q = Q^c
  3. **全局最优**：在每个时段上做网格搜索，闭式解的成本必须 <= 网格任意点
  4. 一致性：LP（K=inf）与闭式解的成本相同
  5. 恒等式：lambda0=0 时成本 == Q^c·P^c + (L−Q^c)·P^D^A（"完全报准"的理论值）
  6. 敏感性：4 个表格存在且水平数达标

用法：<venv>/python.exe tests/test_q1.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.common import io  # noqa: E402
from src.common.settle import LAM0, settle_hour  # noqa: E402
from src.q1.solve import (OUT, q_star, solve_day, solve_day_lp)  # noqa: E402

FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


def main():
    print("=" * 66)
    print("问题1 求解验证")
    print("=" * 66)

    df_all = io.load_attachments()["att1"]

    # ---------- 1. 契约 ----------
    print("\n[1] 输出契约")
    path = os.path.join(OUT, "q1_bid.csv")
    check("q1_bid.csv 存在", os.path.exists(path))
    if os.path.exists(path):
        bid = pd.read_csv(path, encoding="utf-8-sig")
        check("行数 = 120", len(bid) == 120, f"{len(bid)}")
        need = ["date", "hour", "q_bid", "cost_contract", "cost_da_dev",
                "cost_rt_dev", "cost_recovery", "cost_total"]
        check("列齐全", all(c in bid.columns for c in need))
        check("无缺失值", not bid[need[2:]].isna().any().any())
        d = (bid[["cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery"]].sum(axis=1)
             - bid["cost_total"]).abs()
        check("四项成本之和 == 总成本", d.max() < 0.01, f"最大偏差 {d.max():.6f}")
        check("5 个典型日 × 24 时段", bid["date"].nunique() == 5
              and sorted(bid["hour"].unique()) == list(range(24)))

    # ---------- 2. 结构 ----------
    print("\n[2] 解的结构性质")
    n_up = n_dn = n_zero = 0
    bad = 0
    for _, row in df_all.iterrows():
        L, qc = float(row["load_actual"]), float(row["contract_q"])
        pda, prt = float(row["price_da"]), float(row["price_rt"])
        S = prt - pda
        q = float(np.asarray(q_star([L], [pda], [prt], [qc])).reshape(-1)[0])
        if S > 1e-9:
            n_up += 1
            ok = q >= (1 + LAM0) * L - 1e-9
        elif S < -1e-9:
            n_dn += 1
            ok = q <= (1 - LAM0) * L + 1e-9
        else:
            n_zero += 1
            ok = abs(q - qc) < 1e-9
        qnonneg = q >= -1e-9
        if not (ok and qnonneg):
            bad += 1
    check("结构性质全部满足", bad == 0,
          f"S>0 {n_up} 个 / S<0 {n_dn} 个 / S=0 {n_zero} 个，违反 {bad}")

    # ---------- 3. 全局最优（网格搜索） ----------
    print("\n[3] 全局最优性（每时段网格搜索）")
    total_pts = 0
    worse = 0
    for _, row in df_all.iterrows():
        L, qc, pc = row["load_actual"], row["contract_q"], row["contract_p"]
        pda, prt = row["price_da"], row["price_rt"]
        qo = float(q_star([L], [pda], [prt], [qc])[0])
        c_opt = settle_hour(qo, L, pda, prt, qc, pc)["total"]
        grid = np.linspace(0.0, max(2.0 * L, 2.0 * qc) + 1.0, 401)
        costs = [settle_hour(g, L, pda, prt, qc, pc)["total"] for g in grid]
        c_min = min(costs)
        total_pts += len(grid)
        if c_opt > c_min + 1e-6:
            worse += 1
    check("闭式解成本 <= 网格最小值", worse == 0,
          f"共比对 {total_pts} 个网格点，闭式解更差的时段 {worse} 个")

    # ---------- 4. LP 与闭式解一致 ----------
    print("\n[4] LP（K=inf）与闭式解一致")
    max_gap = 0.0
    for d, df in df_all.groupby("date"):
        r_cf = solve_day(df)[1]["sums"]["total"]
        r_lp, _ = solve_day_lp(df, K=None)
        max_gap = max(max_gap, abs(r_cf - r_lp["total"]))
    check("两种解法成本一致", max_gap < 1e-4, f"最大差 {max_gap:.6f} 元")

    # ---------- 5. lambda0=0 恒等式 ----------
    print("\n[5] lambda0=0 时成本应等于「完全报准」的理论值")
    worst = 0.0
    for d, df in df_all.groupby("date"):
        _, r = solve_day(df, lam0=0.0)
        L = df["load_actual"].to_numpy(float)
        qc = df["contract_q"].to_numpy(float)
        pc = df["contract_p"].to_numpy(float)
        pda = df["price_da"].to_numpy(float)
        theory = float((qc * pc).sum() + ((L - qc) * pda).sum())
        worst = max(worst, abs(r["sums"]["total"] - theory))
    check("恒等式成立", worst < 1e-4, f"最大偏差 {worst:.6f} 元")

    # ---------- 6. 敏感性产出 ----------
    print("\n[6] 敏感性产出")
    spec = {"q1_sens_spread.csv": 5, "q1_sens_K.csv": None,
            "q1_sens_lam0.csv": 7, "q1_sens_qbar.csv": 5}
    for fn, n_lvl in spec.items():
        p = os.path.join(OUT, fn)
        exists = os.path.exists(p)
        if not exists:
            check(fn, False, "缺失")
            continue
        df = pd.read_csv(p, encoding="utf-8-sig")
        if n_lvl is None:
            lv = df["kappa"].nunique()
            check(fn, lv >= 5, f"{len(df)} 行 / {lv} 个 kappa 水平")
        else:
            check(fn, len(df) >= n_lvl, f"{len(df)} 行")

    # 单调性：lambda0 越大（允许带越宽）成本越低
    s = pd.read_csv(os.path.join(OUT, "q1_sens_lam0.csv"), encoding="utf-8-sig")
    mono = (s.sort_values("lam0")["total_cost"].diff().dropna() <= 1e-6).all()
    check("lambda0 越大成本越低（单调）", bool(mono),
          "序列 " + ", ".join(f"{v/1e4:.1f}万" for v in s.sort_values("lam0")["total_cost"]))

    # ---------- 7. 真实产出能否通过填表器契约 ----------
    print("\n[7] 真实 q1_bid.csv 对附件6 模板的契约合规性")
    from src.common import fill_att6 as F
    from openpyxl import load_workbook
    try:
        csv_df = F._read_csv(OUT, "q1_bid.csv",
                             list(F.DETAILS["问题1_典型日申报"]["cols"].values()))
        F._check_ranges("q1_bid.csv", csv_df)
        check("量级/缺失值校验通过", True)
    except Exception as e:  # noqa: BLE001
        check("量级/缺失值校验通过", False, f"{type(e).__name__}: {e}")
        csv_df = None

    if csv_df is not None:
        wb = load_workbook(F.DEFAULT_TEMPLATE, data_only=True)
        ws = wb["问题1_典型日申报"]
        tpl = {(str(ws.cell(r, 1).value)[:10], F.text_to_hour(ws.cell(r, 2).value))
               for r in range(4, 124)}
        got = set(zip(csv_df["date"], csv_df["hour"]))
        check("键与模板预填完全一致", got == tpl,
              f"缺 {len(tpl - got)} 个，多 {len(got - tpl)} 个")

    print("\n" + "=" * 66)
    if FAILS:
        print(f"[X] 有 {len(FAILS)} 项失败：{FAILS}")
        return 1
    print("[OK] 问题1 验证全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
