# -*- coding: utf-8 -*-
"""问题3 EDA：价格与价差规律（T3.1）。

产出 3 张图和结论。用法：<venv>/python.exe -m src.q3.eda
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.plotting import TOL, apply_style, new_fig, save_fig, set_seed

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    set_seed(42)
    apply_style()

    a4 = io.load_attachments()["att4"].copy()
    a4["S"] = a4["price_rt"] - a4["price_da"]

    print("=" * 66)
    print("问题3 EDA · 价格与价差")
    print("=" * 66)

    # ---------- 图1：日内形态 ----------
    prof = a4.groupby("hour")[["price_da", "price_rt"]].mean()
    fig, ax = new_fig(figsize=(7.2, 3.6))
    ax.plot(prof.index, prof["price_da"], "o-", ms=3, color=TOL[0], label="日前价格")
    ax.plot(prof.index, prof["price_rt"], "o-", ms=3, color=TOL[1], label="实时价格")
    ax.set_xlabel("时段")
    ax.set_ylabel("平均价格（元/MWh）")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(fontsize=8)
    save_fig(fig, "q3_日内价格形态")

    # ---------- 图2：价差分布 ----------
    fig, axes = new_fig(1, 2, figsize=(9.4, 3.4))
    axes[0].hist(a4["S"], bins=80, color=TOL[2], alpha=0.85)
    axes[0].axvline(0, color="black", lw=0.9)
    axes[0].set_xlabel("价差 实时-日前（元/MWh）")
    axes[0].set_ylabel("频数")
    s = np.sort(a4["S"].to_numpy())
    axes[1].plot(s, np.arange(1, len(s) + 1) / len(s) * 100, color=TOL[3], lw=1.4)
    axes[1].axvline(0, color="black", lw=0.9)
    axes[1].set_xlabel("价差（元/MWh）")
    axes[1].set_ylabel("累积占比（%）")
    save_fig(fig, "q3_价差分布")

    # ---------- 图3：价格序列（标负价与尖峰）----------
    daily = a4.groupby("date").agg(da=("price_da", "mean"), rt=("price_rt", "mean")).reset_index()
    daily["d"] = pd.to_datetime(daily["date"])
    fig, ax = new_fig(figsize=(9.4, 3.2))
    ax.plot(daily["d"], daily["da"], color=TOL[0], lw=1.0, label="日前日均价")
    ax.plot(daily["d"], daily["rt"], color=TOL[1], lw=1.0, label="实时日均价")
    sp = a4[a4["price_rt"] > 800].groupby("date").size()
    if len(sp):
        ax.scatter(pd.to_datetime(sp.index), daily.set_index("date").loc[sp.index, "rt"],
                   s=16, color="black", zorder=3, label="实时价尖峰日（>800）")
    ax.set_xlabel("日期")
    ax.set_ylabel("日均价格（元/MWh）")
    ax.legend(fontsize=7)
    save_fig(fig, "q3_价格序列")

    # ---------- 结论 ----------
    print("\n【结论 1】实时价波动远大于日前价，且存在极端尖峰")
    print(f"  日前：均值 {a4.price_da.mean():.1f}，标准差 {a4.price_da.std():.1f}，"
          f"范围 [{a4.price_da.min():.1f}, {a4.price_da.max():.1f}]")
    print(f"  实时：均值 {a4.price_rt.mean():.1f}，标准差 {a4.price_rt.std():.1f}，"
          f"范围 [{a4.price_rt.min():.1f}, {a4.price_rt.max():.1f}]")

    print("\n【结论 2】存在负电价，且集中在实时市场")
    print(f"  日前负电价占比 {(a4.price_da < 0).mean() * 100:.2f}%，"
          f"实时负电价占比 {(a4.price_rt < 0).mean() * 100:.2f}%")

    print("\n【结论 3】价差接近零均值但对决策极关键")
    print(f"  价差均值 {a4.S.mean():.2f}，中位数 {a4.S.median():.2f}，标准差 {a4.S.std():.1f}")
    print(f"  |价差| 均值 {a4.S.abs().mean():.1f} —— 是价格水平的 "
          f"{a4.S.abs().mean() / a4.price_da.mean() * 100:.0f}%，绝对不可忽略")
    print(f"  价差 >0 占 {(a4.S > 0).mean() * 100:.1f}%，<0 占 {(a4.S < 0).mean() * 100:.1f}%")

    print("\n【结论 4】两价相关性中等，说明'相减法'会放大误差")
    print(f"  Pearson r = {a4.price_da.corr(a4.price_rt):.4f}")
    print("  两价各自有独立扰动，相减后误差方差相加 -> 价差比单价更难预测")

    print("\n【结论 5】价差的日内结构很弱（日内极差远小于价差本身的标准差）")
    med = a4.groupby("hour")["S"].median()
    print(f"  分时段中位数范围 [{med.min():.1f}, {med.max():.1f}]，日内极差 {med.max() - med.min():.1f}")
    print(f"  而价差标准差 {a4.S.std():.1f} —— 极差只占 {abs(med.max() - med.min()) / a4.S.std() * 100:.0f}%")
    print("  -> 提示：'分时段中位数'几乎是个常数，价差的可预测性很有限")

    print("\n产出：q3_日内价格形态.png、q3_价差分布.png、q3_价格序列.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
