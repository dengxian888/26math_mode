# -*- coding: utf-8 -*-
"""问题3 价格特征工程（T3.2–T3.4）。

约束（DECISIONS 口径 #4）：
    附件4 价格      T+6  ->  **只能用 D-7 及以前**
    附件3 预测信息  T-1  ->  可用到 D 日
    附件3 实际信息  T+2  ->  可用到 D-3

> 注意：预测 D 日价格时，最近的**已知价格**是 **D-7** 的（比用电量的 D-5 还晚两天）。
> 这使得"价格历史"特征的信息量远小于"系统预测信息"——这一点会在结果中体现。

目标列（三个，供两法对比）：
    price_da, price_rt, spread = price_rt - price_da
"""
import pandas as pd

from src.common import io
from src.common.panel import assert_consecutive, lag_frame, wide
from src.q2.features import A3_FIELDS, DAY_TYPE_CODE, HOURS, WD_MAP  # 复用同一套定义

# 价格滞后的天数（只能用 <= D-7）
PRICE_LAGS = (7, 8, 9, 14, 21, 28)
ROLL_DAYS = 7


def build_price_panel(data=None) -> pd.DataFrame:
    """构建价格面板：每行 = (date, hour)，含三个目标列与全部特征。"""
    if data is None:
        data = io.load_attachments()

    a2 = data["att2"].copy()          # 只为取日期属性与日历
    a3f = data["att3_forecast"].copy()
    a3a = data["att3_actual"].copy()
    a4 = data["att4"].copy()

    dates = sorted(a4["date"].unique())
    assert_consecutive(dates)

    # ---------- 网格与目标 ----------
    panel = pd.MultiIndex.from_product([dates, HOURS], names=["date", "hour"]).to_frame(index=False)
    panel = panel.merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"], how="left")
    panel["spread"] = panel["price_rt"] - panel["price_da"]

    # ---------- 日期属性 ----------
    attr = (a2[["date", "weekday", "day_type", "holiday"]]
            .drop_duplicates("date").set_index("date").sort_index())
    attr["weekday"] = attr["weekday"].map(WD_MAP).fillna(0).astype(int)
    attr["day_type_code"] = attr["day_type"].map(DAY_TYPE_CODE).fillna(0).astype(int)
    attr["is_weekend"] = attr["day_type"].eq("普通周末").astype(int)
    attr["month"] = [int(d[5:7]) for d in attr.index]
    hol_names = sorted(attr["holiday"].dropna().unique())
    hol_map = {h: i for i, h in enumerate(hol_names)}
    attr["holiday_code"] = attr["holiday"].map(lambda x: hol_map.get(x, -1)).astype(int)
    panel = panel.merge(attr[["weekday", "day_type_code", "holiday_code", "is_weekend", "month"]],
                        left_on="date", right_index=True, how="left")

    # ---------- 价格历史（<= D-7）----------
    pw = wide(a4, ["price_da", "price_rt"])
    for k in PRICE_LAGS:
        panel = panel.merge(lag_frame(pw["price_da"], k, f"da_lag{k}"), on=["date", "hour"], how="left")
        panel = panel.merge(lag_frame(pw["price_rt"], k, f"rt_lag{k}"), on=["date", "hour"], how="left")

    # 最近 7 个可用日（D-13..D-7）的均值 / 标准差
    base_da = pw["price_da"].shift(7)
    base_rt = pw["price_rt"].shift(7)
    for name, series in (("da", base_da), ("rt", base_rt)):
        roll = series.rolling(ROLL_DAYS, min_periods=3)
        panel = panel.merge(lag_frame(roll.mean(), 0, f"{name}_r7mean"), on=["date", "hour"], how="left")
        panel = panel.merge(lag_frame(roll.std(), 0, f"{name}_r7std"), on=["date", "hour"], how="left")

    # 历史价差（由已知的两个价格直接算）
    panel["s_lag7"] = panel["rt_lag7"] - panel["da_lag7"]
    panel["s_r7mean"] = panel["rt_r7mean"] - panel["da_r7mean"]

    # ---------- 附件3 预测信息（D 日可得）----------
    f = a3f[["date", "hour"] + A3_FIELDS].copy()
    f.columns = ["date", "hour"] + [f"a3f_{c}" for c in A3_FIELDS]
    panel = panel.merge(f, on=["date", "hour"], how="left")

    # ---------- 附件3 实际信息（<= D-3）----------
    aw = wide(a3a, A3_FIELDS)
    for c in A3_FIELDS:
        panel = panel.merge(lag_frame(aw[c], 3, f"a3a_{c}_lag3"), on=["date", "hour"], how="left")

    return panel.sort_values(["date", "hour"]).reset_index(drop=True)


FEAT_BASE = (["hour", "weekday", "day_type_code", "holiday_code", "is_weekend", "month"]
             + [f"da_lag{k}" for k in PRICE_LAGS]
             + [f"rt_lag{k}" for k in PRICE_LAGS]
             + ["da_r7mean", "da_r7std", "rt_r7mean", "rt_r7std", "s_lag7", "s_r7mean"])
FEAT_FULL = FEAT_BASE + [f"a3f_{c}" for c in A3_FIELDS] + [f"a3a_{c}_lag3" for c in A3_FIELDS]


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    p = build_price_panel()
    print("面板:", p.shape)
    print("基础特征", len(FEAT_BASE), "| 完整特征", len(FEAT_FULL))
    print("\n目标统计:")
    print(p[["price_da", "price_rt", "spread"]].describe(
        percentiles=[.01, .5, .99]).round(1).to_string())
    print("\n特征缺失率(%):")
    print((p[FEAT_BASE].isna().mean() * 100).round(1).to_string())
