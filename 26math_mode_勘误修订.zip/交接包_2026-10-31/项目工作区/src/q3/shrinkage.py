# -*- coding: utf-8 -*-
"""问题三：决策对齐的收缩（把申报量向合约量收缩）。

动机（G7 评审提出）：论文已证明"MAE 与决策目标不对齐"，却仍按点预测直接代入闭式解。
一个最便宜的决策对齐改进，是**对决策本身做收缩**：

    q(gamma) = Q_c + gamma · (q* − Q_c),      gamma  in  [0, 1]

gamma = 1 即原始确定性申报，gamma = 0 退化为"按合约量申报"。若存在 gamma < 1 使成本低于
按合约量申报，则"点预测决策必然亏损"这一负结论可以被推翻。

**须注意**：gamma 的最优点在同一评估期上选出，属样本内选择；本脚本因此同时报告
整条曲线，以便判断最优点的稳健性（若一片区间都优于基准，样本内选择的风险就低）。

输出 `outputs/q3_shrinkage.csv`。

用法：<venv>/python.exe -m src.q3.shrinkage
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
GAMMAS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.2]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    d = io.load_attachments()
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    df = (q3[["date", "hour", "q_bid"]]
          .merge(d["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(d["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(d["att5"], on=["date", "hour"])
          ).sort_values(["date", "hour"]).reset_index(drop=True)

    qc = df["contract_q"].to_numpy(float)
    qstar = df["q_bid"].to_numpy(float)
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    day_idx = list(df.groupby("date").indices.values())

    def cost(q):
        t = 0.0
        for idx in day_idx:
            t += settle_day(q[idx], L[idx], pda[idx], prt[idx], qc[idx], pc[idx])["sums"]["total"]
        return t

    base = cost(qc)
    rows = []
    for g in GAMMAS:
        q = qc + g * (qstar - qc)
        c = cost(q)
        rows.append({"gamma": g, "总成本": round(c, 2),
                     "相对基准_pct": round((c - base) / base * 100, 3),
                     "申报量均值": round(float(q.mean()), 3)})

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q3_shrinkage.csv"), index=False, encoding="utf-8-sig")

    print("=" * 66)
    print("问题三：决策对齐的收缩  q(gamma) = Qc + gamma·(q* − Qc)")
    print("=" * 66)
    print(out.to_string(index=False))
    best = out.loc[out["总成本"].idxmin()]
    win = out[out["相对基准_pct"] < 0]
    print(f"\n  最优 gamma = {best['gamma']:.1f}，相对基准 {best['相对基准_pct']:+.3f}%")
    if len(win):
        print(f"  优于'按合约量申报'的 gamma 区间: [{win['gamma'].min():.1f}, {win['gamma'].max():.1f}]，"
              f"共 {len(win)} 个点")
    print(f"\n产出：{os.path.join(OUT, 'q3_shrinkage.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
