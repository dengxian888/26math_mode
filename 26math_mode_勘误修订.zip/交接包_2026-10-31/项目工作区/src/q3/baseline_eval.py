# -*- coding: utf-8 -*-
"""问题三：把"分时段中位数"基准也跑成同口径的决策，回答一个关键质疑。

背景（G7 三轮盲评共同提出）：论文采用的 GBDT 价差模型 MAE = 118.62，
而它自己在表 12 里报的"合法基准"（分时段中位数）MAE = 91.99，**劣 5.1%**。
但论文只比较了"直接法 vs 相减法"，从未把这个更强的基准代进决策。

若该基准的决策成本更好，则"价差不可预测"这一归因必须改写——
真正的原因可能是"本文模型选择失败"，而非"价差没有预测价值"。

本脚本用与主流程完全相同的口径（逐周重估、训练截止 W−7、严格无前视的滚动
偏差校正、同一闭式解、同一结算内核），计算：

  方案 A：GBDT + 收缩（本文）
  方案 B：分时段中位数（24 参数基准），不校正
  方案 C：分时段中位数 + 同一滚动偏差校正

对每个方案给出 MAE 与确定性申报的总成本。

输出 `outputs/q3_baseline_compare.csv`。

用法：<venv>/python.exe -m src.q3.baseline_eval
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day
from src.q3.features import build_price_panel
from src.q3.solve import (EVAL_END, EVAL_START, PRICE_LAG, REFIT_DAYS, SEED,
                          deterministic_bid)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
TARGET = "spread"


def walk_forward_profile(panel, target, bias_correct):
    """逐周重估的**分时段中位数**预测（可选施加与主流程同口径的滚动偏差校正）。"""
    dates = sorted(panel["date"].unique())
    eval_dates = [d for d in dates if EVAL_START <= d <= EVAL_END]
    recs = []
    past_pairs = []          # (日期, 残差)，与 src/q3/solve.py 同口径
    i = 0
    while i < len(eval_dates):
        week = eval_dates[i:i + REFIT_DAYS]
        W = week[0]
        pos = dates.index(W)
        train_end = dates[max(0, pos - PRICE_LAG)]
        tr = panel[panel["date"] <= train_end].dropna(subset=[target])

        prof = tr.groupby("hour")[target].median()
        te = panel[panel["date"].isin(week)]
        raw = te["hour"].map(prof).to_numpy(float)
        raw = np.where(np.isnan(raw), 0.0, raw)

        if bias_correct:
            cutoff = dates[max(0, pos - PRICE_LAG)]
            usable = [r for d, r in past_pairs if d <= cutoff]
            bias = float(np.mean(usable)) if usable else 0.0
        else:
            bias = 0.0
        pred = raw + bias

        f = te[["date", "hour"]].copy()
        f["yhat"] = pred
        recs.append(f)

        if bias_correct:
            for dv, rv in zip(te["date"].to_numpy(), te[target].to_numpy(float) - raw):
                if not np.isnan(rv):
                    past_pairs.append((dv, float(rv)))
        i += REFIT_DAYS
    return pd.concat(recs, ignore_index=True)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    np.random.seed(SEED)

    panel = build_price_panel()
    att = io.load_attachments()
    a2, a5 = att["att2"], att["att5"]

    # 评估期真实值
    from src.q3.features import build_price_panel as _b  # noqa: F401
    ev = panel[(panel["date"] >= EVAL_START) & (panel["date"] <= EVAL_END)][
        ["date", "hour", "price_da", "price_rt", "spread"]
    ].copy()
    ev = ev.merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"], how="inner")
    ev = ev.merge(a5, on=["date", "hour"], how="inner").sort_values(["date", "hour"]).reset_index(drop=True)

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q2 = q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
    ev = ev.merge(q2, on=["date", "hour"], how="left")

    q3b = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q3b = q3b[["date", "hour", "pred_spread_final", "q_bid"]]
    ev = ev.merge(q3b, on=["date", "hour"], how="left")

    L = ev["load_actual"].to_numpy(float)
    pda = ev["price_da"].to_numpy(float)
    prt = ev["price_rt"].to_numpy(float)
    qc = ev["contract_q"].to_numpy(float)
    pc = ev["contract_p"].to_numpy(float)

    def settle(q):
        tot = 0.0
        for _, idx in ev.groupby("date").indices.items():
            tot += settle_day(q[idx], L[idx], pda[idx], prt[idx], qc[idx], pc[idx])["sums"]["total"]
        return tot

    # 三种预测
    pred_prof = walk_forward_profile(panel, TARGET, bias_correct=False)
    pred_prof_bc = walk_forward_profile(panel, TARGET, bias_correct=True)
    ev = ev.merge(pred_prof.rename(columns={"yhat": "S_prof"}), on=["date", "hour"], how="left")
    ev = ev.merge(pred_prof_bc.rename(columns={"yhat": "S_prof_bc"}), on=["date", "hour"], how="left")

    truth = ev[TARGET].to_numpy(float)
    rows = []
    plans = [
        ("本文：GBDT + 收缩 + 滚动校正", ev["pred_spread_final"].to_numpy(float), ev["q_bid"].to_numpy(float)),
        ("基准：分时段中位数（不校正）", ev["S_prof"].to_numpy(float), None),
        ("基准：分时段中位数 + 同一滚动校正", ev["S_prof_bc"].to_numpy(float), None),
    ]
    for name, spred, q_fixed in plans:
        mae = float(np.nanmean(np.abs(spred - truth)))
        q = q_fixed if q_fixed is not None else deterministic_bid(ev["L_hat"].to_numpy(float), spred, qc)
        cost = settle(q)
        rows.append({"方案": name, "价差 MAE": round(mae, 2), "总成本": round(cost, 2)})

    out = pd.DataFrame(rows)
    base_cost = settle(qc)
    out["相对基准_pct"] = ((out["总成本"] - base_cost) / base_cost * 100).round(3)
    out.to_csv(os.path.join(OUT, "q3_baseline_compare.csv"), index=False, encoding="utf-8-sig")

    print("=" * 78)
    print("问题三：更强的基准能否做出更好的决策？（153 天，事后结算）")
    print("=" * 78)
    print(f"{'方案':<34}{'MAE':>10}{'总成本':>16}{'相对基准':>10}")
    for r in out.itertuples():
        print(f"{r.方案:<34}{r.价差_MAE if hasattr(r,'价差_MAE') else r[2]:>10.2f}"
              f"{r.总成本:>16,.2f}{r.相对基准_pct:>9.3f}%")
    print(f"\n  按合约量申报：{base_cost:,.2f} 元")
    print(f"\n产出：{os.path.join(OUT, 'q3_baseline_compare.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
