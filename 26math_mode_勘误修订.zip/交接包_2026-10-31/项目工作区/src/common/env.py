# -*- coding: utf-8 -*-
"""运行环境适配：把进程临时目录固定到项目 `_tmp/`。

背景：本机的 `%LOCALAPPDATA%\\Temp` 对子进程是**拒绝访问**的
（实测：`miktexsetup`、pulp 的 CBC 求解器都在这里失败，报 WinError 5 / PermissionError）。
凡是要落临时文件的库（pulp 写 .mps/.sol、matplotlib 字体缓存等）都会踩到。

做法：把 `tempfile.tempdir` 和 TMP/TEMP 环境变量都指到项目内可写的 `_tmp/`。

用法：在**任何**会落临时文件的行为之前调用一次：

    from src.common.env import use_project_tmp
    use_project_tmp()
"""
import os
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(_HERE))
TMP_DIR = os.path.join(ROOT, "_tmp")


def use_project_tmp() -> str:
    """把临时目录切到项目 _tmp，返回该目录。可重复调用（幂等）。"""
    os.makedirs(TMP_DIR, exist_ok=True)
    tempfile.tempdir = TMP_DIR
    os.environ["TMP"] = TMP_DIR
    os.environ["TEMP"] = TMP_DIR
    return TMP_DIR


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print("临时目录 ->", use_project_tmp())
    print("gettempdir() ->", tempfile.gettempdir())
