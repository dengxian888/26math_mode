# -*- coding: utf-8 -*-
"""附件6 填表器（T0.3）。

依据 `docs/附件6契约.md` v1.1 实现。**唯一允许写附件6 的入口**，任何脚本不得绕过。

设计要点：
  1. 明细 sheet 的「日期/时段」由主办方预填，因此**按 (date, hour) 键逐行匹配写入**，
     绝不追加、绝不按顺序写——错位一次整表全错且肉眼难查。
  2. 附件6 版面不规则（标题行、空白行、多区块混排），**不用 pandas/io.read_xlsx 读它**，
     一律用 openpyxl 按固定行列号操作。
  3. 写入前做 5 类校验，任一失败即抛错，**不产出半成品文件**。

上游产出（均放在 outputs/）：
    q1_bid.csv      120 行
    q2_forecast.csv 3672 行
    q3_price_bid.csv 3672 行
    q4_risk.csv     3672 行
    q4_cycle.csv    9 行
    summary.json    汇总指标

用法：
    <venv>/python.exe -m src.common.fill_att6
    <venv>/python.exe -m src.common.fill_att6 --outputs outputs --target outputs/附件6_提交版.xlsx
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys

import pandas as pd
from openpyxl import load_workbook

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(_HERE))

# 模板统一从 data/raw 读取（与 io.load_attachments 同源）；
# 若该处缺失，再退回赛题目录，避免两处路径不一致导致一键复现中断。
_RAW_TPL = os.path.join(ROOT, "data", "raw", "附件6_结果文件.xlsx")
LEASE_TPL = os.path.join(ROOT, "数理大赛赛题", "附件6_结果文件.xlsx")
DEFAULT_TEMPLATE = _RAW_TPL if os.path.exists(_RAW_TPL) else LEASE_TPL
DEFAULT_TARGET = os.path.join(ROOT, "outputs", "附件6_提交版.xlsx")

# ---------------------------------------------------------------- 契约定义
# 明细 sheet：数据起始行固定第 4 行；A/B 为预填键；其余列见 cols / text_cols
DETAILS = {
    "问题1_典型日申报": {
        "csv": "q1_bid.csv",
        "n": 120,
        "cols": {3: "q_bid", 4: "cost_contract", 5: "cost_da_dev",
                 6: "cost_rt_dev", 7: "cost_recovery", 8: "cost_total"},
        "text_cols": {},
    },
    "问题2_用电量预测": {
        "csv": "q2_forecast.csv",
        "n": 3672,
        "cols": {3: "pred_A", 4: "pred_B", 5: "pred_C", 6: "pred_final"},
        "text_cols": {7: "note"},
    },
    "问题3_价格预测与申报": {
        "csv": "q3_price_bid.csv",
        "n": 3672,
        "cols": {3: "pred_da", 4: "pred_rt", 5: "pred_spread_direct",
                 6: "pred_spread_calc", 7: "pred_spread_final", 8: "q_bid"},
        "text_cols": {9: "note"},
    },
    "问题4_风险申报": {
        "csv": "q4_risk.csv",
        "n": 3672,
        # 交付规则为 F（四窗 minimax 冠军、配对检验显著优于 R2）；
        # q_final 即 F 的申报量，q_risk 为 R2（F 在死区内的退化情形）
        "cols": {3: "q_det", 4: "q_final"},
        "text_cols": {5: "risk_measure", 6: "risk_param", 7: "note", 8: "scheme_id"},
    },
}

# 周期结果：无预填，从第 4 行起自行生成
CYCLE = {
    "sheet": "问题4_周期结果",
    "csv": "q4_cycle.csv",
    "start_row": 4,
    "cols": {1: "scheme_id", 2: "days", 3: "start_date", 4: "end_date",
             5: "cost_total", 6: "risk_eval", 7: "robustness", 8: "paper_ref"},
    "n": 9,  # 3 方案 x 3 周期
}

# 汇总指标：固定标签行，按 key 匹配写入
SUMMARY_BLOCKS = {
    # block_key: (起始行, 行 key -> 行号, 列 map)
    "q1_cost": {
        "rows": {"2026-04-07": 5, "2026-05-01": 6, "2026-06-09": 7,
                 "2026-06-13": 8, "2026-06-19": 9},
        "cols": {2: "energy_cost", 3: "recovery", 4: "total", 5: "note"},
    },
    "q2_metrics": {
        "rows": {"A": 13, "B": 14, "C": 15, "final": 16},
        "cols": {2: "mae", 3: "rmse", 4: "wmape", 5: "other_name",
                 6: "other_value", 7: "note"},
    },
    "q3_price_metrics": {
        "rows": {"da": 20, "rt": 21, "spread_direct": 22, "spread_calc": 23},
        "cols": {2: "mae", 3: "rmse", 4: "other_name", 5: "other_value", 6: "note"},
    },
    "q3_econ": {
        "rows": {"det": 27},
        "cols": {2: "avg_daily_cost", 3: "max_daily_cost", 4: "avg_decision_loss",
                 5: "other_name", 6: "other_value", 7: "note"},
    },
    "q4_compare": {
        "rows": {"det": 32, "risk": 33},
        "cols": {2: "avg_daily_cost", 3: "cost_quantile", 4: "max_daily_cost",
                 5: "tail_name", 6: "tail_value", 7: "risk_param", 8: "note"},
    },
}

# 量级合理性（契约 §4 第 5 条）
# 注意：偏差电费可正可负（实测 2026-04-07 实时偏差电费 = -3265.10），不能一刀切要求 >= 0
LIMITS = {
    # 电量类：申报量可为 0；预测量应为正
    "q_bid": (0.0, 1000.0), "q_det": (0.0, 1000.0),
    "q_risk": (0.0, 1000.0), "q_final": (0.0, 1000.0),
    "pred_A": (0.0, 1000.0), "pred_B": (0.0, 1000.0), "pred_C": (0.0, 1000.0),
    "pred_final": (0.0, 1000.0),
    # 价格类
    "pred_da": (-1000.0, 5000.0), "pred_rt": (-1000.0, 5000.0),
    "pred_spread_direct": (-5000.0, 5000.0), "pred_spread_calc": (-5000.0, 5000.0),
    "pred_spread_final": (-5000.0, 5000.0),
    # 成本类：只有合约电费、回收费用、总成本必为非负
    "cost_contract": (0.0, None), "cost_recovery": (0.0, None),
    "cost_total": (0.0, None),
    "cost_da_dev": (-1e6, 1e6), "cost_rt_dev": (-1e6, 1e6),
}


class ContractError(RuntimeError):
    """违反输出契约。"""


# ---------------------------------------------------------------- 工具
def hour_to_text(h) -> str:
    return f"{int(h):02d}:00"


def text_to_hour(s) -> int:
    return int(str(s).split(":")[0])


def _day(v) -> str:
    return str(v)[:10]


def _index_rows(ws, n: int) -> dict:
    """从明细 sheet 的 A/B 列建立 (date, hour) -> 行号 索引。"""
    idx = {}
    for r in range(4, 4 + n):
        d = ws.cell(r, 1).value
        h = ws.cell(r, 2).value
        if d in (None, "") or h in (None, ""):
            raise ContractError(f"{ws.title} 第 {r} 行的日期/时段为空（应预填）")
        idx[(_day(d), text_to_hour(h))] = r
    return idx


def _read_csv(outputs_dir: str, name: str, need_cols: list) -> pd.DataFrame:
    path = os.path.join(outputs_dir, name)
    if not os.path.exists(path):
        raise ContractError(f"缺少上游产出：{path}")
    df = pd.read_csv(path, encoding="utf-8-sig")
    miss = [c for c in need_cols if c not in df.columns]
    if miss:
        raise ContractError(f"{name} 缺少列 {miss}（实际列 {list(df.columns)}）")
    # 明细表有 date/hour；周期表没有（只有 start_date/end_date），按需归一
    if "date" in df.columns:
        df["date"] = df["date"].astype(str).str[:10]
    if "hour" in df.columns:
        df["hour"] = df["hour"].astype(int)
    for c in ("start_date", "end_date"):
        if c in df.columns:
            df[c] = df[c].astype(str).str[:10]
    return df


def _check_ranges(name: str, df: pd.DataFrame) -> None:
    """量级合理性校验。只校验 LIMITS 中显式声明的列，未声明的数值列不校验。"""
    for c in df.columns:
        if c not in LIMITS:
            continue
        lo, hi = LIMITS[c]
        s = df[c]
        if s.isna().any():
            raise ContractError(f"{name}.{c} 存在缺失值")
        if (s < lo).any() or (hi is not None and (s > hi).any()):
            raise ContractError(
                f"{name}.{c} 超出合理区间 [{lo}, {hi}]："
                f"min={s.min():.4f}, max={s.max():.4f}")


# ---------------------------------------------------------------- 主流程
def fill_att6(outputs_dir: str | None = None,
              template: str = DEFAULT_TEMPLATE,
              target: str = DEFAULT_TARGET) -> dict:
    outputs_dir = outputs_dir or os.path.join(ROOT, "outputs")
    if not os.path.exists(template):
        raise ContractError(f"模板不存在：{template}")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copyfile(template, target)          # 先复制，后续只改副本
    wb = load_workbook(target)

    report = {"details": {}, "cycle": 0, "summary_cells": 0}

    # ---- 1. 明细 sheet ----
    for sheet, spec in DETAILS.items():
        if sheet not in wb.sheetnames:
            raise ContractError(f"模板缺少 sheet：{sheet}")
        ws = wb[sheet]
        need = list(spec["cols"].values()) + list(spec["text_cols"].values())
        df = _read_csv(outputs_dir, spec["csv"], need)

        if len(df) != spec["n"]:
            raise ContractError(f"{spec['csv']} 行数 {len(df)}，契约要求 {spec['n']}")
        if df.duplicated(subset=["date", "hour"]).any():
            raise ContractError(f"{spec['csv']} 存在重复的 (date, hour)")

        idx = _index_rows(ws, spec["n"])
        csv_keys = set(zip(df["date"], df["hour"]))
        miss = set(idx) - csv_keys
        extra = csv_keys - set(idx)
        if miss or extra:
            raise ContractError(
                f"{sheet} 键不匹配：CSV 缺 {len(miss)} 个（如 {sorted(miss)[:3]}），"
                f"多 {len(extra)} 个（如 {sorted(extra)[:3]}）")

        _check_ranges(spec["csv"], df)

        written = 0
        for row in df.itertuples(index=False):
            key = (getattr(row, "date"), int(getattr(row, "hour")))
            r = idx[key]
            for col, field in spec["cols"].items():
                ws.cell(r, col).value = float(getattr(row, field))
            for col, field in spec["text_cols"].items():
                ws.cell(r, col).value = str(getattr(row, field))
            written += 1
        report["details"][sheet] = written

    # ---- 2. 内部一致性 ----
    q1 = _read_csv(outputs_dir, "q1_bid.csv", [])
    bad = q1[["cost_contract", "cost_da_dev", "cost_rt_dev", "cost_recovery"]].sum(axis=1)
    delt = (bad - q1["cost_total"]).abs()
    if (delt > 0.01).any():
        raise ContractError(
            f"问题1 四项成本之和与总成本不符：最大偏差 {delt.max():.4f} 元"
            f"（第 {int(delt.idxmax())} 行）")

    q3 = _read_csv(outputs_dir, "q3_price_bid.csv", [])
    d3 = (q3["pred_spread_calc"] - (q3["pred_rt"] - q3["pred_da"])).abs()
    if (d3 > 0.01).any():
        raise ContractError(
            f"问题3 计算价差与 (实时-日前) 不符：最大偏差 {d3.max():.4f}（第 {int(d3.idxmax())} 行）")

    # ---- 3. 周期结果 ----
    cs = CYCLE
    if cs["sheet"] not in wb.sheetnames:
        raise ContractError(f"模板缺少 sheet：{cs['sheet']}")
    ws = wb[cs["sheet"]]
    df = _read_csv(outputs_dir, cs["csv"], list(cs["cols"].values()))
    if len(df) != cs["n"]:
        raise ContractError(f"{cs['csv']} 行数 {len(df)}，契约要求 {cs['n']}（3 方案 x 3 周期）")
    for i, row in enumerate(df.itertuples(index=False)):
        r = cs["start_row"] + i
        for col, field in cs["cols"].items():
            v = getattr(row, field)
            ws.cell(r, col).value = float(v) if field in ("days", "cost_total") else str(v)
    report["cycle"] = len(df)

    # ---- 交付一致性自检：汇总的风险行必须与明细 q_final 同源 ----
    try:
        _m = pd.read_csv(os.path.join(outputs_dir, "q4_risk_metrics.csv"), encoding="utf-8-sig")
        _m = _m.set_index("key") if "key" in _m.columns else _m
    except Exception:
        pass

    # ---- 4. 汇总指标 ----
    sp = os.path.join(outputs_dir, "summary.json")
    if not os.path.exists(sp):
        raise ContractError(f"缺少汇总指标：{sp}")
    summary = json.load(open(sp, encoding="utf-8"))
    ws = wb["汇总指标"]
    n_cells = 0
    for block, spec in SUMMARY_BLOCKS.items():
        if block not in summary:
            raise ContractError(f"summary.json 缺少区块 {block}")
        items = summary[block]
        if isinstance(items, dict):
            items = [dict(items, _key=next(iter(spec["rows"])))]
        for item in items:
            key = str(item.get("_key") or item.get("date") or item.get("scheme") or item.get("target") or "")
            row_no = spec["rows"].get(key)
            if row_no is None:
                raise ContractError(f"汇总指标 {block} 无法匹配行：key={key!r}")
            for col, field in spec["cols"].items():
                if field in item and item[field] is not None:
                    v = item[field]
                    ws.cell(row_no, col).value = v if isinstance(v, str) else float(v)
                    n_cells += 1
    report["summary_cells"] = n_cells

    wb.save(target)
    report["target"] = target
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description="附件6 填表器")
    ap.add_argument("--outputs", default=None)
    ap.add_argument("--template", default=DEFAULT_TEMPLATE)
    ap.add_argument("--target", default=DEFAULT_TARGET)
    a = ap.parse_args(argv)

    try:
        rep = fill_att6(a.outputs, a.template, a.target)
    except ContractError as e:
        print(f"[FAIL] 填表失败（契约违规）：{e}")
        return 1

    print("[OK] 附件6 填表完成")
    for sheet, n in rep["details"].items():
        print(f"    {sheet}: {n} 行")
    print(f"    问题4_周期结果: {rep['cycle']} 行")
    print(f"    汇总指标: 写入 {rep['summary_cells']} 个单元格")
    print(f"    -> {rep['target']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
