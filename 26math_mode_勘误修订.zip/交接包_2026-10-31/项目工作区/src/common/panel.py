# -*- coding: utf-8 -*-
"""长表 <-> 宽表 的对齐工具（Q2/Q3 共用）。

本项目的原始数据是 (日期, 时段) 长表。做滞后特征时最稳的做法是：
先 pivot 成"日期 x 时段"的宽表，再用 `shift(k)` 取 D-k 日的值——
这样不会出现 merge 顺序错乱，也不会因为缺失日期而错位。

**前提**：日期序列必须连续（否则 shift 的行偏移不等于 k 天），
`assert_consecutive()` 会检查这一点。
"""
import pandas as pd

HOURS = list(range(24))


def assert_consecutive(dates):
    """确认日期序列逐日连续。不连续则 shift 语义不成立，必须报错。"""
    d = pd.to_datetime(pd.Series(sorted(dates)))
    gaps = d.diff().dropna().dt.days.unique()
    if len(gaps) != 1 or gaps[0] != 1:
        raise ValueError(f"日期不连续，shift 语义不成立：间隔 {sorted(gaps)}")


def wide(df, value_cols, index="date", columns="hour"):
    """长表 -> {col: 日期x时段 宽表}，日期升序、时段固定 0..23。"""
    out = {}
    for c in value_cols:
        w = df.pivot_table(index=index, columns=columns, values=c, aggfunc="last")
        out[c] = w.reindex(columns=HOURS).sort_index()
    return out


def lag_frame(wide_df: pd.DataFrame, k: int, name: str) -> pd.DataFrame:
    """取 D-k 日的值并摊回 (date, hour, name) 长表。k=0 表示不变。"""
    s = wide_df.shift(k) if k else wide_df
    s = s.copy()
    s.index.name = "date"
    return s.stack(future_stack=True).rename(name).reset_index()
