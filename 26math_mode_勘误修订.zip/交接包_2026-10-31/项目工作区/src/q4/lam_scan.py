# -*- coding: utf-8 -*-
"""问题四：风险厌恶系数 lambda 的扫描（论文表 20 的问题四一行）。

论文初稿曾认为 lambda 由 0 增至 8 时申报量均值基本不动、仅波动下降。用当前代码重算
后发现该说法有误：lambda 由 0 增至 8，申报量均值由 43.64 升到 49.26 MWh（+12.9%），
标准差由 13.44 降到 11.80（-12.2%）。即 lambda 的作用是"把申报推高 + 压缩离散度"，
而非"几乎不改变申报"。正文与表 24 已按本模块的重算结果更正。

输出 `outputs/q4_lam_scan.csv`。

用法：<venv>/python.exe -m src.q4.lam_scan
"""
import os
import sys

import numpy as np
import pandas as pd

from src.q4.solve import SEED, prepare, rolling_sim

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
LAMS = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    df = prepare()
    dates = sorted(df["date"].unique())

    rows = []
    for lam in LAMS:
        plan = rolling_sim(df, dates, lam, np.random.default_rng(SEED))
        q = np.concatenate([np.asarray(x, float) for x in plan["q"]])
        rows.append({
            "lambda": lam,
            "申报量均值": round(float(q.mean()), 3),
            "申报量标准差": round(float(q.std(ddof=1)), 3),
            "最小": round(float(q.min()), 2),
            "最大": round(float(q.max()), 2),
        })
        print(f"  lambda={lam:<4} 均值 {rows[-1]['申报量均值']:>7.2f}  "
              f"标准差 {rows[-1]['申报量标准差']:>6.2f}")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q4_lam_scan.csv"), index=False, encoding="utf-8-sig")
    print("\n" + "=" * 60)
    print(out.to_string(index=False))
    q0, q8 = out.iloc[0], out.iloc[-1]
    print(f"\n  lambda 0→8：均值 {q0['申报量均值']:.2f}→{q8['申报量均值']:.2f}，"
          f"标准差 {q0['申报量标准差']:.2f}→{q8['申报量标准差']:.2f}")
    print(f"  产出：{os.path.join(OUT, 'q4_lam_scan.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
