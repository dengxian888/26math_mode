# -*- coding: utf-8 -*-
"""问题四：优化器精度的验证（论文 §3.4.2 所称"60 组随机参数 × 4001 点密网格对照"）。

论文用黄金分割搜索求每个时段的最优申报量，并声称"经 60 组随机参数与 4001 点密网格
对照，黄金分割全部不劣于网格"。该对照此前只跑过一次、未留脚本，本模块将其固化。

做法：随机生成 60 组（负荷/价差预测、合约量价、残差池），分别
  (1) 用 src.q4.solve.optimal_q（黄金分割）求 q*；
  (2) 用 4001 点均匀网格在同一区间上求最小值；
比较两者的目标值。黄金分割应当**不劣于**密网格（差值 <= 0 或仅数值级）。

输出 `outputs/q4_optimizer_check.csv`。

用法：<venv>/python.exe -m src.q4.validate_optimizer
"""
import os
import sys

import numpy as np
import pandas as pd

from src.q4.solve import cvar, optimal_q, scenario_costs

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
N_TRIALS = 60
N_GRID = 4001
SEED = 7


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    rng = np.random.default_rng(SEED)
    rows = []
    for t in range(N_TRIALS):
        L_hat = rng.uniform(20, 60)
        S_hat = rng.uniform(-60, 60)
        qc = rng.uniform(20, 55)
        pc = rng.uniform(300, 450)
        pda = rng.uniform(300, 450)
        lam = float(rng.choice([0.0, 0.5, 2.0]))
        n = 200
        e = rng.normal(0, 3.2, n)
        f = rng.normal(0, 200, n)

        q_gold, obj_gold = optimal_q(L_hat, S_hat, pda, qc, pc, e, f, lam)

        Ls = np.maximum(L_hat + e, 0.0)
        Ss = S_hat + f
        grid = np.linspace(0.0, 2.0 * max(L_hat, qc), N_GRID)
        objs = np.array([
            scenario_costs(x, Ls, Ss, pda, qc, pc).mean()
            + lam * cvar(scenario_costs(x, Ls, Ss, pda, qc, pc))
            for x in grid
        ])
        i = int(np.argmin(objs))
        rows.append({
            "trial": t, "lambda": lam,
            "黄金分割目标": round(obj_gold, 4),
            "密网格目标": round(float(objs[i]), 4),
            "差值": round(obj_gold - float(objs[i]), 6),
            "golden_更优": bool(obj_gold < float(objs[i]) - 1e-6),
        })

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "q4_optimizer_check.csv"), index=False, encoding="utf-8-sig")

    print("=" * 66)
    print(f"问题四优化器验证（{N_TRIALS} 组随机参数 vs {N_GRID} 点密网格）")
    print("=" * 66)
    print(f"  黄金分割严格更优的组数: {int(df['golden_更优'].sum())}/{N_TRIALS}")
    print(f"  最大'劣于网格'幅度: {df['差值'].max():+.6f}（应 <= 0 或仅数值噪声）")
    print(f"  明显劣于网格（>1e-3）的组数: {int((df['差值'] > 1e-3).sum())}")
    print(f"\n产出：{os.path.join(OUT, 'q4_optimizer_check.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
