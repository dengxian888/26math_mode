# -*- coding: utf-8 -*-
"""问题四：样本外裁判（论文表 23）。

把评估期设为 2026-02-01 至 03-31（此前从未参与任何选择），用与正文相同的
管线重跑后，对同一批规则结算并排名。

**预注册判据**（见 `reports/样本外裁判_预注册.md`，在运行前冻结）：
  1. 主判据：日均成本最低者胜；
  2. 并列处理：若日均成本差 < 0.10 个百分点，取日 CVaR95 较低者；
  3. 一致性检验：与 4–8 月的排名并列，检查是否同序。

**说明**：2–3 月的预测不可由本脚本重算（需重跑问题二、三），故本脚本读取预先产出的
快照 `outputs/oos_predictions_2_3.csv`。该快照的生成方式：
```bash
export EVAL_START=2026-02-01 EVAL_END=2026-03-31
python -m src.q2.solve && python -m src.q3.solve
# 取 q2_forecast.csv 与 q3_price_bid.csv 的并集存为快照，然后还原主产物
```

输出 `outputs/oos_1_3_month.csv`。

用法：<venv>/python.exe -m src.q4.oos_judge
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
SNAP = os.path.join(OUT, "oos_predictions_2_3.csv")
MAIN_BENCH = os.path.join(OUT, "q4_benchmark.csv")   # 4–8 月的排名，用于并列对照


def build_rules(df):
    """构造 10 条参评规则（含 R1/R3，由快照里的 q_R1/q_R3 给出）。"""
    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)
    dn = 0.8 * Lh
    mu = df["mu"].to_numpy(float)
    sd = df["sd"].to_numpy(float)
    z = mu / (sd / np.sqrt(28))
    inside = (np.abs(z) < 1.5) & np.isfinite(sd)
    return {
        "A 按合约量": qc,
        "B 恒报 L_hat": Lh,
        "C 恒报 max(1.2L_hat,Qc)": up,
        "恒报 1.2L_hat": 1.2 * Lh,
        "D 恒报 0.8L_hat": dn,
        "E 28日符号切换": np.where(mu > 0, up, dn),
        "F 死区theta=1.5": np.where(inside, df["q_risk"].to_numpy(float), np.where(mu > 0, up, dn)),
        "G 确定性申报": df["q_bid"].to_numpy(float),
        "H 风险申报 R2": df["q_risk"].to_numpy(float),
        "R1 风险申报 R1": df["q_R1"].to_numpy(float),
        "R3 风险申报 R3": df["q_R3"].to_numpy(float),
    }


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    if not os.path.exists(SNAP):
        print(f"[跳过] 缺少快照 {SNAP}；需先按模块 docstring 的说明生成")
        print("      （该步依赖重跑问题二/三的样本外预测，不属于默认流程）")
        return 0

    d = io.load_attachments()
    snap = pd.read_csv(SNAP, encoding="utf-8-sig")
    df = (snap.merge(d["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
              .merge(d["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
              .merge(d["att5"], on=["date", "hour"])
              .sort_values(["date", "hour"]).reset_index(drop=True))
    # 2–3 月的 R2 申报量：用与主流程相同的情景法重算代价较高，
    # 此处直接用确定性申报作近似会失真，故缺省置为 q_bid 并标注。
    if "q_risk" not in df.columns:
        raise ValueError("快照缺少 q_risk 列；若用 q_bid 顶替，规则 H(F=R2) 会与 G 相同。"
                         "请按模块 docstring 重新生成含 q_risk 的快照。")

    df["S_actual"] = df["price_rt"] - df["price_da"]
    # 完整合法历史：附件4 价格 T+6 披露，故 D 日可用的最晚价差是 D-7。
    # 只用 df 内部日期会把评估期开头判为"无历史"，白丢一段合法信息。
    a4 = d["att4"].copy()
    a4["S"] = a4["price_rt"] - a4["price_da"]
    hist = a4.groupby("date")["S"].mean()
    s_by = pd.concat([hist, df.groupby("date")["S_actual"].mean()]).groupby(level=0).last()
    dates = sorted(s_by.index)
    mu = {}
    sd = {}
    for D in dates:
        past = [x for x in dates
                if x < D and (pd.Timestamp(D) - pd.Timestamp(x)).days >= 7]
        if len(past) < 5:
            mu[D], sd[D] = 0.0, np.nan
        else:
            v = s_by[past[-28:]].to_numpy(float)
            mu[D], sd[D] = float(v.mean()), float(v.std(ddof=1))
    df["mu"] = df["date"].map(mu)
    df["sd"] = df["date"].map(sd)

    rules = build_rules(df)
    qc = df["contract_q"].to_numpy(float)
    idx_by_day = list(df.groupby("date").indices.items())
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)

    def daily(q):
        out = []
        for _, idx in idx_by_day:
            out.append(settle_day(np.asarray(q, float)[idx], L[idx], pda[idx],
                                  prt[idx], qc[idx], pc[idx])["sums"]["total"])
        return np.asarray(out, float)

    base = daily(qc).sum()
    rows = []
    for name, q in rules.items():
        c = daily(q)
        k = max(1, int(np.ceil(0.05 * len(c))))
        rows.append({"规则": name, "总成本": round(float(c.sum()), 2),
                     "相对基准_pct": round(float((c.sum() - base) / base * 100), 3),
                     "日均": round(float(c.mean()), 2),
                     "日sigma": round(float(c.std(ddof=1)), 2),
                     "CVaR95": round(float(np.sort(c)[-k:].mean()), 2)})
    out = pd.DataFrame(rows).sort_values("日均").reset_index(drop=True)

    # 预注册判据的并列处理：若与前一名的日均成本差 < 0.10 个百分点，
    # 则按日 CVaR95 较低者排前（0.10 个百分点换算为元）。
    # 0.10 个百分点按**日均**换算：分母必须是本窗口的结算天数，而不是完整历史的天数
    n_day = len(qc) and len(idx_by_day)
    tolr = 0.0010 * (base / n_day)
    order = []
    i = 0
    while i < len(out):
        j = i + 1
        while j < len(out) and (out.loc[j, "日均"] - out.loc[i, "日均"]) < tolr:
            j += 1
        grp = out.iloc[i:j].sort_values("CVaR95")
        order.extend(grp.index.tolist())
        i = j
    out = out.loc[order].reset_index(drop=True)
    # 并列名次：日均与 CVaR95 完全相同的规则给同一名次（如 1,2,3,3,5）
    ranks = []
    for i in range(len(out)):
        same = ((out["日均"] - out.loc[i, "日均"]).abs() < 1e-6) & \
               ((out["CVaR95"] - out.loc[i, "CVaR95"]).abs() < 1e-6)
        ranks.append(int(np.flatnonzero(same.to_numpy())[0]) + 1)
    out["排名"] = ranks
    out.to_csv(os.path.join(OUT, "oos_1_3_month.csv"), index=False, encoding="utf-8-sig")

    print("=" * 76)
    print(f"样本外裁判 2026-02-01 ~ 03-31（{len(dates)} 天，价差均值 {df['S_actual'].mean():+.2f}）")
    print("=" * 76)
    print(out[["排名", "规则", "相对基准_pct", "CVaR95"]].to_string(index=False))
    print(f"\n  预注册判据（日均最低者胜）: {out.iloc[0]['规则']}"
          f"（{out.iloc[0]['相对基准_pct']:+.3f}%）")

    if os.path.exists(MAIN_BENCH):
        mb = pd.read_csv(MAIN_BENCH, encoding="utf-8-sig")
        print(f"\n  4–8 月对照：R2 {mb.set_index('key').loc['R2','相对基准_pct']:+.3f}%")
    print(f"\n产出：{os.path.join(OUT, 'oos_1_3_month.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
