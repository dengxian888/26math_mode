# -*- coding: utf-8 -*-
"""问题四：日成本的风险指标（用于检验各方案的风险特征）。

背景：正文 §3.4.2 曾声称"表 16 报告的 CVaR 是日成本的 CVaR"，但该表只有总成本，
属于自述与表格不符。本脚本补齐这一缺口：对每个方案给出

    日成本均值 / 标准差 / VaR95 / CVaR95 / 最大单日成本

其中 CVaR95 按经验分布取最差 ceil(5%·153) = 8 天的均值，与正文口径一致。

输出 `outputs/q4_risk_metrics.csv`。

用法：<venv>/python.exe -m src.q4.risk
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

ALPHA = 0.95


def daily_costs(df, q):
    """逐日结算，返回按日期升序的日成本序列。"""
    out = []
    for d, g in df.groupby("date", sort=True):
        r = settle_day(q[g.index], g.load_actual.values, g.price_da.values,
                       g.price_rt.values, g.contract_q.values, g.contract_p.values)
        out.append((d, r["sums"]["total"]))
    return out


def metrics(costs):
    """日成本的风险指标。costs 为一维数组。"""
    c = np.asarray(costs, float)
    n = len(c)
    k = max(1, int(np.ceil((1 - ALPHA) * n)))
    worst = np.sort(c)[-k:]
    return {
        "日数": n,
        "总成本": round(c.sum(), 2),
        "日均": round(c.mean(), 2),
        "标准差": round(c.std(ddof=1), 2),
        "VaR95": round(float(np.quantile(c, ALPHA)), 2),
        "CVaR95": round(float(worst.mean()), 2),
        "最大单日": round(float(c.max()), 2),
        "最差日": round(float(c.max() - c.mean()), 2),
    }


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = io.load_attachments()
    a2, a4, a5 = data["att2"], data["att4"], data["att5"]

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q2 = q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
    plans = pd.read_csv(os.path.join(OUT, "q4_plans.csv"), encoding="utf-8-sig")

    q4r = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")[["date", "hour", "q_final"]]
    df = (q2.merge(plans, on=["date", "hour"], how="inner")
            .merge(q4r, on=["date", "hour"], how="inner")
            .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"], how="inner")
            .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"], how="inner")
            .merge(a5, on=["date", "hour"], how="inner")
            .sort_values(["date", "hour"]).reset_index(drop=True))

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)

    schemes = {
        "baseline": ("按合约量申报", qc),
        "det": ("确定性申报（问题三）", df["q_det"].to_numpy(float)),
        "R1": ("风险申报 lambda=0", df["q_R1"].to_numpy(float)),
        "F": ("F 交付规则（theta=1.5）", df["q_final"].to_numpy(float)),
        "R2": ("系统基线档 R2（lambda=0.5）", df["q_R2"].to_numpy(float)),
        "R3": ("风险申报 lambda=2.0", df["q_R3"].to_numpy(float)),
        "up12": ("恒报 1.2·L_hat（零模型）", 1.2 * Lh),
        "up12_qc": ("恒报 max(1.2·L_hat, Qc)", np.maximum(1.2 * Lh, qc)),
        "flat": ("恒报 L_hat", Lh),
    }

    rows = []
    daily = {}
    for key, (name, qv) in schemes.items():
        dc = daily_costs(df, qv)
        daily[key] = dict(dc)
        m = metrics([v for _, v in dc])
        m = {"key": key, "方案": name, **m}
        rows.append(m)

    out = pd.DataFrame(rows)
    base_mean = float(out.loc[out.key == "baseline", "日均"].iloc[0])
    out["日均相对基准_pct"] = ((out["日均"] - base_mean) / base_mean * 100).round(3)
    cols = ["key", "方案", "总成本", "相对基准_总", "日均", "日均相对基准_pct",
            "标准差", "VaR95", "CVaR95", "最大单日", "最差日"]
    out["相对基准_总"] = (out["总成本"].map(
        lambda v: round((v - out.loc[out.key == "baseline", "总成本"].iloc[0])
                        / out.loc[out.key == "baseline", "总成本"].iloc[0] * 100, 3)))
    out = out[cols]
    out.to_csv(os.path.join(OUT, "q4_risk_metrics.csv"), index=False, encoding="utf-8-sig")

    # 逐日成本明细也存一份，便于论文与核验
    det = pd.DataFrame(daily)
    det.index.name = "date"
    det.reset_index().to_csv(os.path.join(OUT, "q4_daily_cost.csv"),
                             index=False, encoding="utf-8-sig")

    print("=" * 88)
    print(f"问题四 日成本风险指标（{len(det)} 天，CVaR95 取最差 "
          f"{max(1, int(np.ceil(0.05 * len(det))))} 天均值）")
    print("=" * 88)
    show = out.copy()
    for c in ("总成本", "日均", "标准差", "VaR95", "CVaR95", "最大单日"):
        show[c] = show[c].map(lambda v: f"{v:,.0f}")
    print(show.to_string(index=False))
    print()
    r2 = out[out.key == "R2"].iloc[0]
    r1 = out[out.key == "R1"].iloc[0]
    up = out[out.key == "up12_qc"].iloc[0]
    print(f"R2 日成本标准差 {r2['标准差']:,.0f} 元，R1 为 {r1['标准差']:,.0f} 元"
          f"（R2 相对 R1 {'更低' if r2['标准差'] < r1['标准差'] else '更高'}）")
    print(f"R2 的 CVaR95 {r2['CVaR95']:,.0f} 元，零模型 max(1.2L,Qc) 为 {up['CVaR95']:,.0f} 元")
    print(f"\n产出：{os.path.join(OUT, 'q4_risk_metrics.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
