# -*- coding: utf-8 -*-
"""问题四：基于因果可得信息的切换规则实验（论文表 18）。

回答一个具体问题：**若依据"截至 D−7 可得的信息"逐日决定多报/少报，
能否胜过"无条件恒报上带"？** 这是"零模型优势是否可通过条件化复现"的直接检验。

五条规则：
  R-sign      : 28 日滚动均值的符号 → 正走 max(1.2L_hat,Qc)，负走 0.8L_hat
  R-dz(theta)     : 同上，但 |z| < theta 时退回风险申报 R2（z = mu / (sigma/sqrt28)），theta  in  {0.5,1.0,1.5}

注：theta = 0 时必须与 R-sign 完全等价。早期（历史不足 5 天）mu 无法估计时，
两者一律按"少报"处理，不退回 R2——否则两条规则会在冷启动期分岔（这是一处已修的缺陷）。

对照：固定上带 max(1.2L_hat,Qc)。

输出 `outputs/q4_switch.csv`。

用法：<venv>/python.exe -m src.q4.switch_rules
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common import io
from src.common.settle import settle_day

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
LOOKBACK_DAYS = 7      # 价格披露 T+6 → 只能用 <= D−7 的实际价差
WIN = 28               # 滚动均值窗口


def build(df, hist=None):
    """把 28 日滚动均值（严格因果）与 z 值挂到每个日期上。

    hist：可选的"完整合法历史"（全部已知日期的日均价差 Series）。若不提供，则只用
    df 内的日期——这会让评估期开头的日子因"没有历史"而无法判断，白丢一段本可使用的
    合法信息（1–3 月的价差在 4 月决策时早已披露）。
    """
    s_by = df.groupby("date")["S_actual"].mean()
    if hist is not None:
        s_by = pd.concat([hist, s_by]).groupby(level=0).last()
    dates = sorted(s_by.index)
    mu, sd = {}, {}
    for D in dates:
        past = [x for x in dates
                if x < D and (pd.Timestamp(D) - pd.Timestamp(x)).days >= LOOKBACK_DAYS]
        if len(past) < 5:
            mu[D], sd[D] = 0.0, np.nan      # 冷启动：无法判断
        else:
            v = s_by[past[-WIN:]].to_numpy(float)
            mu[D], sd[D] = float(v.mean()), float(v.std(ddof=1) + 1e-12)
    df = df.copy()
    df["mu"] = df["date"].map(mu)
    df["sd"] = df["date"].map(sd)
    return df


def plan_sign(df, up, dn):
    """纯符号规则；冷启动（sd 为 NaN）按"少报"处理。"""
    return np.where(df["mu"] > 0, up, dn)


def plan_deadzone(df, up, dn, q_risk, theta):
    """带死区的规则；|z|<theta 时退回风险申报。theta=0 时与符号规则严格等价。"""
    q = plan_sign(df, up, dn).astype(float)
    if theta > 0:
        z = df["mu"] / (df["sd"] / np.sqrt(WIN))
        inside = (np.abs(z) < theta).to_numpy() & np.isfinite(df["sd"].to_numpy())
        q = np.where(inside, q_risk, q)
    return q


def settle_all(df, q):
    tot = 0.0
    for _, idx in df.groupby("date").indices.items():
        tot += settle_day(q[idx], df["load_actual"].to_numpy(float)[idx],
                          df["price_da"].to_numpy(float)[idx],
                          df["price_rt"].to_numpy(float)[idx],
                          df["contract_q"].to_numpy(float)[idx],
                          df["contract_p"].to_numpy(float)[idx])["sums"]["total"]
    return tot


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = io.load_attachments()
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")

    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(data["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(data["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(data["att5"], on=["date", "hour"])
          .merge(q4[["date", "hour", "q_risk"]], on=["date", "hour"]))
    df["S_actual"] = df["price_rt"] - df["price_da"]
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    # 完整合法历史：附件4 的价格在 T+6 披露，故 D 日可用的最晚价差是 D-7。
    a4 = data["att4"].copy()
    a4["S"] = a4["price_rt"] - a4["price_da"]
    hist = a4.groupby("date")["S"].mean()
    df = build(df, hist=hist)

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)
    dn = 0.8 * Lh
    q_risk = df["q_risk"].to_numpy(float)

    base = settle_all(df, qc)
    rows = []
    for name, q in [("按合约量申报", qc),
                    ("固定上带 max(1.2L_hat,Qc)（对照）", up),
                    ("滚动 28 日均值符号", plan_sign(df, up, dn)),
                    ("同 + 死区 theta=0.5", plan_deadzone(df, up, dn, q_risk, 0.5)),
                    ("同 + 死区 theta=1.0", plan_deadzone(df, up, dn, q_risk, 1.0)),
                    ("同 + 死区 theta=1.5", plan_deadzone(df, up, dn, q_risk, 1.5))]:
        c = settle_all(df, np.asarray(q, float))
        rows.append({"规则": name, "总成本": round(c, 2),
                     "相对基准_pct": round((c - base) / base * 100, 3)})
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q4_switch.csv"), index=False, encoding="utf-8-sig")

    print("=" * 74)
    print("问题四：因果可得信息下的切换规则（153 天，事后结算）")
    print("=" * 74)
    print(out.to_string(index=False))
    best = out[out["规则"].str.contains("死区") | out["规则"].str.contains("符号")]["相对基准_pct"].min()   # 负值越小（越负）越省，故取 min
    fixed = out[out["规则"].str.contains("固定上带")]["相对基准_pct"].iloc[0]
    print(f"\n  最佳切换规则 {best:+.3f}% vs 固定上带 {fixed:+.3f}%"
          f" → 差 {fixed - best:.3f} 个百分点")
    print(f"  产出：{os.path.join(OUT, 'q4_switch.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
