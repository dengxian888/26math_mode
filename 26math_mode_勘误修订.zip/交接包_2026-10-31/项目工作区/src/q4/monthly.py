# -*- coding: utf-8 -*-
"""问题四：各方案的逐月成本对比（检验"零模型的优势是否依赖特定市场状态"）。

背景：论文称零模型"属事后的方向押注、不具可迁移性"。若只有符号统计支撑，
这仍是断言。逐月成本是直接证据：若零模型的优势集中在价差均值为正且幅度大的月份、
而在均值为负的月份转亏，即可证明其收益来源依赖市场状态。

本脚本读取 `q4_daily_cost.csv`（由 src/q4/risk.py 产出），按月汇总并输出
`outputs/q4_monthly.csv`。

用法：<venv>/python.exe -m src.q4.monthly
"""
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
COLS = ["baseline", "det", "R1", "R2", "R3", "up12", "up12_qc"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    d = pd.read_csv(os.path.join(OUT, "q4_daily_cost.csv"), encoding="utf-8-sig")
    d["month"] = pd.to_datetime(d["date"]).dt.strftime("%Y-%m")

    g = d.groupby("month")[COLS].sum()
    rel = g.sub(g["baseline"], axis=0).div(g["baseline"], axis=0) * 100

    print("=" * 76)
    print("问题四：逐月成本（相对按合约量申报，%）")
    print("=" * 76)
    show = rel.copy()
    for c in show.columns:
        show[c] = show[c].map(lambda v: f"{v:+.2f}")
    print(show.to_string())
    print()
    print("R2 与零模型 max(1.2L_hat,Qc) 的逐月差额（正 = 零模型更省）")
    diff = g["R2"] - g["up12_qc"]
    for m, v in diff.items():
        print(f"  {m}: {v:>12,.0f}")
    print(f"  合计 : {diff.sum():>12,.0f}")
    print()
    pos = [m for m in diff.index if m != diff.index[0]]
    print(f"  除去 {diff.index[0]} 后，零模型的净差额为 {diff[pos].sum():,.0f} 元"
          f"（{'亏' if diff[pos].sum() > 0 else '赚'}）")

    out = g.copy()
    out.columns = [c + "_成本" for c in COLS]
    for c in COLS:
        out[c + "_相对基准_pct"] = rel[c].round(3)
    out["R2减零模型_元"] = diff.round(0)
    out.to_csv(os.path.join(OUT, "q4_monthly.csv"), encoding="utf-8-sig")
    print(f"\n产出：{os.path.join(OUT, 'q4_monthly.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
