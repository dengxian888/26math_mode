# -*- coding: utf-8 -*-
"""问题四：预测误差敏感性与异常情景敏感性（回应赛题"考察系统对预测误差、
参数变化及异常情景的敏感性，评价其稳定性与鲁棒性"）。

参数变化（lambda 0→8）已由主流程给出，本模块补另外两类：

  A. **预测误差敏感性**：把残差池整体放大 k 倍（k = 1.0 / 1.5 / 2.0 / 3.0），
     模拟"预测变差"，但结算仍用真实值。观察决策方案的成本如何退化。

  B. **异常情景敏感性**：在原情景池上叠加三类压力，
        B1 价差预期翻转（把 S_hat 整体平移，使期望价差转负）
        B2 极端尖峰（加入若干巨额负价差残差情景）
        B3 情景池减半（只用合法池中较近的一半，模拟样本稀薄）

  每个设置下同时给出"风险申报 R2"与"零模型 max(1.2L_hat,Qc)"的表现，
  后者不依赖情景，可作为对照——若异常情景下 R2 相对零模型的差距缩小甚至反超，
  即说明风险建模在坏情形下确实更抗打。

输出 `outputs/q4_sensitivity.csv`。

用法：<venv>/python.exe -m src.q4.sensitivity
"""
import os
import sys

import numpy as np
import pandas as pd

from src.common.settle import settle_day
from src.q4.solve import (N_SCEN, POOL_LAG, SEED, cvar, optimal_q, prepare)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")
LAM_R2 = 0.5


def simulate(df, dates, lam, seed, scale=1.0, shift_S=0.0,
             stress_n=0, stress_value=0.0, pool_frac=1.0):
    """通用滚动模拟。返回逐日申报量列表（每个元素是当日 24 个 q）。"""
    rng = np.random.default_rng(seed)
    plans = []
    for D in dates:
        pos = dates.index(D)
        today = df[df["date"] == D]
        avail = dates[:max(0, pos - POOL_LAG + 1)]
        pool = df[df["date"].isin(avail)]

        if len(pool) == 0:
            plans.append([float(v) for v in today["q_det"].to_numpy()])
            continue

        if pool_frac < 1.0:
            keep = max(24, int(len(pool) * pool_frac))
            pool = pool.tail(keep)          # 只用较近的一段

        # 与 src/q4/solve.py 一致：按日成组抽样（保留日内相关与分时段异方差）
        e_mat = pool.pivot_table(index="date", columns="hour", values="e_load")
        f_mat = pool.pivot_table(index="date", columns="hour", values="f_spread")
        both = e_mat.notna().all(axis=1) & f_mat.notna().all(axis=1)
        e_mat, f_mat = e_mat[both], f_mat[both]
        if len(e_mat) == 0:
            plans.append([float(v) for v in today["q_det"].to_numpy()])
            continue
        pick = rng.choice(len(e_mat), size=N_SCEN, replace=True)
        e_sel = e_mat.to_numpy(float)[pick] * scale      # [N_SCEN, 24]
        f_sel = f_mat.to_numpy(float)[pick] * scale

        qs = []
        for _, r in today.iterrows():
            h = int(r["hour"])
            e_pool, f_pool = e_sel[:, h], f_sel[:, h]
            if stress_n:
                e_pool = np.concatenate([e_pool, np.full(stress_n, float(np.min(e_mat.to_numpy(float))))])
                f_pool = np.concatenate([f_pool, np.full(stress_n, stress_value)])
            q, _ = optimal_q(r["L_hat"], r["S_hat"] + shift_S, r["pred_da"],
                             r["contract_q"], r["contract_p"], e_pool, f_pool, lam)
            qs.append(q)
        plans.append(qs)
    return plans


def settle_plans(df, dates, plans):
    """事后结算，返回逐日总成本数组。"""
    costs = []
    for D, q in zip(dates, plans):
        g = df[df["date"] == D]
        c = settle_day(np.asarray(q, float), g["load_actual"].to_numpy(float),
                       g["price_da"].to_numpy(float), g["price_rt"].to_numpy(float),
                       g["contract_q"].to_numpy(float), g["contract_p"].to_numpy(float))
        costs.append(c["sums"]["total"])
    return np.asarray(costs, float)


def zero_plan(df, dates):
    """零模型：恒报 max(1.2L_hat, Qc)。不依赖情景，作为对照。"""
    out = []
    for D in dates:
        g = df[df["date"] == D]
        q = np.maximum(1.2 * g["L_hat"].to_numpy(float), g["contract_q"].to_numpy(float))
        out.append(q)
    return out


def summarize(name, cost, base):
    k = max(1, int(np.ceil(0.05 * len(cost))))
    return {
        "设置": name,
        "总成本": round(float(cost.sum()), 2),
        "相对基准_pct": round(float((cost.sum() - base) / base * 100), 3),
        "日成本标准差": round(float(cost.std(ddof=1)), 2),
        "CVaR95": round(float(np.sort(cost)[-k:].mean()), 2),
        "最大单日": round(float(cost.max()), 2),
    }


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    df = prepare()
    dates = sorted(df["date"].unique())
    base_cost = float(settle_plans(df, dates, [[float(v) for v in df[df["date"] == D]["contract_q"]]
                                               for D in dates]).sum())

    rows = []
    # 参照：基准与零模型
    rows.append(summarize("（参照）按合约量申报", settle_plans(df, dates,
                [[float(v) for v in df[df["date"] == D]["contract_q"]] for D in dates]), base_cost))
    zc = settle_plans(df, dates, zero_plan(df, dates))
    rows.append(summarize("（参照）零模型 max(1.2Lhat,Qc)", zc, base_cost))

    # ---------- A. 预测误差敏感性 ----------
    print("模拟预测误差放大...")
    for k in (1.0, 1.5, 2.0, 3.0):
        plans = simulate(df, dates, LAM_R2, SEED, scale=k)
        rows.append(summarize(f"A 预测误差 ×{k:.1f}", settle_plans(df, dates, plans), base_cost))
        print(f"  残差 ×{k:.1f} 完成")

    # ---------- B. 异常情景敏感性 ----------
    print("模拟异常情景...")
    # B1 价差预期翻转：整体平移使期望价差为负
    S_mean = float(df["S_hat"].mean())
    shift = -2.0 * S_mean
    plans = simulate(df, dates, LAM_R2, SEED, shift_S=shift)
    rows.append(summarize(f"B1 价差预期翻转（平移 {shift:+.0f}）",
                          settle_plans(df, dates, plans), base_cost))
    print("  B1 完成")

    # B2 极端尖峰：叠加 60 个 -250 元/MWh 的价差残差情景
    plans = simulate(df, dates, LAM_R2, SEED, stress_n=60, stress_value=-250.0)
    rows.append(summarize("B2 极端尖峰（60×−250 元/MWh）",
                          settle_plans(df, dates, plans), base_cost))
    print("  B2 完成")

    # B3 情景池减半
    plans = simulate(df, dates, LAM_R2, SEED, pool_frac=0.5)
    rows.append(summarize("B3 情景池减半", settle_plans(df, dates, plans), base_cost))
    print("  B3 完成")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q4_sensitivity.csv"), index=False, encoding="utf-8-sig")

    print()
    print("=" * 92)
    print("问题四 敏感性分析（153 天，事后结算；基准 = 按合约量申报）")
    print("=" * 92)
    show = out.copy()
    for c in ("总成本", "日成本标准差", "CVaR95", "最大单日"):
        show[c] = show[c].map(lambda v: f"{v:,.0f}")
    show["相对基准_pct"] = show["相对基准_pct"].map(lambda v: f"{v:+.3f}%")
    print(show.to_string(index=False))
    print(f"\n产出：{os.path.join(OUT, 'q4_sensitivity.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
