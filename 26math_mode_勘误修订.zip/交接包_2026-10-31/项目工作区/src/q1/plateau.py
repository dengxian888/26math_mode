# -*- coding: utf-8 -*-
"""问题一：成本-申报量关系的「平台区」示意图（论文图 1）。

这张图原先是一张没有生成代码的临时图，图例标签还出现了缺字方框。
本脚本把它补成可复现的正式产物，并只用确定会渲染的字符。

图意：
  (a) S > 0：成本在 q < (1+lambda0)L 时以 −S 递减，超过 (1+lambda0)L 后斜率恒为 0
      —— 于是最优解不是一点，而是一条从 (1+lambda0)L 开始的射线。
  (b) S < 0：对称，成本在 q <= (1−lambda0)L 上恒为常数，之后以 −S > 0 递增。

用法：<venv>/python.exe -m src.q1.plateau
"""
import os
import sys

import numpy as np

from src.common.plotting import TOL, apply_style, new_fig, save_fig

LAM0 = 0.20


def hour_cost(q, L, S, pda, pc, qc):
    """单时段总成本（与 settle.py 同一定义，此处独立写一遍以便绘图）。"""
    q = np.asarray(q, float)
    cost = qc * pc + (q - qc) * pda + (L - q) * (pda + S)
    up = np.maximum(0.0, q - (1 + LAM0) * L)
    dn = np.maximum(0.0, (1 - LAM0) * L - q)
    R = np.where(S > 0, S * up, np.where(S < 0, (-S) * dn, 0.0))
    return cost + R


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    apply_style(font_size=10.5)

    fig, axes = new_fig(1, 2, figsize=(9.2, 3.7))

    cases = [
        dict(ax=axes[0], L=38.0, S=60.0, pda=380.0, pc=420.0, qc=34.0,
             title="(a) 价差为正", band=(1 + LAM0) * 38.0, side="up"),
        dict(ax=axes[1], L=26.0, S=-55.0, pda=380.0, pc=420.0, qc=31.0,
             title="(b) 价差为负", band=(1 - LAM0) * 26.0, side="down"),
    ]

    for c in cases:
        ax = c["ax"]
        L, S, pda, pc, qc = c["L"], c["S"], c["pda"], c["pc"], c["qc"]
        lo, hi = 0.0, (1 + LAM0) * L * 1.65
        q = np.linspace(lo, hi, 500)
        cost = hour_cost(q, L, S, pda, pc, qc)

        ax.plot(q, cost, color=TOL[0], lw=2.0, label="时段总成本")
        # 允许偏差带的边界（只画与平台区相关的那个）
        ax.axvline(c["band"], color=TOL[1], ls="--", lw=1.3,
                   label="允许偏差带边界")
        # 实际用电量
        ax.axvline(L, color="0.62", ls=":", lw=1.3, label="实际用电量 L")

        # 标出平台区
        if c["side"] == "up":
            ax.axvspan(c["band"], hi, color=TOL[0], alpha=0.07)
            ax.annotate("斜率为 0\n（平台区）", xy=(hi * 0.78, cost.min()),
                        xytext=(hi * 0.66, cost.min() + 0.28 * (cost.max() - cost.min())),
                        fontsize=9, color="0.25",
                        arrowprops=dict(arrowstyle="->", lw=0.9, color="0.45"))
        else:
            ax.axvspan(lo, c["band"], color=TOL[0], alpha=0.07)
            ax.annotate("斜率为 0\n（平台区）", xy=(c["band"] * 0.45, cost.min()),
                        xytext=(c["band"] * 0.12, cost.min() + 0.22 * (cost.max() - cost.min())),
                        fontsize=9, color="0.25",
                        arrowprops=dict(arrowstyle="->", lw=0.9, color="0.45"))

        ax.set_title(c["title"], fontsize=11.5)
        ax.set_xlabel("申报量（MWh）")
        ax.set_ylabel("时段总成本（元）")
        ax.set_xlim(lo, hi)
        ax.legend(fontsize=8.5, loc="upper right" if c["side"] == "up" else "upper left",
                  frameon=False)

    fig.tight_layout()
    path = save_fig(fig, "q1_平台区示意图")
    print(f"产出：{path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
