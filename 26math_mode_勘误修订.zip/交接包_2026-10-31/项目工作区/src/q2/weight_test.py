# -*- coding: utf-8 -*-
"""问题二：针对"节假日系统性高估"的四组样本加权尝试（论文表 10，负结果）。

背景：误差诊断显示节假日平均高估 2.45 MWh。自然的补救是给节假日样本加权。
本文试了四组权重，**全部使总体 MAE 恶化**——这一负结果此前没有对应脚本，
本模块把它补成可复现产物。

做法：复用与 `src.q2.solve` 完全相同的设置（逐周重估、训练截止 W−5、同一模型与超参、
方案 C 的 41 维特征），只额外给 `fit` 传 `sample_weight`。

输出 `outputs/q2_weight.csv`。

用法：<venv>/python.exe -m src.q2.weight_test
"""
import os
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

from src.q2.features import FEAT_C, build_panel
from src.q2.solve import EVAL_END, EVAL_START, REFIT_DAYS, SEED, TRAIN_LAG

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "outputs")

SCHEMES = [
    ("不加权（本文采用）", 1.0, 1.0),
    ("节假日权重 x3", 3.0, 1.0),
    ("节假日权重 x5", 5.0, 1.0),
    ("节假日 x3 + 周末 x1.5", 3.0, 1.5),
    ("节假日 x5 + 周末 x2", 5.0, 2.0),
]


def walk_forward_weighted(panel, feats, w_hol=1.0, w_wknd=1.0):
    panel = panel.reset_index(drop=True).copy()
    # build_panel 不含 day_type 文本列，从附件2 取日期级映射后并入
    a2 = pd.read_csv(os.path.join(ROOT, 'data', 'interim', 'att2_用电量.csv'),
                     encoding='utf-8-sig')[['date', 'day_type']].drop_duplicates('date')
    panel = panel.merge(a2, on='date', how='left')
    dates = sorted(panel["date"].unique())
    eval_dates = [d for d in dates if EVAL_START <= d <= EVAL_END]
    is_hol_all = (panel["day_type"] == "法定节假日").to_numpy()
    is_wknd_all = (panel["day_type"] == "普通周末").to_numpy()

    recs = []
    i = 0
    while i < len(eval_dates):
        week = eval_dates[i:i + REFIT_DAYS]
        W = week[0]
        pos = dates.index(W)
        train_end = dates[max(0, pos - TRAIN_LAG)]
        tr_mask = ((panel["date"] <= train_end)
                   & panel["load_actual"].notna()).to_numpy()
        te_mask = panel["date"].isin(week).to_numpy()
        tr, te = panel[tr_mask], panel[te_mask]

        w = np.ones(len(tr), float)
        if w_hol != 1.0:
            w = np.where(is_hol_all[tr_mask], w * w_hol, w)
        if w_wknd != 1.0:
            w = np.where(is_wknd_all[tr_mask], w * w_wknd, w)

        model = HistGradientBoostingRegressor(
            max_iter=300, learning_rate=0.06, max_leaf_nodes=31,
            min_samples_leaf=20, l2_regularization=1.0, random_state=SEED)
        model.fit(tr[feats], tr["load_actual"], sample_weight=w)
        pred = np.clip(model.predict(te[feats]), 0, None)

        frame = te[["date", "hour", "day_type"]].copy()
        frame["yhat"] = pred
        frame["y"] = te["load_actual"].to_numpy(float)
        recs.append(frame)
        i += REFIT_DAYS
    return pd.concat(recs, ignore_index=True)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    panel = build_panel()
    rows = []
    for name, wh, ww in SCHEMES:
        p = walk_forward_weighted(panel, FEAT_C, w_hol=wh, w_wknd=ww)
        err = (p["y"] - p["yhat"]).to_numpy(float)
        hol = (p["day_type"] == "法定节假日").to_numpy()
        rows.append({"加权方案": name,
                     "总体 MAE": round(float(np.abs(err).mean()), 4),
                     "节假日 MAE": round(float(np.abs(err[hol]).mean()), 4)})
        print(f"  {name:<24} 总体 {rows[-1]['总体 MAE']:.4f} | "
              f"节假日 {rows[-1]['节假日 MAE']:.4f}")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q2_weight.csv"), index=False, encoding="utf-8-sig")
    print("\n" + out.to_string(index=False))
    base = out.iloc[0]["总体 MAE"]
    n_better = int((out.iloc[1:]["总体 MAE"] < base).sum())
    msg = "（复现“加权无效”的负结果）" if n_better == 0 else "（与论文表述不符，需核对！）"
    print(f"\n  加权后总体 MAE 改善的方案数: {n_better} / {len(out) - 1} {msg}")
    print(f"  产出：{os.path.join(OUT, 'q2_weight.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
