import pymupdf, re, os, pandas as pd
d=pymupdf.open('paper/论文.pdf'); full='\n'.join(d[i].get_text() for i in range(d.page_count))
s=open('paper/论文.tex',encoding='utf-8').read()
apx=[k+1 for k in range(d.page_count) if '附录A' in d[k].get_text()][0]

print('='*64); print('最终自检'); print('='*64)
print('【结构】')
print(f'  页数 {d.page_count} | 正文 {apx-1} 页（≤30）| {os.path.getsize("paper/论文.pdf")/1024/1024:.2f} MB')
t1=d[0].get_text()
print(f'  摘要独占第1页: {"关键词" in t1 and "问题重述" not in t1}')
labels=set(re.findall(r'\\label\{([^}]*)\}', s))
refs=set()
for m in re.finditer(r'\\(?:c|C)ref\{([^}]*)\}', s): refs|={x.strip() for x in m.group(1).split(',')}
print(f'  无定义引用: {len(refs-labels)} | 重复label: {len([k for k in labels if s.count("\\label{%s}"%k)>1])}')
print(f'  ??: {full.count("??")} | 乱码U+FFFF: {full.count(chr(0xFFFF))} | U+FFFD: {full.count(chr(0xFFFD))}')
print(f'  替换符可见: {full.count(chr(0xFFFD))} | extbf: {len(re.findall(r"(?<![a-z])extbf", full))}')

print('【附录】')
blocks=re.findall(r'\\noindent\\textbf\{文件\}：\\texttt\{([^}]*)\}', s)
print(f'  文件块 {len(blocks)} 个 | 重复 {len(blocks)-len(set(blocks))} 个')
disk=[]
for dd in ('src','tests'):
    for r,_,fs in os.walk(dd):
        for f in fs:
            if f.endswith('.py'): disk.append(os.path.join(r,f).replace('\\','/'))
disk+=['run_all.py','build_data.py']
print(f'  磁盘源码 {len(disk)} 个 | 全覆盖: {set(disk)<=set(blocks)}')

print('【数字】')
for k in ['1,432,352.61','59,262,082.68','58,951,240.90','58,141,930.82']:
    print(f'  {k}: {"OK" if k in full else "缺失"}')

print('【陈旧值残留】')
STALE=['58,812,166','67.0 万','0.897','11.2 万','468,843','50,761','0.36%','69.5 万',
       '0.65 个百分点','0.027%','−0.413','−0.440','0.79 个','49.17','9.04，','几乎不变',
       '差距约 29','5 条切换','125 天','232 天','仅有的三条','${2\\to2}$']
hit=[x for x in STALE if x in full]
print('  ', hit if hit else '全部为 0 ✓')
