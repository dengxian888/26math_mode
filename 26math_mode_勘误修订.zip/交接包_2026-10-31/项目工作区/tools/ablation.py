# -*- coding: utf-8 -*-
"""消融：为什么"优化器"输给"恒报上带"?

背景：表 17 里 R1（lambda=0，纯期望成本最小）为 -0.249%，而一行代码的
`max(1.2 L_hat, Qc)` 为 -1.548%，差 1.30 个百分点。若 R1 真的最小化 E[C]，
它至少应当复制"永远贴上带"----因为由式(3)，越过带沿后成本平坦、多报无成本。

本脚本用**同一情景池、同一 D-7 截止、同一黄金分割**，把优化器的输入逐项改造，
看成本如何移动，从而定位差距来源：

    R1            基线（论文主结果）
    R1-deMean     情景残差减去样本均值（中心留在 S_hat）----检验"均值修正"假说
    R1-scale0.5   残差缩放 0.5 倍（噪声减小）----检验"噪声导致对冲"假说
    R1-scale0.2   残差缩放 0.2 倍
    R1-noResid    残差置零（只按点预测决策，等价于确定性申报）
    R1-up         直接恒报上带（对照上界）
    R1-oracle     用真实 S 做决策（完全信息对照）

输出 `outputs/ablation.csv`。

用法：<venv>/python.exe -m tools.ablation
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
def _base_cost():
    b = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig")
    return float(b.set_index("key").loc["baseline", "总成本"])


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day
    from src.q4.solve import prepare, optimal_q, POOL_LAG, SEED, N_SCEN

    df = prepare()
    dates = sorted(df["date"].unique())
    base_cost = _base_cost()

    def settle_all(q):
        L = df["load_actual"].to_numpy(float)
        pda = df["price_da"].to_numpy(float)
        prt = df["price_rt"].to_numpy(float)
        qc = df["contract_q"].to_numpy(float)
        pc = df["contract_p"].to_numpy(float)
        return sum(settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                   for i in df.groupby("date").indices.values())

    def run(mode):
        rng = np.random.default_rng(SEED)
        qs_all = []
        for D in dates:
            pos = dates.index(D)
            today = df[df["date"] == D]
            avail = dates[:max(0, pos - POOL_LAG + 1)]
            pool = df[df["date"].isin(avail)]
            if len(pool) == 0:
                # 池空时按**当前模式**给申报量，而不是一律退回确定性申报
                if mode == "up":
                    qs_all.extend(np.maximum(1.2 * today["L_hat"].to_numpy(float),
                                             today["contract_q"].to_numpy(float)))
                elif mode == "oracle":
                    # 必须用**真实负荷**，否则与表15 的"实L+实S"不是同一对照
                    Sv = today["S_actual"].to_numpy(float)
                    La = today["load_actual"].to_numpy(float)
                    Qc = today["contract_q"].to_numpy(float)
                    qs_all.extend(np.where(Sv > 0, np.maximum(Qc, 1.2 * La),
                                           np.maximum(0, np.minimum(Qc, 0.8 * La))))
                else:
                    qs_all.extend(today["q_det"].to_numpy(float))
                continue
            e_mat = pool.pivot_table(index="date", columns="hour", values="e_load")
            f_mat = pool.pivot_table(index="date", columns="hour", values="f_spread")
            both = e_mat.index.intersection(f_mat.index)
            e_mat, f_mat = e_mat.loc[both], f_mat.loc[both]
            if len(e_mat) == 0:
                if mode == "up":
                    qs_all.extend(np.maximum(1.2 * today["L_hat"].to_numpy(float),
                                             today["contract_q"].to_numpy(float)))
                elif mode == "oracle":
                    # 必须用**真实负荷**，否则与表15 的"实L+实S"不是同一对照
                    Sv = today["S_actual"].to_numpy(float)
                    La = today["load_actual"].to_numpy(float)
                    Qc = today["contract_q"].to_numpy(float)
                    qs_all.extend(np.where(Sv > 0, np.maximum(Qc, 1.2 * La),
                                           np.maximum(0, np.minimum(Qc, 0.8 * La))))
                else:
                    qs_all.extend(today["q_det"].to_numpy(float))
                continue
            pick = rng.choice(len(e_mat), size=N_SCEN, replace=True)
            e_sel = e_mat.to_numpy(float)[pick].copy()
            f_sel = f_mat.to_numpy(float)[pick].copy()
            if mode == "deMean":
                # 按**分时段**去均值（axis=0），而不是全池标量均值；
                # 后者会把 24 个时段的共同水平也一并去掉，与"中心留在 S_hat"的意图不符。
                f_sel -= f_mat.to_numpy(float).mean(axis=0)
            elif mode.startswith("scale"):
                k = float(mode.replace("scale", ""))
                e_sel *= k
                f_sel *= k
            elif mode == "noResid":
                e_sel *= 0.0
                f_sel *= 0.0
            for _, r in today.iterrows():
                h = int(r["hour"])
                if mode == "up":
                    qs_all.append(max(1.2 * r["L_hat"], r["contract_q"]))
                    continue
                if mode == "oracle":
                    # 真实负荷 + 真实价差：零残差下闭式解即最优，
                    # 直接用闭式解可避免黄金分割在平台上停到任意点（对比表15 的 实L+实S）。
                    L_t, S_t, Qc_t = float(r["load_actual"]), float(r["S_actual"]), float(r["contract_q"])
                    if S_t > 0:
                        qs_all.append(max(Qc_t, 1.2 * L_t))
                    else:
                        qs_all.append(max(0.0, min(Qc_t, 0.8 * L_t)))
                    continue
                Sv = float(r["S_hat"])
                q, _ = optimal_q(r["L_hat"], Sv, r["pred_da"], r["contract_q"],
                                 r["contract_p"], e_sel[:, h], f_sel[:, h], 0.0)
                qs_all.append(q)
        return np.asarray(qs_all, float)

    rows = []
    for mode, name in [("base", "R1 基线"), ("deMean", "R1-残差去均值"),
                       ("scale0.5", "R1-残差 x0.5"), ("scale0.2", "R1-残差 x0.2"),
                       ("noResid", "R1-残差置零"), ("up", "恒报上带（对照）"),
                       ("oracle", "真实负荷 + 真实价差（完全信息，对照）")]:
        q = run(mode)
        c = settle_all(q)
        rows.append({"方案": name, "平均申报(MWh)": round(float(q.mean()), 2),
                     "总成本": round(c, 2),
                     "相对基准_pct": round((c - base_cost) / base_cost * 100, 3)})
        print(f"  {name} 完成", flush=True)

    # ---- 自校验：控制项必须与表 17 的已知值吻合，否则说明读错了数据 ----
    chk = {r["方案"]: r["总成本"] for r in rows}
    _b = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    want = {"恒报上带（对照）": float(_b.loc["up12_qc", "总成本"]),
            "R1 基线": float(_b.loc["R1", "总成本"]),
            # 完全信息对照必须等于表17 的 oracle（实L+实S），否则说明用错了负荷列
            "真实负荷 + 真实价差（完全信息，对照）": float(_b.loc["oracle", "总成本"])}
    if "oracle" not in _b.index:
        raise SystemExit("[自校验失败] q4_benchmark.csv 缺 oracle 行，无法核对完全信息对照")
    bad = [(k, chk.get(k), v) for k, v in want.items()
           if chk.get(k) is None or abs(chk[k] - v) > 1.0]
    if bad:
        raise SystemExit(f"[自校验失败] 控制项与表 17 不符：{bad}\n"
                         f"请检查 OUT 是否被环境变量重定向到了错误目录。")
    print("\n  [自校验通过] 恒报上带与 R1 基线与表 17 完全吻合")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "ablation.csv"), index=False, encoding="utf-8-sig")
    print("\n" + "=" * 78)
    print(out.to_string(index=False))
    print("=" * 78)
    print(f"\n  产出：{os.path.join(OUT, 'ablation.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
