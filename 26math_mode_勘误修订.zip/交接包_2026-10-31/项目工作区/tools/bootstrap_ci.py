# -*- coding: utf-8 -*-
"""按日块 bootstrap：给关键对比配上 95% 置信区间。

全文此前 0 处显著性检验，"与日成本噪声同量级""统计上不可判别"都只是断言。
本脚本对各规则的**逐日总成本**做配对块 bootstrap（块长 7 天，保留周内相关），
给出"相对按合约量申报"的日均改善及其 95% CI，从而把断言变成数字。

输出 `outputs/bootstrap_ci.csv`。

用法：<venv>/python.exe -m tools.bootstrap_ci
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
B = 2000          # bootstrap 次数
BLOCK = 7         # 块长（天）
SEED = 42


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    plans = pd.read_csv(os.path.join(OUT, "q4_plans.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")

    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(plans[["date", "hour", "q_R1", "q_R2", "q_R3"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"]))
    df["S"] = df["price_rt"] - df["price_da"]
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)

    # gamma=0.3 的申报量：q = Qc + 0.3 (q* - Qc)，q* 即 q_bid
    qstar = df["q_bid"].to_numpy(float)
    q_g03 = qc + 0.3 * (qstar - qc)

    rules = {
        "恒报上带 max(1.2Lhat,Qc)": up,
        "恒报 Lhat": Lh,
        "R2（系统基线档）": df["q_R2"].to_numpy(float),
        "R1（lambda=0）": df["q_R1"].to_numpy(float),
        "gamma=0.3 收缩": q_g03,
        "确定性申报": qstar,
    }
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)

    def daily(q):
        out = []
        for i in df.groupby("date").indices.values():
            out.append(settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"])
        return np.asarray(out, float)

    base_daily = daily(qc)
    dates = np.array(sorted(df["date"].unique()))
    n = len(dates)
    rng = np.random.default_rng(SEED)

    # 预生成块 bootstrap 的索引（块长 7 天，环绕拼接）
    nb = int(np.ceil(n / BLOCK))
    idxs = []
    for _ in range(B):
        starts = rng.integers(0, n, size=nb)
        idx = np.concatenate([(np.arange(s, s + BLOCK) % n) for s in starts])[:n]
        idxs.append(idx)

    rows = []
    for name, q in rules.items():
        d = daily(q)
        diff = d - base_daily                      # 逐日差额（正=更贵）
        point = float(diff.mean())
        boots = np.array([diff[idx].mean() for idx in idxs])
        lo, hi = np.percentile(boots, [2.5, 97.5])
        rows.append({"规则": name,
                     "日均差额_元": round(point, 1),
                     "相对基准_pct": round(float(d.sum() - base_daily.sum()) / base_daily.sum() * 100, 3),
                     "CI下界_元": round(float(lo), 1),
                     "CI上界_元": round(float(hi), 1),
                     "显著": "是" if (lo > 0 or hi < 0) else "否"})

    out = pd.DataFrame(rows).sort_values("相对基准_pct")
    out.to_csv(os.path.join(OUT, "bootstrap_ci.csv"), index=False, encoding="utf-8-sig")
    print("=" * 94)
    print(out.to_string(index=False))
    print("=" * 94)
    print(f"\n  块长 {BLOCK} 天，重采样 {B} 次 | 产出：{os.path.join(OUT, 'bootstrap_ci.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
