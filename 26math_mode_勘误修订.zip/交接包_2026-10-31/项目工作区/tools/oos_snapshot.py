# -*- coding: utf-8 -*-
"""生成 2--3 月样本外快照 `outputs/oos_predictions_2_3.csv`。

**为什么需要这个脚本**：论文的样本外裁判（表 21）与四窗 minimax（表 22）都依赖
2--3 月那一段的预测与申报量。此前的做法是"手工跑一遍、手工存快照"，附录里没有
生成脚本，导致表 21 的 R1/R3 两行与表 22 的 R1 行没有可复现来源。

本脚本把这条链补上：在临时目录里按 2--3 月评估窗跑 q2 → q3 → q4，
取 q2/q3/q4 的并集存为快照。**主产物不被写入**（三个模块的 OUT 都重定向）。

输出：
    outputs/oos_predictions_2_3.csv   列：date hour L_hat S_hat q_bid q_det q_R1 q_R2 q_R3

用法：<venv>/python.exe -m tools.oos_snapshot
"""
import os
import shutil
import subprocess
import sys
import tempfile

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
START, END = "2026-02-01", "2026-03-31"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    tmp = tempfile.mkdtemp(prefix="oos_")
    try:
        env = dict(os.environ)
        env.update({"PYTHONIOENCODING": "utf-8",
                    "SUMMARY_PATH": os.path.join(tmp, "summary.json"),
                    "EVAL_START": START, "EVAL_END": END,          # q2/q3 用
                    "Q4_EVAL_START": START, "Q4_EVAL_END": END,    # q4 用
                    "Q2_OUT_DIR": tmp, "Q3_OUT_DIR": tmp, "Q4_OUT_DIR": tmp,
                    "FIG_DIR": os.path.join(tmp, "figures")})
        env.pop("Q3_NO_BIAS", None)

        for mod in ("src.q2.solve", "src.q3.solve", "src.q4.solve"):
            print(f"  {mod} ...", flush=True)
            r = subprocess.run([sys.executable, "-m", mod], cwd=ROOT, env=env,
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace")
            if r.returncode != 0:
                raise RuntimeError(f"{mod} 失败：\n{r.stderr[-800:]}")

        q2 = pd.read_csv(os.path.join(tmp, "q2_forecast.csv"), encoding="utf-8-sig")
        q3 = pd.read_csv(os.path.join(tmp, "q3_price_bid.csv"), encoding="utf-8-sig")
        plans = pd.read_csv(os.path.join(tmp, "q4_plans.csv"), encoding="utf-8-sig")

        snap = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
                .merge(q3[["date", "hour", "pred_spread_final", "q_bid"]].rename(
                           columns={"pred_spread_final": "S_hat"}), on=["date", "hour"])
                .merge(plans, on=["date", "hour"]))
        snap["q_risk"] = snap["q_R2"]      # oos_judge 读 q_risk，二者同为 R2
        snap = snap.sort_values(["date", "hour"]).reset_index(drop=True)
        snap.to_csv(os.path.join(OUT, "oos_predictions_2_3.csv"), index=False,
                    encoding="utf-8-sig")

        print(f"\n  行数 {len(snap)} | 日期 {snap.date.min()} ~ {snap.date.max()}"
              f"（{snap.date.nunique()} 天）")
        print(f"  列：{list(snap.columns)}")
        print(f"  产出：{os.path.join(OUT, 'oos_predictions_2_3.csv')}")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
