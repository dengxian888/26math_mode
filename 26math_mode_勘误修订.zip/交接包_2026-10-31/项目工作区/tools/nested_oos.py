# -*- coding: utf-8 -*-
"""嵌套滚动样本外：(4-6 月选规则) -> (7-8 月只评一次)。

**做法**：不另跑管线，而是把**主跑（4-8 月）的逐日决策**按窗口切开。
理由：主跑的模型本来就逐周重估（训练截止 W-5 / W-7），因此 7 月 1 日的决策
只用到 6 月底及以前的信息——与"在 7-8 月单独重跑一次"**在信息集上完全等价**，
而主跑的残差池在 7/1 已有 4-6 月的合法历史（单独重跑则池为空）。

**早先版本的错误**：曾用两个独立窗口各跑一条管线，导致 7-8 月窗口在 7/1
残差池冷启动、丢掉 4-6 月合法可得的残差，使依赖池的规则（R1/R2/R3/F/G）
被系统性低估、池无关规则（A/B/C）不受影响。这会让"规则排名不可传递"
的结论部分成为 warm-up 伪影。本版已修正。

输出 `outputs/nested_oos.csv`。

用法：<venv>/python.exe -m tools.nested_oos
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")

SEL = ("2026-04-01", "2026-06-30")
EVA = ("2026-07-01", "2026-08-31")


def load_main():
    """读主跑（4-8 月）的逐日决策与结算要素。"""
    from src.common import io
    data = io.load_attachments()
    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")
    plans = pd.read_csv(os.path.join(OUT, "q4_plans.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "pred_spread_final", "q_bid"]], on=["date", "hour"])
          .merge(q4[["date", "hour", "q_risk"]], on=["date", "hour"])
          .merge(plans, on=["date", "hour"])
          .merge(data["att2"][["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(data["att4"][["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(data["att5"], on=["date", "hour"]))
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)
    df["S"] = df["price_rt"] - df["price_da"]
    return df, data


def settle_sum(df, q):
    from src.common.settle import settle_day
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    tot = 0.0
    for _, idx in df.groupby("date").indices.items():
        tot += settle_day(np.asarray(q, float)[idx], L[idx], pda[idx],
                          prt[idx], qc[idx], pc[idx])["sums"]["total"]
    return tot


def evaluate(df, hist):
    """在给定窗口内计算各候选规则的相对基准成本（%）。"""
    qc = df["contract_q"].to_numpy(float)
    base = settle_sum(df, qc)

    allspread = pd.concat([hist, df.groupby("date")["S"].mean()]).groupby(level=0).last()
    dates = list(allspread.index)
    mu, sd = {}, {}
    for D in dates:
        past = [x for x in dates
                if x < D and (pd.Timestamp(D) - pd.Timestamp(x)).days >= 7]
        if len(past) < 5:
            mu[D], sd[D] = 0.0, np.nan
        else:
            v = allspread[past[-28:]].to_numpy(float)
            mu[D], sd[D] = float(v.mean()), float(v.std(ddof=1))
    d = df.copy()
    d["mu"] = d["date"].map(mu)
    d["sd"] = d["date"].map(sd)
    mu_v = d["mu"].to_numpy(float)
    sd_v = d["sd"].to_numpy(float)
    z = mu_v / (sd_v / np.sqrt(28))

    Lh = d["L_hat"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)
    dn = 0.8 * Lh
    qr = d["q_risk"].to_numpy(float)
    qstar = d["q_bid"].to_numpy(float)

    res = {}
    cand = [("A 按合约量", qc), ("B 恒报L", Lh), ("C 恒报上带", up), ("恒报1.2L", 1.2 * Lh), ("D 报下带", dn),
            ("G 确定性", qstar), ("R1 lambda0", d["q_R1"].to_numpy(float)),
            ("R2 lambda0.5", qr), ("R3 lambda2", d["q_R3"].to_numpy(float))]
    for name, q in cand:
        res[name] = (settle_sum(d, q) - base) / base * 100
    res["E 符号"] = (settle_sum(d, np.where(mu_v > 0, up, dn)) - base) / base * 100
    for th in (0.5, 1.0, 1.5):
        inside = (np.abs(z) < th) & np.isfinite(sd_v)
        q = np.where(inside, qr, np.where(mu_v > 0, up, dn))
        res[f"F 死区{th}"] = (settle_sum(d, q) - base) / base * 100
    for g in (0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0):
        q = qc + g * (qstar - qc)
        res[f"gamma={g:.1f}"] = (settle_sum(d, q) - base) / base * 100
    return res


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    df, data = load_main()
    a4 = data["att4"].copy()
    a4["S"] = a4["price_rt"] - a4["price_da"]
    hist = a4.groupby("date")["S"].mean()

    out = {}
    for tag, (s, e) in (("select", SEL), ("eval", EVA)):
        sub = df[(df["date"] >= s) & (df["date"] <= e)].reset_index(drop=True)
        out[tag] = evaluate(sub, hist)
        print(f"  窗口 {tag}: {sub.date.nunique()} 天，{len(sub)} 行")

    # 一致性自检：两窗按天数加权应还原主跑（4-8）
    full = evaluate(df, hist)
    ns, ne = df[(df.date >= SEL[0]) & (df.date <= SEL[1])].date.nunique(), \
        df[(df.date >= EVA[0]) & (df.date <= EVA[1])].date.nunique()
    print("\n  一致性自检（两窗按天数加权 vs 主跑 4-8 月）：")
    for k in ["B 恒报L", "C 恒报上带", "G 确定性", "R2 lambda0.5", "F 死区1.5"]:
        w = (out["select"][k] * ns + out["eval"][k] * ne) / (ns + ne)
        print(f"    {k:<14} 加权 {w:+.3f}% vs 主跑 {full[k]:+.3f}%  差 {w-full[k]:+.4f}")

    rows = []
    for k in out["select"]:
        rows.append({"候选": k, "选择窗_4-6月": round(out["select"][k], 3),
                     "检验窗_7-8月": round(out["eval"][k], 3)})
    res = pd.DataFrame(rows)
    res["最差一期"] = res[["选择窗_4-6月", "检验窗_7-8月"]].max(axis=1).round(3)
    res.to_csv(os.path.join(OUT, "nested_oos.csv"), index=False, encoding="utf-8-sig")

    print("\n" + "=" * 60)
    print(res.to_string(index=False))
    p = np.corrcoef(res["选择窗_4-6月"], res["检验窗_7-8月"])[0, 1]
    sp = res[["选择窗_4-6月", "检验窗_7-8月"]].corr(method="spearman").iloc[0, 1]
    print("=" * 60)
    print(f"  n={len(res)}  Pearson {p:+.3f} | Spearman {sp:+.3f}")
    print(f"  选择窗最优: {res.loc[res['选择窗_4-6月'].idxmin(),'候选']}"
          f"（{res['选择窗_4-6月'].min():+.3f}%）")
    print(f"  检验窗最优: {res.loc[res['检验窗_7-8月'].idxmin(),'候选']}"
          f"（{res['检验窗_7-8月'].min():+.3f}%）")
    print(f"\n  产出：{os.path.join(OUT, 'nested_oos.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
