# -*- coding: utf-8 -*-
"""问题三：偏差校正的 2x2 对照矩阵（论文表 13 的四格）。

四个格子：
    行 = 预测器（GBDT+收缩 / 分时段中位数基准）
    列 = 是否施加同一滚动校正
其中"GBDT 不校正"这一格此前只存在于正文的叙述里，没有产物，本脚本补齐。

**安全性**：把 `src.q3.solve.OUT` 临时重定向到临时目录，因此**不会覆盖任何主产物**。
q2 的预测先复制进临时目录，保证 main() 能读到上游。

输出 `outputs/q3_bias_matrix.csv`。

用法：<venv>/python.exe -m tools.q3_bias_matrix
"""
import os
import shutil
import subprocess
import sys
import tempfile

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def run_q3(tmp, no_bias):
    """在 tmp 目录里跑一次 q3/solve.py，返回写出的 q3_econ.csv。"""
    env = dict(os.environ)
    env["SUMMARY_PATH"] = os.path.join(tmp, "summary.json")
    env["PYTHONIOENCODING"] = "utf-8"
    if no_bias:
        env["Q3_NO_BIAS"] = "1"
    else:
        env.pop("Q3_NO_BIAS", None)
    env["Q3_OUT_DIR"] = tmp          # 由 solve.py 读取（见下）
    r = subprocess.run([sys.executable, "-m", "src.q3.solve"],
                       cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError(f"q3 solve 失败：{r.stderr[-600:]}")
    return pd.read_csv(os.path.join(tmp, "q3_econ.csv"), encoding="utf-8-sig")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    base = pd.read_csv(os.path.join(OUT, "q3_baseline_compare.csv"), encoding="utf-8-sig")

    tmp = tempfile.mkdtemp(prefix="q3bias_")
    try:
        # 上游 q2 预测复制进临时目录（main() 从 OUT 读）
        shutil.copy(os.path.join(OUT, "q2_forecast.csv"), tmp)

        print("  跑 GBDT 不校正 ...")
        econ_raw = run_q3(tmp, no_bias=True)

        # 该次运行已把 q3 产物写进 tmp；取指标
        met = pd.read_csv(os.path.join(tmp, "q3_metrics.csv"), encoding="utf-8-sig")
        spread_mae = float(met[met["target"] == "spread_direct"]["MAE"].iloc[0]) \
            if "target" in met.columns else float("nan")
        cost_raw = float(econ_raw.iloc[0]["总成本"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # 同一基准
    base_cost = float(pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"),
                                  encoding="utf-8-sig")
                      .set_index("key").loc["baseline", "总成本"])

    def rel(c):
        return (float(c) - base_cost) / base_cost * 100

    rows = [
        {"预测器": "GBDT + 收缩（本文）", "校正": "不校正",
         "价差 MAE": round(spread_mae, 2), "总成本": round(cost_raw, 2),
         "相对基准_pct": round(rel(cost_raw), 3)},
    ]
    for _, r in base.iterrows():
        rows.append({"预测器": "分时段中位数（基准）" if "基准" in r["方案"] else "GBDT",
                     "校正": "不校正" if "不校正" in r["方案"] else "同一滚动校正",
                     "价差 MAE": round(float(r["价差 MAE"]), 2),
                     "总成本": round(float(r["总成本"]), 2),
                     "相对基准_pct": round(rel(r["总成本"]), 3)})
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "q3_bias_matrix.csv"), index=False, encoding="utf-8-sig")

    print("\n" + out.to_string(index=False))
    print(f"\n  产出：{os.path.join(OUT, 'q3_bias_matrix.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
