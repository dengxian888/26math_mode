# -*- coding: utf-8 -*-
"""四窗 minimax 判据：把论文报告过的全部四个窗口并列，选"最差一期最好"的规则。

**数据来源（全部从产物现算，无任何硬编码）**：
    4--8 月  ← outputs/q4_benchmark.csv（C/B/R1/R2/R3/A）与 q4_switch.csv（F/E）
    2--3 月  ← outputs/oos_1_3_month.csv（由 src/q4/oos_judge.py 产出）
    4--6 月  ← outputs/nested_oos.csv（由 tools/nested_oos.py 产出）
    7--8 月  ← outputs/nested_oos.csv

窗口：
    4-8 月（153 天，E[S]=+23.74）  主评估期
    2-3 月（59 天，E[S]=+0.62）    样本外裁判
    4-6 月（91 天，E[S]=+34.60）   嵌套：选择窗
    7-8 月（62 天，E[S]=+7.80）    嵌套：检验窗

输出 `outputs/minimax_4win.csv`。

用法：<venv>/python.exe -m tools.minimax_4win
"""
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    bench = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    switch = pd.read_csv(os.path.join(OUT, "q4_switch.csv"), encoding="utf-8-sig").set_index("规则")
    oos = pd.read_csv(os.path.join(OUT, "oos_1_3_month.csv"), encoding="utf-8-sig").set_index("规则")
    nest = pd.read_csv(os.path.join(OUT, "nested_oos.csv"), encoding="utf-8-sig").set_index("候选")

    def b(k):
        return float(bench.loc[k, "相对基准_pct"])

    def s(k):
        return float(switch.loc[k, "相对基准_pct"])

    def o(k):
        return float(oos.loc[k, "相对基准_pct"])

    def n(k, col):
        return float(nest.loc[k, col])

    F_KEY = "同 + 死区 theta=1.5"
    spec = [
        # 显示名, 4-8月, 2-3月, nested 键
        ("F 死区 1.5", s(F_KEY), o("F 死区theta=1.5"), "F 死区1.5"),
        ("C 恒报上带", b("up12_qc"), o("C 恒报 max(1.2L_hat,Qc)"), "C 恒报上带"),
        ("B 恒报 L", b("flat"), o("B 恒报 L_hat"), "B 恒报L"),
        ("恒报 1.2L_hat", b("up12"), o("恒报 1.2L_hat"), "恒报1.2L"),
        ("R2（系统基线档）", b("R2"), o("H 风险申报 R2"), "R2 lambda0.5"),
        ("R3（lambda=2）", b("R3"), o("R3 风险申报 R3"), "R3 lambda2"),
        ("R1（lambda=0）", b("R1"), o("R1 风险申报 R1"), "R1 lambda0"),
        ("A 按合约量", 0.0, 0.0, "A 按合约量"),
    ]
    rows = []
    for name, v48, v23, nk in spec:
        v = [v48, v23, n(nk, "选择窗_4-6月"), n(nk, "检验窗_7-8月")]
        rows.append({"规则": name, "4-8月_+23.74": round(v[0], 3), "2-3月_+0.62": round(v[1], 3),
                     "4-6月_+34.60": round(v[2], 3), "7-8月_+7.80": round(v[3], 3),
                     "最差一期": round(max(v), 3)})
    out = pd.DataFrame(rows).sort_values("最差一期").reset_index(drop=True)
    out["排名"] = out.index + 1
    out.to_csv(os.path.join(OUT, "minimax_4win.csv"), index=False, encoding="utf-8-sig")

    print("=" * 80)
    print("四窗 minimax（越负越好；'最差一期'= 四个窗口中最高者）")
    print("=" * 80)
    print(out.round(3).to_string(index=False))
    print(f"\n  冠军：{out.iloc[0]['规则']}（最差一期 {out.iloc[0]['最差一期']:+.3f}%）")
    r2 = out[out["规则"].str.startswith("R2")]
    print(f"  R2 最差一期 {float(r2['最差一期'].iloc[0]):+.3f}%，第 {int(r2['排名'].iloc[0])}")
    print(f"\n  产出：{os.path.join(OUT, 'minimax_4win.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
