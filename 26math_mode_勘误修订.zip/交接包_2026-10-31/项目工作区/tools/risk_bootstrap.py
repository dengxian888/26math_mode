# -*- coding: utf-8 -*-
"""风险指标之差的月份块配对 bootstrap。

**为什么要做**：正文以"F 的标准差与日 CVaR95 为全表最低"作为交付 F 的依据，
但那只报了**点估计**。若该差值与噪声同量级，这条依据就不成立。
本脚本对 F/C/R2 两两之间做**月份块**配对 bootstrap（20000 次），
给出日标准差之差与日 CVaR95 之差的 95% 区间。

输出 outputs/risk_bootstrap.csv。
用法：<venv>/python.exe -m tools.risk_bootstrap
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
B, SEED = 20000, 42


def cvar95(x):
    k = max(1, int(np.ceil(0.05 * len(x))))
    return float(np.sort(x)[-k:].mean())


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q4[["date", "hour", "q_risk", "q_final"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"])).sort_values(["date", "hour"]).reset_index(drop=True)
    L = df["load_actual"].to_numpy(float); pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float); qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    up = np.maximum(1.2 * df["L_hat"].to_numpy(float), qc)

    idx = list(df.groupby("date").indices.items())
    days = [str(d)[:10] for d, _ in idx]
    months = np.array([d[:7] for d in days])
    def daily(q):
        return np.asarray([settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                           for _, i in idx])
    rules = {"F（交付规则）": df["q_final"].to_numpy(float),
             "R2（基线档）": df["q_risk"].to_numpy(float),
             "C（恒报上带）": up}
    D = {k: daily(v) for k, v in rules.items()}

    uniq = sorted(set(months))
    blocks = [np.where(months == m)[0] for m in uniq]
    rng = np.random.default_rng(SEED)
    rows = []
    for a_, b_ in [("F（交付规则）", "C（恒报上带）"), ("F（交付规则）", "R2（基线档）"),
                   ("C（恒报上带）", "R2（基线档）")]:
        for metric in ["标准差", "CVaR95"]:
            fn = (lambda x: float(x.std(ddof=1))) if metric == "标准差" else cvar95
            obs = fn(D[a_]) - fn(D[b_])
            boots = np.empty(B)
            for k in range(B):
                pick = rng.integers(0, len(blocks), size=len(blocks))
                ii = np.concatenate([blocks[j] for j in pick])
                boots[k] = fn(D[a_][ii]) - fn(D[b_][ii])
            lo, hi = np.percentile(boots, [2.5, 97.5])
            p = float(2 * min((boots <= 0).mean(), (boots >= 0).mean()))
            rows.append({"对比": f"{a_} vs {b_}", "指标": metric,
                         "差值_元": round(float(obs), 1),
                         "CI下界": round(float(lo), 1), "CI上界": round(float(hi), 1),
                         "p值": round(p, 4),
                         "显著": "是" if (lo > 0 or hi < 0) else "否"})
    # ---- 剔除 4 月后的风险指标（检验"不依赖 4 月"这一说法）----
    keep = months != "2026-04"
    ex = []
    for k, v in D.items():
        x = v[keep]
        ex.append({"方案": k, "口径": "剔除4月", "标准差": round(float(x.std(ddof=1)), 1),
                   "CVaR95": round(cvar95(x), 1), "最大单日": round(float(x.max()), 1),
                   "天数": int(keep.sum())})
    for k, v in D.items():
        ex.append({"方案": k, "口径": "全期", "标准差": round(float(v.std(ddof=1)), 1),
                   "CVaR95": round(cvar95(v), 1), "最大单日": round(float(v.max()), 1),
                   "天数": int(len(v))})
    pd.DataFrame(ex).to_csv(os.path.join(OUT, "risk_ex_april.csv"), index=False, encoding="utf-8-sig")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "risk_bootstrap.csv"), index=False, encoding="utf-8-sig")
    print("=" * 86)
    print("风险指标之差的月份块配对 bootstrap（负 = 前者更低/更好；20000 次，块=月）")
    print("=" * 86)
    print(out.to_string(index=False))
    print()
    print("=" * 86)
    print("剔除 4 月后的风险指标（检验'不依赖 4 月'）")
    print("=" * 86)
    print(pd.DataFrame(ex).sort_values(["口径", "方案"]).to_string(index=False))
    print(f"\n  产出：risk_bootstrap.csv、risk_ex_april.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
