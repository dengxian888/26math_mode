# -*- coding: utf-8 -*-
"""问题四交付图：累计成本差（相对按合约量申报）与 4 月的贡献。

左图：F / R2 / C 三条规则的累计节省曲线，直观显示 F 的增量集中在 4 月。
右图：逐月节省柱状对比，对应正文"F 的优势几乎全部来自 4 月"。

输出 outputs/figures/q4_交付对比.png。
用法：<venv>/python.exe -m tools.fig_q4_final
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
FIG = os.path.join(OUT, "figures")
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(q4[["date", "hour", "q_risk", "q_final"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"])).sort_values(["date", "hour"]).reset_index(drop=True)
    L = df["load_actual"].to_numpy(float); pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float); qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    up = np.maximum(1.2 * df["L_hat"].to_numpy(float), qc)

    idx = list(df.groupby("date").indices.items())
    days = [str(d)[:10] for d, _ in idx]
    def daily(q):
        return np.asarray([settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                           for _, i in idx])
    base = daily(qc)
    rules = {"F（交付规则）": df["q_final"].to_numpy(float),
             "R2（系统基线档）": df["q_risk"].to_numpy(float),
             "C（恒报上带）": up}
    D = {k: daily(v) for k, v in rules.items()}

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.2, 4.4), gridspec_kw={"width_ratios": [1.65, 1]})
    x = np.arange(len(days))
    colors = {"F（交付规则）": "#1f77b4", "R2（系统基线档）": "#d62728", "C（恒报上带）": "#2ca02c"}
    for k, c in D.items():
        ax1.plot(x, np.cumsum(base - c) / 1e4, label=k, color=colors[k], lw=1.7)
    ap = [i for i, d in enumerate(days) if d.startswith("2026-04")]
    if ap:
        ax1.axvspan(min(ap), max(ap), color="orange", alpha=0.13)
        ax1.text((min(ap) + max(ap)) / 2, ax1.get_ylim()[1] * 0.92, "2026 年 4 月",
                 ha="center", fontsize=9, color="#b35900")
    ax1.axhline(0, color="gray", lw=0.8, ls="--")
    ax1.set_xlabel("评估期交易日（2026-04-01 起）")
    ax1.set_ylabel("累计节省（万元）")
    ax1.set_title("累计成本差：F 的增量几乎全部发生在 4 月", fontsize=11)
    ax1.legend(fontsize=8.5, loc="upper left")
    ax1.grid(alpha=0.25)
    tick = [i for i, d in enumerate(days) if d.endswith("-01")]
    ax1.set_xticks(tick)
    ax1.set_xticklabels([days[i][:7] for i in tick], fontsize=8.5)

    months = sorted({d[:7] for d in days})
    w = 0.26
    for j, (k, c) in enumerate(D.items()):
        vals = [(base[np.array([m == mm for m in [d[:7] for d in days]])].sum()
                 - c[np.array([m == mm for m in [d[:7] for d in days]])].sum()) / 1e4
                for mm in months]
        ax2.bar(np.arange(len(months)) + (j - 1) * w, vals, w, label=k.split("（")[0], color=colors[k])
    ax2.axhline(0, color="gray", lw=0.8, ls="--")
    ax2.set_xticks(np.arange(len(months)))
    ax2.set_xticklabels([m[5:] for m in months], fontsize=9)
    ax2.set_xlabel("月份")
    ax2.set_ylabel("当月节省（万元）")
    ax2.set_title("逐月分解：5–8 月三者接近", fontsize=11)
    ax2.legend(fontsize=8.5)
    ax2.grid(alpha=0.25, axis="y")

    fig.tight_layout()
    os.makedirs(FIG, exist_ok=True)
    out = os.path.join(FIG, "q4_交付对比.png")
    fig.savefig(out, dpi=170, bbox_inches="tight")
    print(f"  [fig] {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
