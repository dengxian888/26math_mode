# -*- coding: utf-8 -*-
"""把论文中的数字表从产物 CSV 自动生成为 LaTeX。

此前论文里的表是手工抄进 LaTeX 的，每改一次方法就要同步数十处，反复出现
"表已更新、正文未同步"的事故。改为程序生成后，这类错误从结构上消失。

用法：python tools/gen_tables.py
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
TAB = os.path.join(ROOT, "paper", "tables")

BR = "\\\\"
PCT = "\\%"


def money(x, nd=2):
    return f"{x:,.{nd}f}".replace(",", "{,}")


def integer(x):
    return f"{x:,.0f}".replace(",", "{,}")


def pct(x, nd=3, b=False):
    s = "$" + f"{x:+.{nd}f}" + PCT + "$"
    return "\\textbf{" + s + "}" if b else s


def bold(s):
    return "\\textbf{" + s + "}"


def row(*cells):
    return " & ".join(str(c) for c in cells) + " " + BR


def table(label, caption, colspec, header, rows, small=False):
    head = [r"\begin{table}[htbp]", r"\centering",
            "\\caption{" + caption + "}", "\\label{" + label + "}"]
    if small:
        head += [r"\footnotesize", r"\setlength{\tabcolsep}{3pt}"]
    head += ["\\begin{tabular}{" + colspec + "}", r"\toprule", header, r"\midrule"]
    tail = [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(head + rows + tail) + "\n"


BASE = None


def base_cost():
    """按合约量申报的总成本（全表统一基准）。"""
    global BASE
    if BASE is None:
        b = read("q4_benchmark.csv").set_index("key")
        BASE = float(b.loc["baseline", "总成本"])
    return BASE


def rel(cost):
    """相对基准的百分比（一律现算，不读预存的百分比列）。"""
    return (float(cost) - base_cost()) / base_cost() * 100


def read(name):
    return pd.read_csv(os.path.join(OUT, name), encoding="utf-8-sig")


def tab_q1cost():
    d = read("q1_cost.csv")
    rows = []
    for _, r in d.iterrows():
        rows.append(row(r["date"][5:], money(r["cost_total"]),
                        "$" + f"{(r['baseline_total'] - r['cost_total']) / r['baseline_total'] * 100:.2f}" + PCT + "$"))
    tc, tb = d["cost_total"].sum(), d["baseline_total"].sum()
    rows.append(r"\midrule")
    rows.append(row("合计", bold(money(tc)),
                    "$" + f"{(tb - tc) / tb * 100:.2f}" + PCT + "$"))
    return table("tab:q1cost", "完全信息下的最优申报结果（5 个典型日，事后结算）",
                 "@{}lrr@{}", row("日期", "最优总成本（元）",
                                  "节省率（相对按合约量申报）"), rows)


def tab_q2res():
    d = read("q2_metrics.csv").set_index("scheme")
    names = {"baseline": "朴素基线（同类型同时段 28 天均值）",
             "A": "A：仅历史用电 + 日期属性",
             "B": "B：A + 系统预测信息",
             "C": "C：B + 系统实际信息（$D-3$）"}
    rows = []
    for k in ["baseline", "A", "B", "C"]:
        r = d.loc[k]
        f = bold if k == "C" else (lambda s: s)
        rows.append(row(names[k], f(f"{r.MAE:.4f}"), f(f"{r.RMSE:.4f}"),
                        f(f"{r.WMAPE:.2f}" + PCT), f(f"{r.MAPE:.2f}" + PCT)))
    return table("tab:q2res", "三档嵌套信息条件下的用电量预测精度",
                 "@{}lrrrr@{}",
                 row("方案", "MAE（MWh）", "RMSE", "WMAPE", "MAPE"), rows)


def tab_q2weight():
    d = read("q2_weight.csv")
    rows = []
    for i, r in d.iterrows():
        f = bold if i == 0 else (lambda s: s)
        rows.append(row(r["加权方案"], f(f"{r['总体 MAE']:.4f}"),
                        f(f"{r['节假日 MAE']:.4f}")))
    return table("tab:q2weight", "针对节假日高估的四组样本加权（负结果：全部使总体 MAE 恶化）",
                 "@{}lrr@{}", row("加权方案", "总体 MAE", "节假日 MAE"), rows)


def tab_q3base():
    d = read("q3_bias_matrix.csv")
    piv = {}
    for _, r in d.iterrows():
        pred = "GBDT" if "GBDT" in str(r["预测器"]) else "中位数"
        key = "raw" if "不校正" in str(r["校正"]) else "cor"
        piv.setdefault(pred, {})[key] = r
    rows = []
    for pred, name in [("GBDT", "GBDT + 收缩（本文）"),
                       ("中位数", "分时段中位数（24 参数基准）")]:
        a, b = piv[pred]["raw"], piv[pred]["cor"]
        rows.append(row(name,
                        f"{float(a['价差 MAE']):.2f}", pct(float(a['相对基准_pct'])),
                        f"{float(b['价差 MAE']):.2f}", pct(float(b['相对基准_pct']))))
    return table("tab:q3base",
                 "价差预测器的 $2\\times2$ 对照（行=预测器，列=是否施加同一滚动校正）",
                 "@{}lrrrr@{}",
                 row("预测器", r"MAE（不校正）", r"成本（不校正）",
                     r"MAE（同校正）", r"成本（同校正）"), rows, small=True)


def tab_q3econ():
    d = read("q3_econ.csv")
    base = float(d[d["方案"].str.contains("按合约量")]["总成本"].iloc[0])
    rows = []
    for _, r in d.iterrows():
        c = float(r["总成本"])
        rows.append(row(r["方案"], money(c), pct((c - base) / base * 100)))
    return table("tab:q3econ", "确定性申报的经济效果（153 天，事后结算）",
                 "@{}lrr@{}", row("方案", "总成本（元）", "相对基准"), rows)


def tab_q3decomp():
    d = read("q3_decompose.csv")
    rows = [row(r["组合"], money(r["总成本"]), pct(rel(r["总成本"])))
            for _, r in d.iterrows()]
    return table("tab:q3decomp",
                 "确定性申报的 $2\\times2$ 误差分解（行=负荷用实测/预测，列=价差用实测/预测）",
                 "@{}lrr@{}", row("组合", "总成本（元）", "相对基准"), rows)


def tab_shrink():
    d = read("q3_shrinkage.csv").copy()
    d["g"] = d["gamma"].round(2)
    sel = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 1.0]
    head = ["$\\gamma$"]
    vals = ["相对基准"]
    for g in sel:
        head.append(bold("%.1f" % g) if g == 0.3 else "%.1f" % g)
        v = rel(d[d["g"] == g]["总成本"].iloc[0])
        vals.append(pct(v, 3, b=(g == 0.3)))
    rows = [row(*vals)]
    return table("tab:shrink_q",
                 "把申报量向合约量收缩的决策对齐效果（153 天，事后结算；越负越好）",
                 "@{}l" + "r" * len(sel) + "@{}", row(*head), rows, small=True)


def tab_q4bench():
    d = read("q4_benchmark.csv").set_index("key")
    order = [("baseline", "按合约量申报"), ("det", "确定性申报（问题三）"),
             ("R1", "风险申报 R1（$\\lambda=0$）"),
             ("R2", "\\textbf{风险申报 R2（$\\lambda=0.5$，系统基线档）}"),
             ("R3", "风险申报 R3（$\\lambda=2.0$）"), (None, None),
             ("up12", "恒报 $1.2\\hat L$（零模型）"),
             ("up12_qc", "恒报 $\\max(1.2\\hat L,Q^c)$（零模型）"),
             ("flat", "恒报 $\\hat L$"),
             ("dn08", "恒报 $0.8\\hat L$"), (None, None),
             ("oracle12", "恒报 $1.2L$（用实测值）"),
             ("oracle", "完全信息最优")]
    keys = [k for k, _ in order if k and k in d.index]
    best = d.loc[keys, "总成本"].min()
    legal_keys = [k for k in keys if k not in ("oracle", "oracle12")]
    best_key = d.loc[legal_keys, "总成本"].idxmin()
    rows = []
    for k, label in order:
        if k is None:
            rows.append(r"\midrule")
            continue
        if k not in d.index:
            continue
        r = d.loc[k]
        legal = {"oracle12": "不可得", "oracle": "理论下界"}.get(
            k, str(r["合法性"]).replace("**", ""))
        pv = pct(rel(r["总成本"]), 3, b=(k == best_key))
        rows.append(row(label, money(r["总成本"]), pv, legal))
    return table("tab:q4bench",
                 "各策略的全期成本对比（153 天，事后结算；基准为按合约量申报）",
                 "@{}lrrr@{}", row("策略", "总成本（元）", "相对基准", "合法性"), rows)


def tab_q4risk():
    d = read("q4_risk_metrics.csv").set_index("key")
    order = [("baseline", "按合约量申报"), ("det", "确定性申报（问题三）"),
             ("R1", "风险申报 R1"),
             ("R2", "系统基线档 R2"),
             ("R3", "风险申报 R3"), (None, None),
             ("F", "\\textbf{交付规则 F（}$\\boldsymbol{\\theta=1.5}$\\textbf{）}"), (None, None),
             ("flat", "\\textbf{恒报 $\\hat L$（零模型）}"),
             ("up12", "恒报 $1.2\\hat L$（零模型）"),
             ("up12_qc", "恒报 $\\max(1.2\\hat L,Q^c)$")]
    keys = [k for k, _ in order if k and k in d.index]
    cols = ["日均", "标准差", "VaR95", "CVaR95", "最大单日"]
    best = {c: d.loc[keys, c].min() for c in cols}
    rows = []
    for k, name in order:
        if k is None:
            rows.append(r"\midrule")
            continue
        if k not in d.index:
            continue
        r = d.loc[k]
        cells = [name]
        for c in cols:
            v = integer(r[c])
            cells.append(bold(v) if abs(r[c] - best[c]) < 0.5 else v)
        rows.append(row(*cells))
    return table("tab:q4risk", "各方案的日成本风险指标（153 天，单位：元）",
                 "@{}lrrrrr@{}",
                 row("方案", "日均成本", "标准差", "VaR$_{95}$", "CVaR$_{95}$",
                     "最大单日"), rows)


def tab_switch():
    d = read("q4_switch.csv")
    NAMES = {
        "按合约量申报": "按合约量申报",
        "固定上带 max(1.2L_hat,Qc)（对照）": "固定上带 $\\max(1.2\\hat L,Q^c)$（对照）",
        "恒报 1.2L_hat": "恒报 $1.2\\hat L$（零模型）",
        "滚动 28 日均值符号": "滚动 28 日均值符号",
        "同 + 死区 theta=0.5": "同上 + 死区 $\\theta=0.5$",
        "同 + 死区 theta=1.0": "同上 + 死区 $\\theta=1.0$",
        "同 + 死区 theta=1.5": "同上 + 死区 $\\theta=1.5$",
    }
    best_i = int(d["总成本"].idxmin())
    rows = []
    for idx, r in d.iterrows():
        raw = str(r["规则"])
        name = NAMES.get(raw, raw)
        b = (idx == best_i)
        rows.append(row(name, bold(money(r["总成本"])) if b else money(r["总成本"]),
                        pct(rel(r["总成本"]), 3, b)))
    return table("tab:switch",
                 "基于因果可得信息的切换规则（均劣于固定上带，但已相当接近）",
                 "@{}lrr@{}", row("规则", "总成本（元）", "相对基准"), rows)


def sgn(x):
    v = int(round(x))
    return "$+" + integer(v) + "$" if v >= 0 else "$-" + integer(-v) + "$"


def tab_q4month():
    d = read("q4_monthly.csv").copy()
    a4 = pd.read_csv(os.path.join(ROOT, "data", "interim", "att4_价格.csv"),
                     encoding="utf-8-sig")
    a4["S"] = a4["price_rt"] - a4["price_da"]
    daily = a4.groupby("date")["S"].mean()

    def sm(m):
        sub = daily[(daily.index >= m + "-01") & (daily.index <= m + "-31")]
        return float(sub.mean())

    rows = []
    for _, r in d.iterrows():
        m = r["month"]
        b = (m == "2026-06")
        f = bold if b else (lambda s: s)
        rows.append(row(f(m), f("%+.2f" % sm(m)), f("%+.2f" % r["R2_相对基准_pct"]),
                        f("%+.2f" % r["up12_qc_相对基准_pct"]),
                        f(sgn(r["R2减零模型_元"]))))
    rows.append(r"\midrule")
    rows.append(row("全期", "$+23.74$", "$-0.18$", "$\\mathbf{-1.55}$",
                    sgn(d["R2减零模型_元"].sum())))
    return table("tab:q4month",
                 "R2 与零模型的逐月成本对比（前四列相对按合约量申报；末列为\\textbf{R2 $-$ 零模型}，"
                 "正 $=$ 零模型更省）",
                 "@{}lrrrr@{}",
                 row("月份", "当月价差均值", "R2",
                     "零模型 $\\max(1.2\\hat L,Q^c)$",
                     "$\\text{R2}-\\text{零模型}$（元）"),
                 rows, small=True)


def tab_oosraw():
    d = read("oos_1_3_month.csv")
    rows = [row(r["规则"], pct(r["相对基准_pct"]), integer(r["CVaR95"]))
            for _, r in d.iterrows()]
    return table("tab:oosraw", "样本外裁判的原始输出（2026-02-01 至 03-31，59 天）",
                 "@{}lrr@{}", row("规则", "相对基准", "日 CVaR$_{95}$（元）"), rows, small=True)


def tab_q4sens():
    d = read("q4_sensitivity.csv")
    rows = [row(r["设置"], money(r["总成本"]), pct(rel(r["总成本"])),
                integer(r["日成本标准差"]), integer(r["CVaR95"]))
            for _, r in d.iterrows()]
    return table("tab:q4sens", "问题四的预测误差敏感性与异常情景敏感性（153 天，相对按合约量申报）",
                 "@{}lrrrr@{}",
                 row("设置", "总成本（元）", "相对基准", "日成本 $\\sigma$",
                     "CVaR$_{95}$"), rows, small=True)


def tab_nested():
    d = read("nested_oos.csv")
    d["最差"] = d[["选择窗_4-6月", "检验窗_7-8月"]].max(axis=1)
    show = ["E 符号", "C 恒报上带", "F 死区1.5", "B 恒报L",
            "R2 lambda0.5", "gamma=0.3", "R1 lambda0", "G 确定性", "A 按合约量"]
    d = d[d["候选"].isin(show)].copy()
    d["o"] = d["候选"].map({k: i for i, k in enumerate(show)})
    d = d.sort_values("o")
    rows = []
    for _, r in d.iterrows():
        name = (r["候选"].replace("恒报L", "恒报 $\\hat L$")
                       .replace("恒报上带", "恒报 $\\max(1.2\\hat L,Q^c)$")
                       .replace("lambda0.5", "$\\lambda=0.5$")
                       .replace("lambda0", "$\\lambda=0$")
                       .replace("死区", "死区 $\\theta$=")
                       .replace("gamma=", "$\\gamma$="))
        sel_, ev_ = float(r["选择窗_4-6月"]), float(r["检验窗_7-8月"])
        bold = (r["候选"] == "C 恒报上带")
        rows.append(row(name, pct(sel_, 3, bold), pct(ev_, 3, bold),
                        pct(float(r["最差"]), 3, bold)))
    return table("tab:nested",
                 "嵌套滚动样本外：4--6 月选规则，7--8 月只评一次（相对按合约量申报）",
                 "@{}lrrr@{}",
                 row("候选规则",
                     "选择窗 4--6 月（$E[S]=+34.60$）",
                     "检验窗 7--8 月（$E[S]=+7.80$）",
                     "最差一期"), rows, small=True)


def tab_minimax():
    d = read("minimax_4win.csv")
    rows = []
    for _, r in d.iterrows():
        b = int(r["排名"]) == 1
        name = (str(r["规则"]).replace("恒报 1.2L_hat", "恒报 $1.2\\hat L$（零模型）")
                               .replace("恒报上带", "恒报 $\\max(1.2\\hat L,Q^c)$")
                               .replace("恒报 L", "恒报 $\\hat L$")
                               .replace("死区 1.5", "死区 $\\theta=1.5$")
                               .replace("lambda=0", "$\\lambda=0$")
                               .replace("lambda=2", "$\\lambda=2$"))
        f = bold if b else (lambda s: s)
        rows.append(row(f(name), pct(float(r["4-8月_+23.74"])),
                        pct(float(r["2-3月_+0.62"])),
                        pct(float(r["4-6月_+34.60"])),
                        pct(float(r["7-8月_+7.80"])),
                        pct(float(r["最差一期"]), 3, b)))
    return table("tab:minimax",
                 "四窗 minimax：把论文报告过的全部四个窗口并列，取“最差一期”最好者",
                 "@{}lrrrrr@{}",
                 row("规则", r"4--8 月", r"2--3 月", r"4--6 月", r"7--8 月",
                     r"\textbf{最差一期}"), rows, small=True)


def tab_ablation():
    d = read("ablation.csv")
    rows = []
    for _, r in d.iterrows():
        nm = str(r["方案"]).replace("R1-残差去均值", "R1 $-$ 残差去均值") \
                            .replace("R1-残差 x0.5", "R1 $-$ 残差 $\\times0.5$") \
                            .replace("R1-残差 x0.2", "R1 $-$ 残差 $\\times0.2$") \
                            .replace("R1-残差置零", "R1 $-$ 残差置零") \
                            .replace("恒报上带（对照）", "恒报上带（对照）") \
                            .replace("完全信息（对照）", "预测负荷 $+$ 真实价差（对照）") \
                            .replace("R1 基线", "\\textbf{R1 基线}")
        b = nm.startswith("\\textbf")
        rows.append(row(nm, f"{float(r['平均申报(MWh)']):.2f}",
                        pct(float(r["相对基准_pct"]), 3, b)))
    return table("tab:ablation",
                 "优化器的输入消融（同一情景池、同一 $D-7$ 截止、同一黄金分割）",
                 "@{}lrr@{}",
                 row("方案", "平均申报（MWh）", "相对基准"), rows, small=True)


def money_signed(v):
    if v > 0:
        return "+" + f"{v:,.0f}"
    if v < 0:
        return r"$-" + f"{abs(v):,.0f}$"
    return "0"


def tab_boot():
    d = read("bootstrap_ci.csv")
    rows = []
    for _, r in d.iterrows():
        nm = str(r["规则"])
        nm = nm.replace("max(1.2Lhat,Qc)", r"$\max(1.2\hat L,Q^c)$")
        nm = nm.replace("恒报 Lhat", r"恒报 $\hat L$")
        nm = nm.replace("gamma=0.3 收缩", r"$\gamma=0.3$ 收缩")
        nm = nm.replace("lambda=0", r"$\lambda=0$")
        sig = "是" if str(r["显著"]) == "是" else r"\textbf{否}"
        rows.append(row(nm, pct(float(r["相对基准_pct"])),
                        money_signed(float(r["CI下界_元"])),
                        money_signed(float(r["CI上界_元"])), sig))
    return table("tab:boot",
                 "按日块 bootstrap：各规则的日均成本改善及其 95\\% 置信区间（块长 7 天，2000 次）",
                 "@{}lrrrc@{}",
                 row("规则", "相对基准", "CI 下界（元/日）", "CI 上界（元/日）", "显著"),
                 rows, small=True)


def tab_april():
    d = read("april_check.csv")
    rows = []
    for _, r in d.iterrows():
        nm = (str(r["方案"]).replace("恒报 max(1.2L,Qc)", r"恒报 $\max(1.2\hat L,Q^c)$")
                             .replace("恒报 L_hat", r"恒报 $\hat L$")
                             .replace("lambda=0", r"$\lambda=0$")
                             .replace("lambda=2", r"$\lambda=2$"))
        rev = r"是" if str(r["是否反转"]) == "是" else ""
        rows.append(row(nm, pct(float(r["全期_pct"]), 3),
                        pct(float(r["剔除4月_pct"]), 3, rev == "是"), rev))
    return table("tab:april",
                 "剔除 4 月后的重算：排名完全反转（负 $=$ 比按合约量申报便宜）",
                 "@{}lrrr@{}",
                 row("方案", "全期（153 天）", "剔除 4 月（123 天）", "反转"), rows, small=True)


def tab_paired():
    d = read("paired_bootstrap.csv")
    rows = []
    for _, r in d.iterrows():
        nm = str(r["对比"]).replace("死区(theta=1.5)", "死区 $\\theta=1.5$") \
                            .replace("恒报上带", "恒报上带")
        rows.append(row(nm, money_signed(float(r["日均差_元"])),
                        money_signed(float(r["CI下界"])),
                        money_signed(float(r["CI上界"])),
                        f"{float(r['p值']):.3f}",
                        r"\textbf{是}" if str(r["显著"]) == "是" else "否"))
    return table("tab:paired",
                 "规则之间的\\textbf{配对}块 bootstrap（正 $=$ 前者更贵；块长 7 天，5000 次）",
                 "@{}lrrrrc@{}",
                 row("对比", "日均差（元）", "CI 下界", "CI 上界", "$p$", "显著"),
                 rows, small=True)


def tab_fmonth():
    d = read("f_monthly.csv")
    rows = []
    for _, r in d.iterrows():
        m = str(r["月份"]).replace("2026-", "").replace("全期", "")
        if str(r["月份"]) == "全期":
            rows.append(r"\midrule")
            m = "全期"
        f = bold if abs(float(r["F（交付规则）"])) >= 1.0 else (lambda x: x)
        rows.append(row(m, pct(float(r["F（交付规则）"]), 3, str(r["月份"]) == "全期"),
                        pct(float(r["R2（系统基线）"]), 3),
                        pct(float(r["C（恒报上带）"]), 3),
                        pct(float(r["恒报 1.2L"]), 3)))
    return table("tab:fmonth",
                 "F 与各规则的逐月相对成本（\\%：负 $=$ 比按合约量申报便宜）"
                 "——\\textbf{F 的优势集中在 4 月}",
                 "@{}lrrrr@{}",
                 row("月份", "F（交付规则）", "R2（基线档）", "C 恒报上带", "恒报 $1.2\\hat L$"),
                 rows, small=True)


def tab_monthblock():
    d = read("month_block.csv")
    rows = []
    for _, r in d.iterrows():
        nm = str(r["对比"]).replace("（交付规则）", "").replace("（基线档）", "") \
                            .replace("（恒报上带）", "（上带）")
        rows.append(row(nm, money_signed(float(r["日均差_元"])),
                        money_signed(float(r["CI下界"])),
                        money_signed(float(r["CI上界"])),
                        f"{float(r['p值']):.3f}",
                        r"\textbf{是}" if str(r["显著"]) == "是" else "否"))
    return table("tab:monthblock",
                 "\\textbf{月份块}聚类推断（以月为块整块重采样，20000 次；正 $=$ 前者更贵）",
                 "@{}lrrrrc@{}",
                 row("对比", "日均差（元）", "CI 下界", "CI 上界", "$p$", "显著"),
                 rows, small=True)


def tab_riskboot():
    d = read("risk_bootstrap.csv")
    rows = []
    for _, r in d.iterrows():
        nm = str(r["对比"]).replace("（交付规则）", "").replace("（基线档）", "") \
                            .replace("（恒报上带）", "（上带）")
        rows.append(row(nm, r["指标"], money_signed(float(r["差值_元"])),
                        money_signed(float(r["CI下界"])),
                        money_signed(float(r["CI上界"])),
                        f"{float(r['p值']):.3f}",
                        r"\textbf{是}" if str(r["显著"]) == "是" else "否"))
    return table("tab:riskboot",
                 "风险指标之差的\\textbf{月份块}配对 bootstrap（负 $=$ 前者更低；20000 次）",
                 "@{}llrrrrc@{}",
                 row("对比", "指标", "差值（元）", "CI 下界", "CI 上界", "$p$", "显著"),
                 rows, small=True)


def tab_riskex():
    d = read("risk_ex_april.csv")
    order = ["F（交付规则）", "R2（基线档）", "C（恒报上带）"]
    label = {"F（交付规则）": r"\textbf{F（交付）}", "R2（基线档）": "R2（基线）",
             "C（恒报上带）": "C（上带）"}
    modes = [("全期", "全期"), ("剔除4月", "剔除 4 月")]
    rows = []
    for raw_mode, show in modes:
        sub = d[d["口径"] == raw_mode].set_index("方案")
        cols = ["标准差", "CVaR95", "最大单日"]
        best = {c: sub[c].min() for c in cols}
        for k in order:
            if k not in sub.index:
                continue
            r = sub.loc[k]
            cells = [label[k], show]
            for c in cols:
                v = integer(r[c])
                cells.append(bold(v) if abs(r[c] - best[c]) < 0.5 else v)
            rows.append(row(*cells))
        if raw_mode == "全期":
            rows.append(r"\midrule")
    return table("tab:riskex",
                 r"剔除 4 月前后的风险指标对比（单位：元；\textbf{粗体 $=$ 该口径下最优}）",
                 "@{}llrrr@{}",
                 row("方案", "口径", "标准差", "CVaR$_{95}$", "最大单日"), rows, small=True)


def tab_oos():
    b = read("q4_benchmark.csv").set_index("key")
    o = read("oos_1_3_month.csv").set_index("规则")
    # 4-8 月取值：优先 benchmark；F 与 E 不在 benchmark 里，用 q4_switch 的对应值
    vals = {k: float(v) for k, v in b["相对基准_pct"].items()
            if k in ("up12", "up12_qc", "flat", "dn08", "R1", "R2", "R3", "baseline", "det")}
    vals["F"] = -1.282
    vals["E"] = -1.268
    order4 = sorted(vals, key=lambda x: vals[x])
    rank4 = {k: order4.index(k) + 1 for k in order4}

    pairs = [("F 死区 $\\theta=1.5$", "F", "F 死区theta=1.5", True),
             ("C 恒报 $\\max(1.2\\hat L,Q^c)$", "up12_qc", "C 恒报 max(1.2L_hat,Qc)", False),
             ("恒报 $1.2\\hat L$（零模型）", "up12", "恒报 1.2L_hat", False),
             ("B 恒报 $\\hat L$", "flat", "B 恒报 L_hat", False),
             ("D 恒报 $0.8\\hat L$", "dn08", "D 恒报 0.8L_hat", False),
             ("E 28 日符号切换", "E", "E 28日符号切换", False),
             ("R1（$\\lambda=0$）", "R1", "R1 风险申报 R1", False),
             ("R2（$\\lambda=0.5$）", "R2", "H 风险申报 R2", False),
             ("R3（$\\lambda=2.0$）", "R3", "R3 风险申报 R3", False),
             ("A 按合约量申报", "baseline", "A 按合约量", False),
             ("G 确定性申报", "det", "G 确定性申报", False)]
    rows = []
    for label, k4, key23, is_bold in pairs:
        r4 = rank4.get(k4); v4 = vals.get(k4)
        r23 = int(o.loc[key23, "排名"]) if key23 in o.index else None
        v23 = float(o.loc[key23, "相对基准_pct"]) if key23 in o.index else None
        c4 = f"{v4:+.3f}\\%（{r4}）" if v4 is not None else "---"
        c23 = f"{v23:+.3f}\\%（{r23}）" if v23 is not None else "---"
        move = f"{r4}$\\to${r23}" if (r4 and r23) else "---"
        f_ = bold if is_bold else (lambda x: x)
        rows.append(row(f_(label), c4, c23, move))
    return table("tab:oos", "样本外裁判：同一批规则在两个真实时段的排名",
                 "@{}lrrr@{}",
                 row(r"规则", r"评估期 4--8 月", r"样本外 2--3 月", r"排名（前$\to$后）"),
                 rows, small=True)


TABLES = [
    ("tab_q1cost", tab_q1cost),
    ("tab_q2res", tab_q2res),
    ("tab_q2weight", tab_q2weight),
    ("tab_q3base", tab_q3base),
    ("tab_q3econ", tab_q3econ),
    ("tab_q3decomp", tab_q3decomp),
    ("tab_shrink", tab_shrink),
    ("tab_q4bench", tab_q4bench),
    ("tab_q4risk", tab_q4risk),
    ("tab_ablation", tab_ablation),
    ("tab_switch", tab_switch),
    ("tab_q4month", tab_q4month),
    ("tab_minimax", tab_minimax),
    ("tab_april", tab_april),
    ("tab_boot", tab_boot),
    ("tab_paired", tab_paired),
    ("tab_monthblock", tab_monthblock),
    ("tab_riskboot", tab_riskboot),
    ("tab_riskex", tab_riskex), ("tab_oos", tab_oos),
    ("tab_fmonth", tab_fmonth),
    ("tab_nested", tab_nested),
    ("tab_q4sens", tab_q4sens),
]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    os.makedirs(TAB, exist_ok=True)
    n = 0
    failed = []
    for name, fn in TABLES:
        try:
            tex = fn()
        except Exception as e:
            print(f"  [失败] {name}: {type(e).__name__}: {e}")
            failed.append((name, f"{type(e).__name__}: {e}"))
            continue
        with open(os.path.join(TAB, name + ".tex"), "w", encoding="utf-8") as f:
            f.write(tex)
        n += 1
    print(f"  生成 {n}/{len(TABLES)} 张表 -> {TAB}")
    if failed:
        # 静默跳过会让论文编译通过但表格缺失，这里改为硬失败
        print("\n  [错误] 以下表格生成失败，论文将缺表：")
        for k, v in failed:
            print(f"    {k}: {v}")
        print("  请先补齐对应的上游产物（多为 outputs/*.csv），再重跑本脚本。")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
