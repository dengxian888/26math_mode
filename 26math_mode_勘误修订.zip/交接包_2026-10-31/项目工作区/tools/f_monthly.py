# -*- coding: utf-8 -*-
"""F 的逐月成本与"剔除 4 月"重算——交付 F 是否同样依赖极端月？

**为什么要做**：论文用四窗 minimax + 配对检验支持交付 F，但从未检验
**F 的优势是否也像零模型那样集中在 4 月**。若 F 在 4 月拿到的收益与其总优势同量级，
则"交付 F"与"交付 R2"面临同一种质疑。

逐月输出 F / R2 / C / 恒报1.2L̂ 的成本与相对基准值，并给出剔除 4 月后的配对检验。

输出 `outputs/f_monthly.csv`、`outputs/f_ex_april.csv`。

用法：<venv>/python.exe -m tools.f_monthly
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
BLOCK, B, SEED = 7, 5000, 42


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(q4[["date", "hour", "q_risk", "q_final"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"]))
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)

    rules = {"F（交付规则）": df["q_final"].to_numpy(float),
             "R2（系统基线）": df["q_risk"].to_numpy(float),
             "C（恒报上带）": up,
             "恒报 1.2L": 1.2 * Lh,
             "按合约量（基准）": qc}

    idx_by_day = list(df.groupby("date").indices.items())
    days = [str(d)[:7] for d, _ in idx_by_day]
    def daily(q):
        return np.asarray([settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                           for _, i in idx_by_day], float)
    D = {k: daily(v) for k, v in rules.items()}

    bench = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    if abs(D["C（恒报上带）"].sum() - float(bench.loc["up12_qc", "总成本"])) > 1.0:
        raise SystemExit("[自校验失败] C 与表 17 不符")

    base = D["按合约量（基准）"]
    months = np.array(days)
    rows = []
    for m in sorted(set(months)):
        msk = months == m
        b = base[msk].sum()
        rows.append({"月份": m, **{k: round((D[k][msk].sum() - b) / b * 100, 3)
                                   for k in rules if k != "按合约量（基准）"}})
    tot_b = base.sum()
    rows.append({"月份": "全期", **{k: round((D[k].sum() - tot_b) / tot_b * 100, 3)
                                    for k in rules if k != "按合约量（基准）"}})
    mdf = pd.DataFrame(rows)
    mdf.to_csv(os.path.join(OUT, "f_monthly.csv"), index=False, encoding="utf-8-sig")

    # 剔除 4 月
    keep = months != "2026-04"
    b2 = base[keep].sum()
    ex = {k: round((D[k][keep].sum() - b2) / b2 * 100, 3) for k in rules if k != "按合约量（基准）"}

    # 配对检验（剔除 4 月后）：F vs R2、F vs C
    n = int(keep.sum()); nb = int(np.ceil(n / BLOCK))
    rng = np.random.default_rng(SEED)
    # diff 已按 keep 子集化，长度 n，故索引直接取 0..n-1
    idxs = [np.concatenate([(np.arange(s, s + BLOCK) % n) for s in rng.integers(0, n, size=nb)])[:n]
            for _ in range(B)]
    erows = []
    for a_, b_ in [("F（交付规则）", "R2（系统基线）"), ("F（交付规则）", "C（恒报上带）")]:
        diff = (D[a_] - D[b_])[keep]
        boots = np.array([diff[i].mean() for i in idxs])
        lo, hi = np.percentile(boots, [2.5, 97.5])
        p = float(2 * min((boots <= 0).mean(), (boots >= 0).mean()))
        erows.append({"对比": f"{a_} vs {b_}", "剔除4月后日均差_元": round(float(diff.mean()), 1),
                      "CI下界": round(float(lo), 1), "CI上界": round(float(hi), 1),
                      "p值": round(p, 4), "显著": "是" if (lo > 0 or hi < 0) else "否"})
    edf = pd.DataFrame(erows)
    edf.to_csv(os.path.join(OUT, "f_ex_april.csv"), index=False, encoding="utf-8-sig")

    print("=" * 84)
    print("F 与各规则的逐月相对成本（%，负 = 比按合约量申报便宜）")
    print("=" * 84)
    print(mdf.to_string(index=False))
    print("\n剔除 4 月后的全期：")
    for k, v in ex.items():
        print(f"    {k:<16}{v:+.3f}%")
    print()
    print(edf.to_string(index=False))
    print(f"\n  产出：f_monthly.csv、f_ex_april.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
