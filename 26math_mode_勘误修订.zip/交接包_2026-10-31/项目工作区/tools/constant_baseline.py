# -*- coding: utf-8 -*-
"""最平凡基准：用一个"常数"预测价差，看 MAE 与经济效果。

动机：论文此前比较了 GBDT、分时段中位数（24 参数）等多种预测器，却从未试过
**常数预测**。而价差是重尾分布，常数（中位数）的 MAE 可能反而最小。

结果同时给出两个排序：
  - 按 MAE：常数最优、GBDT 最差；
  - 按经济效果：常数（取正号）最优、常数（取中位数）最差、GBDT 居中。
这正是"MAE 与决策不对齐"的最锋利例证。

输出 `outputs/constant_baseline.csv`。

用法：<venv>/python.exe -m tools.constant_baseline
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
def _base_cost():
    """按合约量申报的全期成本，从产物读取而非硬编码。"""
    b = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig")
    return float(b.set_index("key").loc["baseline", "总成本"])


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    BASE_COST = _base_cost()
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"]))
    df["S"] = df["price_rt"] - df["price_da"]
    S = df["S"].to_numpy(float)
    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)

    def cost_of(q):
        L = df["load_actual"].to_numpy(float)
        pda = df["price_da"].to_numpy(float)
        prt = df["price_rt"].to_numpy(float)
        pc = df["contract_p"].to_numpy(float)
        return sum(settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                   for i in df.groupby("date").indices.values())

    def bid(Sv):
        up = np.maximum(1.2 * Lh, qc)
        dn = np.maximum(0, np.minimum(qc, 0.8 * Lh))
        return np.where(Sv > 0, up, dn)

    rows = []
    for name, c in [("常数=中位数", float(np.median(S))), ("常数=0", 0.0),
                    ("常数=+1（微正）", 1.0), ("常数=均值", float(S.mean()))]:
        mae = float(np.abs(S - c).mean())
        cost = cost_of(bid(np.full(len(df), c)))
        rows.append({"预测器": name, "取值": round(c, 2), "价差MAE": round(mae, 2),
                     "总成本": round(cost, 2),
                     "相对基准_pct": round((cost - BASE_COST) / BASE_COST * 100, 3)})

    # 注意：pred_spread_direct 是**已校正**后的产物（校正发生在 walk_forward 内），
    # 因此这里必须标注为"已校正"，否则与表 8 的 96.66（未校正）混淆。
    for name, col in [("GBDT（已校正）", "pred_spread_direct")]:
        if col in q3:
            m = q3[[col]].to_numpy(float).ravel()
            mae = float(np.abs(S - m).mean())
            cost = cost_of(bid(m))
            rows.append({"预测器": name, "取值": None, "价差MAE": round(mae, 2),
                         "总成本": round(cost, 2),
                         "相对基准_pct": round((cost - BASE_COST) / BASE_COST * 100, 3)})

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "constant_baseline.csv"), index=False, encoding="utf-8-sig")
    print("=" * 72)
    print(out.to_string(index=False))
    print("=" * 72)
    print(f"\n  产出：{os.path.join(OUT, 'constant_baseline.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
