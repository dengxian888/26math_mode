# -*- coding: utf-8 -*-
"""月份块聚类推断 + 留一月稳定性 + Holm 校正选择检验。

**为什么要做**：此前的配对 bootstrap 用 7 天块，远短于本文结果的主导聚集尺度
（4 月 E[S]=+91.97，其余月 +7.10）。7 天块会系统性低估不确定性，
而"从 22 条候选里挑最好"又系统性高估最优者——两项误差方向相反却都偏向
"F 显著优于 R2"。本脚本用**月份为块**重做推断，并给出留一月排名稳定性。

输出 outputs/month_block.csv、outputs/loo_month.csv。

用法：<venv>/python.exe -m tools.month_block
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
B, SEED = 20000, 42


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    q4 = pd.read_csv(os.path.join(OUT, "q4_risk.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(q4[["date", "hour", "q_risk", "q_final"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"])).sort_values(["date", "hour"]).reset_index(drop=True)
    L = df["load_actual"].to_numpy(float); pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float); qc = df["contract_q"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    up = np.maximum(1.2 * df["L_hat"].to_numpy(float), qc)
    Lh = df["L_hat"].to_numpy(float)

    idx = list(df.groupby("date").indices.items())
    days = [str(d)[:10] for d, _ in idx]
    months = np.array([d[:7] for d in days])
    def daily(q):
        return np.asarray([settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                           for _, i in idx])
    rules = {"F（交付规则）": df["q_final"].to_numpy(float),
             "R2（基线档）": df["q_risk"].to_numpy(float),
             "C（恒报上带）": up,
             "恒报 1.2L": 1.2 * Lh}
    D = {k: daily(v) for k, v in rules.items()}
    base = daily(qc)

    bench = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    if abs(D["C（恒报上带）"].sum() - float(bench.loc["up12_qc", "总成本"])) > 1.0:
        raise SystemExit("[自校验失败] C 与表 17 不符")

    # ---- (1)  月份块 bootstrap（以月为块，整块重采样）----
    uniq = sorted(set(months))
    blocks = [np.where(months == m)[0] for m in uniq]
    rng = np.random.default_rng(SEED)
    rows = []
    for a_, b_ in [("F（交付规则）", "R2（基线档）"), ("C（恒报上带）", "R2（基线档）"),
                   ("F（交付规则）", "C（恒报上带）"), ("恒报 1.2L", "R2（基线档）")]:
        diff = D[a_] - D[b_]
        boots = np.empty(B)
        for k in range(B):
            pick = rng.integers(0, len(blocks), size=len(blocks))
            ii = np.concatenate([blocks[j] for j in pick])
            boots[k] = diff[ii].mean()
        lo, hi = np.percentile(boots, [2.5, 97.5])
        p = float(2 * min((boots <= 0).mean(), (boots >= 0).mean()))
        rows.append({"对比": f"{a_} vs {b_}", "日均差_元": round(float(diff.mean()), 1),
                     "CI下界": round(float(lo), 1), "CI上界": round(float(hi), 1),
                     "p值": round(p, 4), "显著": "是" if (lo > 0 or hi < 0) else "否",
                     "块数": len(uniq)})
    mb = pd.DataFrame(rows)
    mb.to_csv(os.path.join(OUT, "month_block.csv"), index=False, encoding="utf-8-sig")

    # ---- (2)  留一月：去掉任一月后，F 是否仍是最优（点估计）----
    lorows = []
    for m in uniq:
        keep = months != m
        rel = {k: (D[k][keep].sum() - base[keep].sum()) / base[keep].sum() * 100 for k in rules}
        order = sorted(rel, key=lambda x: rel[x])
        lorows.append({"剔除月份": m, **{k: round(v, 3) for k, v in rel.items()},
                       "最便宜者": order[0], "F排名": order.index("F（交付规则）") + 1})
    lo_df = pd.DataFrame(lorows)
    lo_df.to_csv(os.path.join(OUT, "loo_month.csv"), index=False, encoding="utf-8-sig")

    print("=" * 84)
    print("(1)  月份块 bootstrap（以月为块整块重采样，正 = 前者更贵）")
    print("=" * 84)
    print(mb.to_string(index=False))
    print()
    print("=" * 84)
    print("(2)  留一月：剔除任一月后的排名（% 相对按合约量申报）")
    print("=" * 84)
    print(lo_df.to_string(index=False))
    print()
    print(f"  产出：month_block.csv、loo_month.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
