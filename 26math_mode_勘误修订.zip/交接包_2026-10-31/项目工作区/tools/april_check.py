# -*- coding: utf-8 -*-
"""剔除 4 月后的重算：全文最重要的一个敏感性检验。

**为什么要做**：表 17 里三条"零模型"在点估计上优于全部风险方案（-1.531%/-1.548%
对 -0.178%），这是论文最响的负面结论。但 4 月一个月的价差均值是 +91.97，
接近全期均值 +23.74 的四倍----若把 4 月剔除，零模型是否仍然更优？

**结论（见输出）**：不。剔除 4 月后，两个零模型全部失效（C 反亏 +0.026%、
恒报 1.2L_hat 仅 -0.025%），而风险方案 R1/R2 反而更好（-0.305%/-0.160%）。
这与论文的主论点一致：**收益是对 E[S]>0 的暴露，E[S] 越大，"永远贴带上"越占便宜。**

本脚本自行从原始数据逐日结算（不依赖 q4_monthly 的派生列），并**自校验全期值必须
等于 q4_benchmark.csv**----若不等则直接报错，避免再出现"用错列反推"这类问题。

输出 `outputs/april_check.csv`。

用法：<venv>/python.exe -m tools.april_check
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    plans = pd.read_csv(os.path.join(OUT, "q4_plans.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(plans[["date", "hour", "q_R1", "q_R2", "q_R3"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"]))
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)

    rules = {
        "C 恒报 max(1.2L,Qc)": np.maximum(1.2 * Lh, qc),
        "恒报 1.2L": 1.2 * Lh,
        "恒报 L_hat": Lh,
        "R1（lambda=0）": df["q_R1"].to_numpy(float),
        "R2（系统基线档）": df["q_R2"].to_numpy(float),
        "R3（lambda=2）": df["q_R3"].to_numpy(float),
        "确定性申报": df["q_bid"].to_numpy(float),
        "按合约量（基准）": qc,
    }

    # 逐日成本
    idx_by_day = list(df.groupby("date").indices.items())
    days = [d for d, _ in idx_by_day]

    def daily(q):
        out = []
        for _, idx in idx_by_day:
            out.append(settle_day(np.asarray(q, float)[idx], L[idx], pda[idx],
                                  prt[idx], qc[idx], pc[idx])["sums"]["total"])
        return np.asarray(out, float)

    daily_cost = {k: daily(v) for k, v in rules.items()}
    base_d = daily_cost["按合约量（基准）"]
    months = np.array([str(d)[:7] for d in days])
    apr_mask = months == "2026-04"

    # ---- 自校验：全期相对值必须与 q4_benchmark.csv 一致 ----
    bench = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    keymap = {"C 恒报 max(1.2L,Qc)": "up12_qc", "恒报 L_hat": "flat", "恒报 1.2L": "up12",
              "R1（lambda=0）": "R1", "R2（系统基线档）": "R2", "R3（lambda=2）": "R3",
              "确定性申报": "det", "按合约量（基准）": "baseline"}
    full = {}
    for k in rules:
        full[k] = (daily_cost[k].sum() - base_d.sum()) / base_d.sum() * 100
    bad = []
    for k, kk in keymap.items():
        if kk in bench.index:
            want = float(bench.loc[kk, "相对基准_pct"])
            if abs(full[k] - want) > 0.01:
                bad.append((k, round(full[k], 3), want))
    if bad:
        raise SystemExit(f"[自校验失败] 全期值与 q4_benchmark 不符：{bad}")

    rows = []
    for k in rules:
        b_rest = base_d[~apr_mask].sum()
        ex = (daily_cost[k][~apr_mask].sum() - b_rest) / b_rest * 100
        rows.append({"方案": k, "全期_pct": round(full[k], 3),
                     "剔除4月_pct": round(ex, 3),
                     "是否反转": "是" if (full[k] < 0) != (ex < 0) else ""})
    out = pd.DataFrame(rows).sort_values("剔除4月_pct")
    out.to_csv(os.path.join(OUT, "april_check.csv"), index=False, encoding="utf-8-sig")

    print("=" * 74)
    print("剔除 4 月后的重算（负 = 比按合约量申报便宜）")
    print("=" * 74)
    print(out.to_string(index=False))
    print(f"\n  [自校验通过] 全期值与 q4_benchmark.csv 一致")
    print(f"  4 月基准成本 {base_d[apr_mask].sum():,.0f} | 剔除后 {base_d[~apr_mask].sum():,.0f}")
    print(f"  产出：{os.path.join(OUT, 'april_check.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
