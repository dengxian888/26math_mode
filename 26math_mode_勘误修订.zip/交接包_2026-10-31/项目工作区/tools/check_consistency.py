# -*- coding: utf-8 -*-
"""表的内部与表间数值自洽检查。

盲评反复在做的一类检查是"表内各分量之和是否等于合计""日均x天数是否等于总额"
"正文说的方向是否与表一致"。此前这些只能靠人工复核，本脚本把可自动化的部分固化下来。

用法：python tools/check_consistency.py
退出码 0 表示全部通过。
"""
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def read(n):
    return pd.read_csv(os.path.join(OUT, n), encoding="utf-8-sig")


PASS, FAIL = [], []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name + ("" if cond else f"  {detail}"))


def main():
    sys.stdout.reconfigure(encoding="utf-8")

    # ---- 表3：五行之和 == 合计
    d = read("q1_cost.csv")
    s = d["cost_total"].sum()
    b = d["baseline_total"].sum()
    # 与论文表 3 中印出的合计常量比较（此前的写法是自己减自己，恒真）
    chk("表3 分项和 = 表内合计 1,432,352.61", abs(s - 1432352.61) < 0.02,
        f"得 {s:.2f}")
    chk("表3 节省额 = 基准-最优", abs((b - s) - 258311.79) < 0.05, f"得 {b-s:.2f}")
    chk("表3 节省率 = 节省/基准", abs((b - s) / b * 100 - 15.279) < 0.01,
        f"得 {(b-s)/b*100:.3f}")

    # ---- 表17 与表18：日均 x 153 == 总成本
    bench = read("q4_benchmark.csv").set_index("key")
    risk = read("q4_risk_metrics.csv").set_index("key")
    for k in risk.index:
        if k in bench.index:
            chk(f"表18 {k} 日均x153 = 表17 总成本",
                abs(risk.loc[k, "日均"] * 153 - bench.loc[k, "总成本"]) < 200,
                f"日均x153={risk.loc[k,'日均']*153:,.0f} vs {bench.loc[k,'总成本']:,.0f}")

    # ---- 表20：差额合计 == 表17 两方案之差
    m = read("q4_monthly.csv")
    tot = m["R2减零模型_元"].sum()
    gap = bench.loc["R2", "总成本"] - bench.loc["up12_qc", "总成本"]
    chk("表20 差额合计 = 表17 R2-零模型", abs(tot - gap) < 200, f"{tot:,.0f} vs {gap:,.0f}")

    # ---- 表20：月度价差均值按天数加权 == 全期均值
    a4 = pd.read_csv(os.path.join(ROOT, "data", "interim", "att4_价格.csv"),
                     encoding="utf-8-sig")
    a4["S"] = a4["price_rt"] - a4["price_da"]
    daily = a4.groupby("date")["S"].mean()
    ev = daily[(daily.index >= "2026-04-01") & (daily.index <= "2026-08-31")]
    chk("表20 价差均值 153 天 = +23.74", abs(ev.mean() - 23.74) < 0.01, f"{ev.mean():.3f}")
    wsum = sum(
        daily[(daily.index >= r["month"] + "-01") & (daily.index <= r["month"] + "-31")].mean()
        * len(ev[(ev.index >= r["month"] + "-01") & (ev.index <= r["month"] + "-31")])
        for _, r in m.iterrows())
    chk("表20 月度按天数加权 = 全期", abs(wsum / 153 - ev.mean()) < 0.01, f"{wsum/153:.3f}")

    # ---- 表16：gamma=1.0 应等于表14 的确定性申报
    sh = read("q3_shrinkage.csv")
    g1 = sh[sh["gamma"].round(2) == 1.0]
    econ = read("q3_econ.csv")
    if len(g1) and len(econ):
        base_c = float(econ[econ["方案"].str.contains("按合约量")]["总成本"].iloc[0])
        det_c = float(econ[econ["方案"].str.contains("确定性")]["总成本"].iloc[0])
        chk("表16 gamma=1.0 百分比 = 由表14 成本算出的百分比",
            abs(float(g1["相对基准_pct"].iloc[0]) - (det_c - base_c) / base_c * 100) < 0.01)
        chk("表16 gamma=1.0 总成本 = 表14 总成本",
            abs(float(g1["总成本"].iloc[0]) - float(econ.iloc[0]["总成本"])) < 0.05)

    # ---- 表16：最优 gamma 应使成本最低
    imin = sh["总成本"].idxmin()
    # 实检：最优 gamma 应落在论文正文声明的 [0.1, 0.6] 区间内（此前是自己减自己，恒真）
    chk("表16 最优 gamma 落在正文声明的 [0.1,0.6] 内",
        0.1 <= float(sh.loc[imin, "gamma"]) <= 0.6,
        f"得 gamma={float(sh.loc[imin, 'gamma']):.2f}")
    chk("表16 盈利区间含 0.1~0.6",
        set(sh[sh["相对基准_pct"] < 0]["gamma"].round(1)) >= {0.1, 0.2, 0.3, 0.4, 0.5, 0.6},
        str(sorted(sh[sh["相对基准_pct"] < 0]["gamma"].round(1))))

    # ---- 表15：四格相对基准与总成本互验
    dc = read("q3_decompose.csv")
    base = bench.loc["baseline", "总成本"]
    for _, r in dc.iterrows():
        calc = (r["总成本"] - base) / base * 100
        chk(f"表15 {r['组合']} 百分比与成本互验", abs(calc - r["相对基准_pct"]) < 0.01,
            f"{calc:.3f} vs {r['相对基准_pct']}")

    # ---- 表8：WMAPE 与 MAE 的自洽（隐含平均负荷应一致）
    q2 = read("q2_metrics.csv")
    means = (q2["MAE"] / q2["WMAPE"] * 100).round(2)
    chk("表8 各行隐含平均负荷一致", means.max() - means.min() < 0.1, str(means.tolist()))

    # ---- 表19：固定上带应是最优
    sw = read("q4_switch.csv")
    chk("表19 固定上带成本最低", sw["总成本"].idxmin() ==
        sw[sw["规则"].str.contains("固定上带")].index[0])

    # ---- 表21：样本外排名与数值方向一致
    o = read("oos_1_3_month.csv").sort_values("相对基准_pct").reset_index(drop=True)
    # 标准竞赛排名：rank = 1 + 严格小于它的个数（并列共享名次，后续跳号）
    v = o["相对基准_pct"].to_numpy(float)
    want = (1 + (v[:, None] > v[None, :]).sum(axis=1)).tolist()
    chk("表21 排名随成本单调（支持并列）", list(o["排名"]) == want,
        f"实得 {list(o['排名'])} / 应为 {want}")

    # ---- 表17：零模型应优于全部风险方案
    for k in ["R1", "R2", "R3"]:
        chk(f"表17 零模型优于 {k}",
            bench.loc["up12_qc", "总成本"] < bench.loc[k, "总成本"])

    print("=" * 64)
    print(f"  通过 {len(PASS)} 项 / 失败 {len(FAIL)} 项")
    print("=" * 64)
    if FAIL:
        for f in FAIL:
            print("  [失败]", f)
        return 1
    print("  全部自洽")
    return 0


if __name__ == "__main__":
    sys.exit(main())
