# -*- coding: utf-8 -*-
"""规则之间的**配对**块 bootstrap：F vs R2、C vs R2、R1 vs R2 等。

**为什么必须做这个**：此前的 bootstrap（tools/bootstrap_ci.py）只做了
"每条规则 vs 基准"的边际检验，全部 CI 跨零；正文据此说"1.37pp 的差距同样不显著"。
但这在逻辑上不成立——"两者都与基准不可分"推不出"两者之差不可分"。
规则之间的**配对差**消掉了共同的日效应，标准误通常远小于边际检验，
完全可能出现"各自都不显著、但配对差显著"。

本脚本给出：配对均差、95% CI、p 值，以及"要把 1pp 与噪声分开需要多少天"的功效估算。

输出 `outputs/paired_bootstrap.csv`。

用法：<venv>/python.exe -m tools.paired_bootstrap
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
B = 5000
BLOCK = 7
SEED = 42


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, ROOT)
    from src.common.settle import settle_day

    q2 = pd.read_csv(os.path.join(OUT, "q2_forecast.csv"), encoding="utf-8-sig")
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    plans = pd.read_csv(os.path.join(OUT, "q4_plans.csv"), encoding="utf-8-sig")
    a4 = pd.read_csv(os.path.join(ROOT, "data/interim/att4_价格.csv"), encoding="utf-8-sig")
    a2 = pd.read_csv(os.path.join(ROOT, "data/interim/att2_用电量.csv"), encoding="utf-8-sig")
    a5 = pd.read_csv(os.path.join(ROOT, "data/interim/att5_合约.csv"), encoding="utf-8-sig")
    df = (q2[["date", "hour", "pred_final"]].rename(columns={"pred_final": "L_hat"})
          .merge(q3[["date", "hour", "q_bid"]], on=["date", "hour"])
          .merge(plans[["date", "hour", "q_R1", "q_R2", "q_R3"]], on=["date", "hour"])
          .merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
          .merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"])
          .merge(a5, on=["date", "hour"]))
    df["S"] = df["price_rt"] - df["price_da"]
    df = df.sort_values(["date", "hour"]).reset_index(drop=True)

    Lh = df["L_hat"].to_numpy(float)
    qc = df["contract_q"].to_numpy(float)
    L = df["load_actual"].to_numpy(float)
    pda = df["price_da"].to_numpy(float)
    prt = df["price_rt"].to_numpy(float)
    pc = df["contract_p"].to_numpy(float)
    up = np.maximum(1.2 * Lh, qc)

    # 死区规则 F（theta=1.5）：|z|>=1.5 用 R2，否则按 28 日均值符号
    a4b = a4.copy(); a4b["S"] = a4b["price_rt"] - a4b["price_da"]
    hist = a4b.groupby("date")["S"].mean()
    s_by = pd.concat([hist, df.groupby("date")["S"].mean()]).groupby(level=0).last()
    dts = sorted(s_by.index)
    mu = {}
    for D in dts:
        past = [x for x in dts if x < D and (pd.Timestamp(D) - pd.Timestamp(x)).days >= 7]
        mu[D] = float(s_by[past[-28:]].mean()) if len(past) >= 5 else 0.0
        sd = float(s_by[past[-28:]].std(ddof=1)) if len(past) >= 5 else np.nan
        mu[(D, "sd")] = sd
    m = df["date"].map(lambda x: mu.get(x, 0.0)).to_numpy(float)
    sdv = df["date"].map(lambda x: mu.get((x, "sd"), np.nan)).to_numpy(float)
    z = m / (sdv / np.sqrt(28))
    inside = (np.abs(z) < 1.5) & np.isfinite(sdv)
    q_R2 = df["q_R2"].to_numpy(float)
    qF = np.where(inside, q_R2, np.where(m > 0, up, 0.8 * Lh))

    rules = {"F 死区(" + "theta=1.5)": qF,
             "C 恒报上带": up,
             "恒报 L": Lh,
             "R2": q_R2,
             "R1": df["q_R1"].to_numpy(float)}

    idx_by_day = list(df.groupby("date").indices.items())
    def daily(q):
        return np.asarray([settle_day(np.asarray(q, float)[i], L[i], pda[i], prt[i], qc[i], pc[i])["sums"]["total"]
                           for _, i in idx_by_day], float)

    D = {k: daily(v) for k, v in rules.items()}

    # 自校验：R2 / C / 恒报L 的逐日总和须与表17 一致
    bench = pd.read_csv(os.path.join(OUT, "q4_benchmark.csv"), encoding="utf-8-sig").set_index("key")
    base = D["R2"].sum() / (1 + float(bench.loc["R2", "相对基准_pct"]) / 100)
    for k, kk in [("R2", "R2"), ("C 恒报上带", "up12_qc"), ("恒报 L", "flat")]:
        want = float(bench.loc[kk, "总成本"])
        if abs(D[k].sum() - want) > 1.0:
            raise SystemExit(f"[自校验失败] {k}: {D[k].sum():,.0f} vs {want:,.0f}")

    n = len(D["R2"])
    nb = int(np.ceil(n / BLOCK))
    rng = np.random.default_rng(SEED)
    idxs = [np.concatenate([(np.arange(s, s + BLOCK) % n) for s in rng.integers(0, n, size=nb)])[:n]
            for _ in range(B)]

    pairs = [("F 死区(" + "theta=1.5)", "R2"), ("C 恒报上带", "R2"), ("R1", "R2"),
             ("恒报 L", "R2"), ("F 死区(" + "theta=1.5)", "C 恒报上带")]
    rows = []
    for a, b in pairs:
        diff = D[a] - D[b]          # 正 = a 更贵
        point = float(diff.mean())
        boots = np.array([diff[i].mean() for i in idxs])
        lo, hi = np.percentile(boots, [2.5, 97.5])
        p = float(2 * min((boots <= 0).mean(), (boots >= 0).mean()))
        se = float(boots.std(ddof=1))
        # 功效：要把 1% 的日均差（约 3850 元/日）与噪声分开需要多少天
        need = int(np.ceil((1.96 * se / 3853.0) ** 2)) if se > 0 else -1
        rows.append({"对比": f"{a} vs {b}", "日均差_元": round(point, 1),
                     "CI下界": round(float(lo), 1), "CI上界": round(float(hi), 1),
                     "p值": round(p, 4), "显著": "是" if (lo > 0 or hi < 0) else "否",
                     "分开1pp所需天数": need})

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "paired_bootstrap.csv"), index=False, encoding="utf-8-sig")
    print("=" * 92)
    print("配对块 bootstrap（正 = 前者更贵；块长 7 天，重采样 5000 次）")
    print("=" * 92)
    print(out.to_string(index=False))
    print(f"\n  [自校验通过] R2/C/恒报L 的总成本与表 17 一致")
    print(f"  产出：{os.path.join(OUT, 'paired_bootstrap.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
