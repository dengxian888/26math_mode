# -*- coding: utf-8 -*-
"""论文中被引用、但此前没有独立脚本来源的统计量，统一落盘。

**须区分两个口径**（这是本脚本要紧的地方）：
  - `q3_price_bid.csv` 里的 `pred_spread_direct` 是**已施加滚动偏差校正**的预测
    （校正在 walk_forward 内部完成：pred = raw + bias）；
  - 论文所说的"未校正"口径必须用 `Q3_NO_BIAS=1` 跑一遍才有。
本脚本用 Q3 的 OUT 重定向在临时目录里跑一次对照，**不覆盖任何主产物**。

输出 `outputs/stats_report.csv`。

用法：<venv>/python.exe -m tools.stats_report
"""
import os
import shutil
import subprocess
import sys
import tempfile

import numpy as np
import pandas as pd
from scipy import stats as st

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def attach(q3):
    a4 = pd.read_csv(os.path.join(ROOT, "data", "interim", "att4_价格.csv"), encoding="utf-8-sig")
    df = q3.merge(a4[["date", "hour", "price_da", "price_rt"]], on=["date", "hour"])
    df["S"] = df["price_rt"] - df["price_da"]
    return df


def stats_of(df, col, label):
    acc = float(((df[col] > 0) == (df["S"] > 0)).mean() * 100)
    r = float(np.corrcoef(df[col], df["S"])[0, 1])
    return [{"口径": label, "符号准确率(%)": round(acc, 2),
             "与真实价差的相关系数": round(r, 4)}]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    rows = []

    # ---- 已校正口径（主产物） ----
    q3 = pd.read_csv(os.path.join(OUT, "q3_price_bid.csv"), encoding="utf-8-sig")
    df = attach(q3)
    rows += stats_of(df, "pred_spread_direct", "已校正（主产物）")
    neg = float((df["S"] < 0).mean() * 100)
    rows[0]["评估期负价差占比(%)"] = round(neg, 2)

    # ---- 未校正口径（临时目录跑 Q3_NO_BIAS=1） ----
    tmp = tempfile.mkdtemp(prefix="q3nb_")
    try:
        shutil.copy(os.path.join(OUT, "q2_forecast.csv"), tmp)
        env = dict(os.environ)
        env.update({"PYTHONIOENCODING": "utf-8",
                    "SUMMARY_PATH": os.path.join(tmp, "summary.json"), "Q3_NO_BIAS": "1", "Q3_OUT_DIR": tmp})
        r = subprocess.run([sys.executable, "-m", "src.q3.solve"], cwd=ROOT, env=env,
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            raise RuntimeError(r.stderr[-800:])
        raw = pd.read_csv(os.path.join(tmp, "q3_price_bid.csv"), encoding="utf-8-sig")
        rows += stats_of(attach(raw), "pred_spread_direct", "未校正（Q3_NO_BIAS=1）")
        rows[1]["评估期负价差占比(%)"] = round(neg, 2)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # ---- 两窗 Pearson / Spearman 及显著性 ----
    p = os.path.join(OUT, "nested_oos.csv")
    if os.path.exists(p):
        n = pd.read_csv(p, encoding="utf-8-sig")
        pr = st.pearsonr(n["选择窗_4-6月"], n["检验窗_7-8月"])
        sr = st.spearmanr(n["选择窗_4-6月"], n["检验窗_7-8月"])
        rows.append({"口径": "两窗线性相关", "符号准确率(%)": None,
                     "与真实价差的相关系数": round(float(pr.statistic), 3),
                     "说明": f"Pearson n={len(n)} p={pr.pvalue:.3f}"})
        rows.append({"口径": "两窗秩相关", "符号准确率(%)": None,
                     "与真实价差的相关系数": round(float(sr.statistic), 3),
                     "说明": f"Spearman n={len(n)} p={sr.pvalue:.3f}"})

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "stats_report.csv"), index=False, encoding="utf-8-sig")
    print("=" * 78)
    print(out.to_string(index=False))
    print("=" * 78)
    print(f"\n  产出：{os.path.join(OUT, 'stats_report.csv')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
