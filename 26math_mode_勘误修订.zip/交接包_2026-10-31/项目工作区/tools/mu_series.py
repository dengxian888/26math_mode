# -*- coding: utf-8 -*-
"""2--3 月的逐日 28 日滚动均值序列（用完整合法历史），用于支撑"E 与 D 逐位并列"。

正文声称 2--3 月"59 天滚动均值无一为正"，因此符号规则 E 在该窗恒等于报下带 D。
本脚本把这条序列落盘，供核对：关键在于 1 月的深度负值（E[S]=-38.10）会把 3 月的
滚动均值压住——即使 3 月当月均值为正，28 日窗口仍为负。

输出 `outputs/mu_series_2_3.csv`。

用法：<venv>/python.exe -m tools.mu_series
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    a4 = pd.read_csv(os.path.join(ROOT, "data", "interim", "att4_价格.csv"), encoding="utf-8-sig")
    a4["S"] = a4["price_rt"] - a4["price_da"]
    daily = a4.groupby("date")["S"].mean()
    dates = list(daily.index)

    rows = []
    for D in dates:
        past = [x for x in dates if x < D and (pd.Timestamp(D) - pd.Timestamp(x)).days >= 7]
        if len(past) < 5:
            continue
        w = daily[past[-28:]]
        rows.append({"date": D, "当日价差": round(float(daily.loc[D]), 2),
                     "窗口天数": len(w), "28日均值": round(float(w.mean()), 2),
                     "28日标准差": round(float(w.std(ddof=1)), 2)})
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "mu_series_2_3.csv"), index=False, encoding="utf-8-sig")

    sub = out[(out.date >= "2026-02-01") & (out.date <= "2026-03-31")]
    print("=" * 62)
    print(f"  2--3 月可判断天数: {len(sub)}")
    print(f"  其中 28 日均值为正: {int((sub['28日均值'] > 0).sum())} 天")
    print(f"  其中 28 日均值为负: {int((sub['28日均值'] < 0).sum())} 天")
    print(f"  3/31 的 28 日均值: {float(sub[sub.date=='2026-03-31']['28日均值'].iloc[0]):+.2f}")
    print(f"\n  产出：{os.path.join(OUT, 'mu_series_2_3.csv')}")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
