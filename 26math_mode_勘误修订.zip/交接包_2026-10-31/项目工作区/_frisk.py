import pandas as pd, numpy as np, sys
sys.path.insert(0,'.')
from src.common.settle import settle_day
q4=pd.read_csv('outputs/q4_risk.csv',encoding='utf-8-sig')
q3=pd.read_csv('outputs/q3_price_bid.csv',encoding='utf-8-sig')
a4=pd.read_csv('data/interim/att4_价格.csv',encoding='utf-8-sig')
a2=pd.read_csv('data/interim/att2_用电量.csv',encoding='utf-8-sig')
a5=pd.read_csv('data/interim/att5_合约.csv',encoding='utf-8-sig')
df=(q4.merge(q3[['date','hour','q_bid']],on=['date','hour'])
      .merge(a4[['date','hour','price_da','price_rt']],on=['date','hour'])
      .merge(a2[['date','hour','load_actual']],on=['date','hour'])
      .merge(a5,on=['date','hour'])).sort_values(['date','hour']).reset_index(drop=True)
L=df.load_actual.to_numpy(float); pda=df.price_da.to_numpy(float)
prt=df.price_rt.to_numpy(float); qc=df.contract_q.to_numpy(float); pc=df.contract_p.to_numpy(float)
idx=list(df.groupby('date').indices.values())
def daily(q):
    return np.asarray([settle_day(np.asarray(q,float)[i],L[i],pda[i],prt[i],qc[i],pc[i])['sums']['total'] for i in idx])
def stats(q,lab):
    c=daily(q); k=max(1,int(np.ceil(0.05*len(c))))
    return {'方案':lab,'日均':round(float(c.mean()),2),'标准差':round(float(c.std(ddof=1)),2),
            'VaR95':round(float(np.sort(c)[int(0.95*len(c))]),2),
            'CVaR95':round(float(np.sort(c)[-k:].mean()),2),
            '最大单日':round(float(c.max()),2),'最差日':round(float(c.min()),2)}
rows=[stats(df.q_final.to_numpy(float),'F（交付规则）'),
      stats(df.q_risk.to_numpy(float),'R2（系统基线档）'),
      stats(df.q_bid.to_numpy(float),'确定性申报')]
out=pd.DataFrame(rows)
print(out.to_string(index=False))
print()
print('  对照论文表18: R2 日均 385,302 σ 51,591 VaR 450,102 CVaR 470,258 最大 493,100 最差 107,798')
