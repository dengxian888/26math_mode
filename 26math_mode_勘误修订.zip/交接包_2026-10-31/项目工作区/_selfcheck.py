import pymupdf, re, os, glob
import pandas as pd

print('='*70)
print('自检 1：LaTeX 结构')
print('='*70)
s=open('paper/论文.tex',encoding='utf-8').read()
labels=re.findall(r'\\label\{([^}]*)\}', s)
refs=set()
for m in re.finditer(r'\\(?:c|C)ref\{([^}]*)\}', s):
    for x in m.group(1).split(','): refs.add(x.strip())
from collections import Counter
dup=[k for k,v in Counter(labels).items() if v>1]
print(f'  重复 label: {dup if dup else "无"}')
missing = refs - set(labels)
print(f'  引用但无定义: {missing if missing else "无"}')
unused = set(labels) - refs
print(f'  定义但从未引用: {sorted(unused) if unused else "无"}')

# tabular 列数与单元格数
bad_tables=[]
for m in re.finditer(r'\\begin\{tabular\}\{([^}]*)\}(.*?)\\end\{tabular\}', s, re.S):
    spec, body = m.group(1), m.group(2)
    ncol = len(re.sub(r'@\{[^}]*\}|[^lcrp|]', '', spec))
    for line in body.split('\\\\'):
        line=line.strip()
        if not line or line.startswith('\\toprule') or line.startswith('\\midrule') \
           or line.startswith('\\bottomrule') or line.startswith('\\cmidrule'): continue
        if '\\multicolumn' in line: continue
        cells = line.count('&')+1
        if cells != ncol and cells>1:
            bad_tables.append((ncol, cells, line[:50]))
print(f'  tabular 列数不匹配: {len(bad_tables)} 处')
for x in bad_tables[:5]: print('   ', x)

print()
print('='*70)
print('自检 2：PDF 渲染')
print('='*70)
d=pymupdf.open('paper/论文.pdf')
full='\n'.join(d[i].get_text() for i in range(d.page_count))
print(f'  页数 {d.page_count} | 大小 {os.path.getsize("paper/论文.pdf")/1024/1024:.2f} MB')
print(f'  "??"x{full.count("??")} | 替换符x{full.count(chr(0xFFFD))} | extbf x{len(re.findall(r"(?<![a-z])extbf", full))}')
print(f'  tex 中 TAB: {s.count(chr(9))}')
apx=[k+1 for k in range(d.page_count) if '附录A' in d[k].get_text()][0]
t1=d[0].get_text()
print(f'  正文 {apx-1} 页 | 摘要1页 {("关键词" in t1) and ("问题重述" not in t1)}')
ascii_q = s[:s.index(r'\section*{附录}')].count('"')
print(f'  正文 ASCII 引号: {ascii_q}')

print()
print('='*70)
print('自检 3：图片引用')
print('='*70)
figs=re.findall(r'includegraphics(?:\[[^]]*\])?\{([^}]*)\}', s)
miss=[f for f in figs if not os.path.exists(os.path.join('outputs/figures',f))]
print(f'  引用 {len(figs)} 张 | 缺失 {miss if miss else "无"}')
