# -*- coding: utf-8 -*-
"""问题2 特征工程（T2.2）。

核心约束：**所有特征都必须满足 D-1 日 24:00 可得**（DECISIONS.md 口径 #4）。

按披露延迟换算成相对目标日 D 的滞后：
    附件2 实际用电量   T+4  →  只能用 D-5 及以前
    附件3 预测信息     T-1  →  **可用到 D 日**（最强信息源）
    附件3 实际运行信息 T+2  →  只能用 D-3 及以前

三档信息条件（附件6 定义）：
    A  仅附件2 历史用电 + 日期属性
    B  A + 附件3 预测信息（D 日）
    C  B + 附件3 实际运行信息（D-3）

实现：把长表 pivot 成 (日期 × 时段) 宽表，用 `shift(k)` 取 D-k 日的值。
日期序列是连续的 243 天，所以 shift 的行偏移恰好等于 k 天。
**不做任何 ffill/bfill**，避免把未来值带进来。
"""
import numpy as np
import pandas as pd

from src.common import io

HOURS = list(range(24))

A3_FIELDS = ["load_total", "gen_A", "gen_B", "gen_local", "tie_yuegang", "wind",
             "pv", "thermal", "hydro", "gen_total", "renew_total", "hydro_total",
             "reserve_up", "reserve_down"]

DAY_TYPE_CODE = {"普通工作日": 0, "普通周末": 1, "法定节假日": 2, "调休工作日": 3}
WD_MAP = {"周一": 0, "周二": 1, "周三": 2, "周四": 3, "周五": 4, "周六": 5, "周日": 6}

# 特征列定义（供各档使用）
FEAT_A = ["hour", "weekday", "day_type_code", "holiday_code", "is_weekend", "month",
          "lag5", "lag6", "lag7", "same_wd_mean", "same_wd_std",
          "roll7_mean", "roll7_std"]
FEAT_B = FEAT_A + [f"a3f_{c}" for c in A3_FIELDS]
FEAT_C = FEAT_B + [f"a3a_{c}_lag3" for c in A3_FIELDS]


def _assert_consecutive(dates):
    d = pd.to_datetime(pd.Series(dates))
    gaps = d.diff().dropna().dt.days.unique()
    if len(gaps) != 1 or gaps[0] != 1:
        raise ValueError(f"日期不连续，shift 语义不成立：间隔 {sorted(gaps)}")


def _wide(df, value_cols):
    """长表 -> {col: date×hour 宽表}，日期升序、列固定 0..23。"""
    out = {}
    for c in value_cols:
        w = df.pivot_table(index="date", columns="hour", values=c, aggfunc="last")
        out[c] = w.reindex(columns=HOURS).sort_index()
    return out


def _lag_frame(wide: pd.DataFrame, k: int, name: str) -> pd.DataFrame:
    """取 D-k 日的值，摊成 (date, hour, name) 长表。"""
    s = wide.shift(k)
    s.index.name = "date"
    out = s.stack(future_stack=True).rename(name).reset_index()
    return out


def build_panel(data=None) -> pd.DataFrame:
    """构建全量面板：每行 = (date, hour)，含目标列与三档特征。"""
    if data is None:
        data = io.load_attachments()

    a2 = data["att2"].copy()
    a3f = data["att3_forecast"].copy()
    a3a = data["att3_actual"].copy()

    dates = sorted(a2["date"].unique())
    _assert_consecutive(dates)

    # ---------- 网格与目标 ----------
    panel = pd.MultiIndex.from_product([dates, HOURS], names=["date", "hour"]).to_frame(index=False)
    panel = panel.merge(a2[["date", "hour", "load_actual"]], on=["date", "hour"], how="left")

    # ---------- 日期属性（目标日 D 的属性，事先已知）----------
    attr = (a2[["date", "weekday", "day_type", "holiday"]]
            .drop_duplicates("date").set_index("date").sort_index())
    attr["weekday"] = attr["weekday"].map(WD_MAP).fillna(0).astype(int)
    attr["day_type_code"] = attr["day_type"].map(DAY_TYPE_CODE).fillna(0).astype(int)
    attr["is_weekend"] = attr["day_type"].eq("普通周末").astype(int)
    attr["month"] = [int(d[5:7]) for d in attr.index]
    hol_names = sorted(attr["holiday"].dropna().unique())
    hol_map = {h: i for i, h in enumerate(hol_names)}
    attr["holiday_code"] = attr["holiday"].map(lambda x: hol_map.get(x, -1)).astype(int)
    attr = attr[["weekday", "day_type_code", "holiday_code", "is_weekend", "month"]]
    panel = panel.merge(attr, left_on="date", right_index=True, how="left")

    # ---------- A 档：附件2 历史负荷（≤ D-5）----------
    lw = _wide(a2, ["load_actual"])["load_actual"]

    for k in (5, 6, 7, 14, 21, 28):
        panel = panel.merge(_lag_frame(lw, k, f"_l{k}"), on=["date", "hour"], how="left")
    panel["lag5"] = panel["_l5"]
    panel["lag6"] = panel["_l6"]
    panel["lag7"] = panel["_l7"]

    # 同星期历史：D-7 / D-14 / D-21 / D-28（全部 ≤ D-5，故 D-1 决策时均可得）
    wd_cols = ["_l7", "_l14", "_l21", "_l28"]
    panel["same_wd_mean"] = panel[wd_cols].mean(axis=1)
    panel["same_wd_std"] = panel[wd_cols].std(axis=1)

    # 最近 7 个可用日（D-11..D-5）的均值与标准差
    tail = lw.shift(5).rolling(7, min_periods=4)
    panel = panel.merge(_lag_frame(tail.mean(), 0, "roll7_mean"), on=["date", "hour"], how="left")
    panel = panel.merge(_lag_frame(tail.std(), 0, "roll7_std"), on=["date", "hour"], how="left")
    panel = panel.drop(columns=["_l5", "_l6", "_l7", "_l14", "_l21", "_l28"])

    # ---------- B 档：附件3 预测信息（D 日，available = D-1）----------
    f = a3f[["date", "hour"] + A3_FIELDS].copy()
    f.columns = ["date", "hour"] + [f"a3f_{c}" for c in A3_FIELDS]
    panel = panel.merge(f, on=["date", "hour"], how="left")

    # ---------- C 档：附件3 实际运行信息（≤ D-3）----------
    aw = _wide(a3a, A3_FIELDS)
    for c in A3_FIELDS:
        panel = panel.merge(_lag_frame(aw[c], 3, f"a3a_{c}_lag3"), on=["date", "hour"], how="left")

    return panel.sort_values(["date", "hour"]).reset_index(drop=True)


def check_no_leakage(panel: pd.DataFrame) -> list:
    """抽查：确认 D 日特征里不含 D-1..D 的实际值（防未来信息泄漏）。

    返回问题列表，空列表表示通过。
    """
    problems = []
    # lag5 必须等于 D-5 的实际值
    d = panel.dropna(subset=["lag5"]).head(200)
    for _, r in d.iterrows():
        src = panel[(panel["date"] == r["date"]) & (panel["hour"] == r["hour"])]
        if src.empty:
            continue
        # 用日期位置回推 D-5
        dates = sorted(panel["date"].unique())
        i = dates.index(r["date"])
        if i < 5:
            continue
        d5 = dates[i - 5]
        ref = panel[(panel["date"] == d5) & (panel["hour"] == r["hour"])]["load_actual"]
        if len(ref) and abs(ref.iloc[0] - r["lag5"]) > 1e-9:
            problems.append((r["date"], r["hour"], "lag5", r["lag5"], ref.iloc[0]))
    return problems[:5]


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    p = build_panel()
    print("面板形状:", p.shape)
    print("A 档特征", len(FEAT_A), "| B 档", len(FEAT_B), "| C 档", len(FEAT_C))
    print("\nA 档特征缺失率(%):")
    print((p[FEAT_A].isna().mean() * 100).round(1).to_string())
    print("\n泄漏抽查:", check_no_leakage(p) or "通过 ✅")
